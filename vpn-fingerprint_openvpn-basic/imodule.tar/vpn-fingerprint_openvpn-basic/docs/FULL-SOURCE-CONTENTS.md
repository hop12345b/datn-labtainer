# Toàn bộ nội dung tệp nguồn — `vpn-fingerprint_openvpn-basic`

Tệp này gom nguyên văn các tệp nguồn dạng văn bản trong gói để tiện đọc và rà soát. Các archive `.tar`, `.tar.gz` và PDF vẫn nằm riêng trong cấu trúc gói ZIP.

> Lưu ý: `scripts/vpn-static.key` chỉ dùng cho mạng lab cô lập, không sử dụng trong môi trường thật.

## `config/start.config`

````text
# Labtainer start configuration for vpn-fingerprint_openvpn-basic
# The NETWORK GATEWAY addresses (.254) belong to Docker/Labtainer bridges.
# LAB GATEWAY values (.1) identify our simulated router container.
GLOBAL_SETTINGS
    HOST_HOME_XFER seed_dir/
    LAB_MASTER_SEED vpn_fingerprint_openvpn_basic_seed
    COLLECT_DOCS yes
    CHECKWORK yes

NETWORK client-net
    MASK 10.0.1.0/24
    GATEWAY 10.0.1.254

NETWORK external-net
    MASK 10.0.2.0/24
    GATEWAY 10.0.2.254

CONTAINER client
    USER ubuntu
    PASSWORD ubuntu
    TERMINALS 1
    SCRIPT NONE
    client-net 10.0.1.100
    LAB GATEWAY 10.0.1.1

CONTAINER gateway
    USER ubuntu
    PASSWORD ubuntu
    TERMINALS 1
    SCRIPT NONE
    client-net 10.0.1.1
    external-net 10.0.2.1

CONTAINER vpn-server
    USER ubuntu
    PASSWORD ubuntu
    TERMINALS 0
    SCRIPT NONE
    external-net 10.0.2.10
    LAB GATEWAY 10.0.2.1

CONTAINER web-server
    USER ubuntu
    PASSWORD ubuntu
    TERMINALS 0
    SCRIPT NONE
    external-net 10.0.2.20
    LAB GATEWAY 10.0.2.1
````

## `dockerfiles/Dockerfile.vpn-fingerprint_openvpn-basic.client.student`

````dockerfile
# Labtainer Dockerfile for vpn-fingerprint_openvpn-basic.client.student
ARG registry
FROM $registry/labtainer.network2
ARG lab labdir imagedir user_name password apt_source
ADD $labdir/$imagedir/sys_tar/sys.tar /
ADD $labdir/sys_$lab.tar.gz /
RUN useradd -ms /bin/bash "$user_name" && \
    echo "$user_name:$password" | chpasswd && \
    adduser "$user_name" sudo
RUN apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
      openvpn curl iproute2 iptables iputils-ping ca-certificates \
    && rm -rf /var/lib/apt/lists/*
USER $user_name
ENV HOME /home/$user_name
ADD $labdir/$imagedir/home_tar/home.tar $HOME
RUN rm -f $HOME/home.tar
ADD $labdir/$lab.tar.gz $HOME
USER root
RUN mkdir -p /etc/openvpn && \
    chmod 700 /etc/openvpn && \
    chown -R ubuntu:ubuntu /home/ubuntu
ADD $labdir/scripts/client.ovpn /home/ubuntu/client.ovpn
ADD $labdir/scripts/vpn-static.key /etc/openvpn/static.key
RUN chmod 600 /etc/openvpn/static.key && \
    chown ubuntu:ubuntu /home/ubuntu/client.ovpn && \
    chmod 644 /home/ubuntu/client.ovpn
CMD ["/bin/bash", "-c", "exec /sbin/init --log-target=journal 3>&1"]
````

## `dockerfiles/Dockerfile.vpn-fingerprint_openvpn-basic.gateway.student`

````dockerfile
# Labtainer Dockerfile for vpn-fingerprint_openvpn-basic.gateway.student
ARG registry
FROM $registry/labtainer.network2
ARG lab labdir imagedir user_name password apt_source
ADD $labdir/$imagedir/sys_tar/sys.tar /
ADD $labdir/sys_$lab.tar.gz /
RUN useradd -ms /bin/bash "$user_name" && \
    echo "$user_name:$password" | chpasswd && \
    adduser "$user_name" sudo
RUN apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
      tcpdump tshark python3 iproute2 iptables iputils-ping ca-certificates \
    && rm -rf /var/lib/apt/lists/*
USER $user_name
ENV HOME /home/$user_name
ADD $labdir/$imagedir/home_tar/home.tar $HOME
RUN rm -f $HOME/home.tar
ADD $labdir/$lab.tar.gz $HOME
USER root
ADD $labdir/scripts/gateway-startup.sh /usr/local/sbin/gateway-startup.sh
ADD $labdir/scripts/vpn-fingerprint-gateway.service /etc/systemd/system/vpn-fingerprint-gateway.service
ADD $labdir/scripts/detect_openvpn.py /home/ubuntu/detect_openvpn.py
ADD $labdir/scripts/evaluate.py /home/ubuntu/evaluate.py
RUN chmod 755 /usr/local/sbin/gateway-startup.sh /home/ubuntu/detect_openvpn.py /home/ubuntu/evaluate.py && \
    mkdir -p /etc/systemd/system/multi-user.target.wants /home/ubuntu && \
    ln -sf /etc/systemd/system/vpn-fingerprint-gateway.service /etc/systemd/system/multi-user.target.wants/vpn-fingerprint-gateway.service && \
    chown -R ubuntu:ubuntu /home/ubuntu
CMD ["/bin/bash", "-c", "exec /sbin/init --log-target=journal 3>&1"]
````

## `dockerfiles/Dockerfile.vpn-fingerprint_openvpn-basic.vpn-server.student`

````dockerfile
# Labtainer Dockerfile for vpn-fingerprint_openvpn-basic.vpn-server.student
ARG registry
FROM $registry/labtainer.network2
ARG lab labdir imagedir user_name password apt_source
ADD $labdir/$imagedir/sys_tar/sys.tar /
ADD $labdir/sys_$lab.tar.gz /
RUN useradd -ms /bin/bash "$user_name" && \
    echo "$user_name:$password" | chpasswd && \
    adduser "$user_name" sudo
RUN apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
      openvpn iproute2 iptables iputils-ping ca-certificates \
    && rm -rf /var/lib/apt/lists/*
USER $user_name
ENV HOME /home/$user_name
ADD $labdir/$imagedir/home_tar/home.tar $HOME
RUN rm -f $HOME/home.tar
ADD $labdir/$lab.tar.gz $HOME
USER root
RUN mkdir -p /etc/openvpn /var/log/openvpn /dev/net
ADD $labdir/scripts/vpn-startup.sh /usr/local/sbin/vpn-startup.sh
ADD $labdir/scripts/vpn-fingerprint-openvpn.service /etc/systemd/system/vpn-fingerprint-openvpn.service
ADD $labdir/scripts/openvpn-server.conf /etc/openvpn/server.conf
ADD $labdir/scripts/vpn-static.key /etc/openvpn/static.key
RUN chmod 755 /usr/local/sbin/vpn-startup.sh && \
    chmod 600 /etc/openvpn/static.key && \
    mkdir -p /etc/systemd/system/multi-user.target.wants && \
    ln -sf /etc/systemd/system/vpn-fingerprint-openvpn.service /etc/systemd/system/multi-user.target.wants/vpn-fingerprint-openvpn.service
CMD ["/bin/bash", "-c", "exec /sbin/init --log-target=journal 3>&1"]
````

## `dockerfiles/Dockerfile.vpn-fingerprint_openvpn-basic.web-server.student`

````dockerfile
# Labtainer Dockerfile for vpn-fingerprint_openvpn-basic.web-server.student
ARG registry
FROM $registry/labtainer.network2
ARG lab labdir imagedir user_name password apt_source
ADD $labdir/$imagedir/sys_tar/sys.tar /
ADD $labdir/sys_$lab.tar.gz /
RUN useradd -ms /bin/bash "$user_name" && \
    echo "$user_name:$password" | chpasswd && \
    adduser "$user_name" sudo
RUN apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
      nginx curl iproute2 iputils-ping ca-certificates \
    && rm -rf /var/lib/apt/lists/*
USER $user_name
ENV HOME /home/$user_name
ADD $labdir/$imagedir/home_tar/home.tar $HOME
RUN rm -f $HOME/home.tar
ADD $labdir/$lab.tar.gz $HOME
USER root
ADD $labdir/scripts/web-startup.sh /usr/local/sbin/web-startup.sh
ADD $labdir/scripts/vpn-fingerprint-web.service /etc/systemd/system/vpn-fingerprint-web.service
ADD $labdir/scripts/index.html /var/www/html/index.html
RUN chmod 755 /usr/local/sbin/web-startup.sh && \
    mkdir -p /etc/systemd/system/multi-user.target.wants && \
    rm -f /etc/systemd/system/multi-user.target.wants/nginx.service && \
    ln -sf /etc/systemd/system/vpn-fingerprint-web.service /etc/systemd/system/multi-user.target.wants/vpn-fingerprint-web.service
CMD ["/bin/bash", "-c", "exec /sbin/init --log-target=journal 3>&1"]
````

## `instr_config/results.config`

````text
# Labtainers instructor-side automated result parsing.
# evaluate.py prints the matching markers in one invocation, so the boolean
# results below are all associated with the evaluation output artifact.
_baseline_ok = gateway:*.stdout : CONTAINS : BASELINE_EXPECTED_NO_OPENVPN
_vpn_ok = gateway:*.stdout : CONTAINS : VPN_EXPECTED_OPENVPN
_eval_pass = gateway:*.stdout : CONTAINS : LAB1_RESULT_PASS
````

## `instr_config/goals.config`

````text
# One automatically assessed goal: both PCAP classes must be classified correctly.
# The three result tags are generated by the same evaluate.py invocation.
correct_detection = boolean : ( _baseline_ok and _vpn_ok and _eval_pass )
````

## `scripts/gateway-startup.sh`

````bash
#!/usr/bin/env bash
set -Eeuo pipefail

log() { printf '[gateway-startup] %s\n' "$*"; }
interface_for_ip() {
  local wanted="$1" attempt iface addr
  for attempt in $(seq 1 30); do
    while read -r iface addr; do
      if [[ "$addr" == "$wanted"/* ]]; then
        printf '%s\n' "$iface"
        return 0
      fi
    done < <(ip -o -4 addr show | awk '{print $2, $4}')
    sleep 1
  done
  return 1
}

CLIENT_IF="$(interface_for_ip 10.0.1.1)" || { log 'Không tìm thấy interface 10.0.1.1'; exit 1; }
EXTERNAL_IF="$(interface_for_ip 10.0.2.1)" || { log 'Không tìm thấy interface 10.0.2.1'; exit 1; }

sysctl -w net.ipv4.ip_forward=1
sysctl -w net.ipv4.conf.all.rp_filter=0 || true
iptables -P FORWARD ACCEPT
iptables -F FORWARD
iptables -A FORWARD -i "$CLIENT_IF" -o "$EXTERNAL_IF" -s 10.0.1.0/24 -d 10.0.2.0/24 -j ACCEPT
iptables -A FORWARD -i "$EXTERNAL_IF" -o "$CLIENT_IF" -s 10.0.2.0/24 -d 10.0.1.0/24 -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
log "Router ready: $CLIENT_IF (10.0.1.1) <-> $EXTERNAL_IF (10.0.2.1)"
log 'Forwarding enabled; no NAT is used on this router so packet sources remain visible.'
````

## `scripts/vpn-startup.sh`

````bash
#!/usr/bin/env bash
set -Eeuo pipefail
log() { printf '[vpn-startup] %s\n' "$*"; }

# The Labtainer VM normally exposes /dev/net/tun to privileged lab containers.
# Create the device node only if the base image did not provide it.
mkdir -p /dev/net
if [[ ! -c /dev/net/tun ]]; then
  mknod /dev/net/tun c 10 200 || { log 'Không tạo được /dev/net/tun; kiểm tra quyền/capability của container.'; exit 1; }
  chmod 600 /dev/net/tun
fi

sysctl -w net.ipv4.ip_forward=1
EXTERNAL_IF=''
for attempt in $(seq 1 30); do
  EXTERNAL_IF="$(ip -o -4 addr show | awk '$4 ~ /^10\.0\.2\.10\// {print $2; exit}')"
  [[ -n "$EXTERNAL_IF" ]] && break
  sleep 1
done
[[ -n "$EXTERNAL_IF" ]] || { log 'Không tìm thấy interface có IP 10.0.2.10'; exit 1; }

iptables -P FORWARD ACCEPT
iptables -A FORWARD -i tun0 -o "$EXTERNAL_IF" -s 10.8.0.0/24 -d 10.0.2.0/24 -j ACCEPT
iptables -A FORWARD -i "$EXTERNAL_IF" -o tun0 -d 10.8.0.0/24 -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
iptables -t nat -C POSTROUTING -s 10.8.0.0/24 -o "$EXTERNAL_IF" -j MASQUERADE 2>/dev/null || \
  iptables -t nat -A POSTROUTING -s 10.8.0.0/24 -o "$EXTERNAL_IF" -j MASQUERADE
log "Starting OpenVPN on 10.0.2.10/UDP 1194 using $EXTERNAL_IF"
exec /usr/sbin/openvpn --config /etc/openvpn/server.conf
````

## `scripts/web-startup.sh`

````bash
#!/usr/bin/env bash
set -Eeuo pipefail
/usr/sbin/nginx -t
exec /usr/sbin/nginx -g 'daemon off;'
````

## `scripts/openvpn-server.conf`

````text
# LAB ONLY: minimal OpenVPN static-key server.
local 10.0.2.10
port 1194
proto udp
dev tun0
secret /etc/openvpn/static.key
ifconfig 10.8.0.1 10.8.0.2
persist-key
persist-tun
ping 10
ping-restart 60
verb 3
status /var/log/openvpn-status.log
````

## `scripts/client.ovpn`

````text
# LAB ONLY: OpenVPN static-key tunnel for a local training network.
# The remote server route stays outside the tunnel; other 10.0.2.0/24 traffic
# is sent through tun0 to make HTTP visible only as encrypted UDP at gateway.
proto udp
remote 10.0.2.10 1194
nobind
dev tun0
secret /etc/openvpn/static.key
ifconfig 10.8.0.2 10.8.0.1
persist-key
persist-tun
route 10.0.2.10 255.255.255.255 net_gateway
route 10.0.2.0 255.255.255.0 10.8.0.1
ping 10
ping-restart 60
verb 3
````

## `scripts/detect_openvpn.py`

````python
#!/usr/bin/env python3
"""Rule-based OpenVPN UDP fingerprint detector for the Labtainer exercise.

Students are expected to edit only the configuration constants below.
This is an educational heuristic, not a production-grade VPN detector.
"""
from __future__ import annotations
import argparse
import json
import os
import subprocess
import sys
from typing import Any

# ---------------------------------------------------------------------------
# STUDENT CONFIGURATION: the initial values are intentionally incorrect.
# Use tshark to inspect vpn-traffic.pcap, then tune these four values.
# ---------------------------------------------------------------------------
VPN_UDP_PORT = 1195          # TODO: determine from the captured traffic
MIN_FRAME_SIZE = 100         # inclusive lower bound in bytes
MAX_FRAME_SIZE = 1000        # inclusive upper bound in bytes
MIN_MATCHING_PACKETS = 999   # TODO: lower this based on observed packet counts
# ---------------------------------------------------------------------------


def read_udp_packets(pcap_path: str) -> list[dict[str, Any]]:
    if not os.path.isfile(pcap_path):
        raise FileNotFoundError(f"Không tìm thấy PCAP: {pcap_path}")
    command = [
        "tshark", "-n", "-r", pcap_path, "-Y", "udp",
        "-T", "fields", "-E", "separator=\\t", "-E", "occurrence=f",
        "-e", "frame.len", "-e", "udp.srcport", "-e", "udp.dstport",
    ]
    completed = subprocess.run(command, capture_output=True, text=True, check=False)
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout).strip()
        raise RuntimeError(f"tshark không đọc được PCAP. Chi tiết: {detail}")
    packets: list[dict[str, Any]] = []
    for line in completed.stdout.splitlines():
        fields = line.split("\t")
        if len(fields) < 3:
            continue
        try:
            frame_len = int(fields[0])
            src_port = int(fields[1])
            dst_port = int(fields[2])
        except (ValueError, IndexError):
            continue
        packets.append({"frame_len": frame_len, "src_port": src_port, "dst_port": dst_port})
    return packets


def detect_pcap(pcap_path: str, verbose: bool = False) -> dict[str, Any]:
    if VPN_UDP_PORT < 1 or VPN_UDP_PORT > 65535:
        raise ValueError("VPN_UDP_PORT phải nằm trong khoảng 1..65535")
    if MIN_FRAME_SIZE < 0 or MAX_FRAME_SIZE < MIN_FRAME_SIZE:
        raise ValueError("Khoảng frame size không hợp lệ")
    if MIN_MATCHING_PACKETS < 1:
        raise ValueError("MIN_MATCHING_PACKETS phải lớn hơn hoặc bằng 1")

    packets = read_udp_packets(pcap_path)
    port_packets = [p for p in packets if p["src_port"] == VPN_UDP_PORT or p["dst_port"] == VPN_UDP_PORT]
    matching_packets = [
        p for p in port_packets
        if MIN_FRAME_SIZE <= p["frame_len"] <= MAX_FRAME_SIZE
    ]
    detected = len(matching_packets) >= MIN_MATCHING_PACKETS
    result = {
        "pcap": os.path.basename(pcap_path),
        "udp_packets": len(packets),
        "port_matches": len(port_packets),
        "matched_packets": len(matching_packets),
        "port": VPN_UDP_PORT,
        "min_frame_size": MIN_FRAME_SIZE,
        "max_frame_size": MAX_FRAME_SIZE,
        "minimum_matches": MIN_MATCHING_PACKETS,
        "detected": detected,
        "classification": "OPENVPN" if detected else "NO_OPENVPN",
    }
    if verbose:
        print(f"PCAP={result['pcap']}")
        print(f"UDP_PACKETS={result['udp_packets']}")
        print(f"PORT_MATCHES={result['port_matches']}")
        print(f"MATCHED_PACKETS={result['matched_packets']}")
        print(f"RULE=port {VPN_UDP_PORT}, frame.len {MIN_FRAME_SIZE}..{MAX_FRAME_SIZE}, minimum {MIN_MATCHING_PACKETS}")
        print(f"DETECTION={result['classification']}")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Phát hiện dấu hiệu OpenVPN/UDP theo rule cấu hình.")
    parser.add_argument("pcap", help="Đường dẫn file PCAP cần phân tích")
    parser.add_argument("--json", action="store_true", help="In kết quả ở định dạng JSON")
    args = parser.parse_args()
    try:
        result = detect_pcap(args.pcap, verbose=not args.json)
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["detected"] else 1
    except (OSError, ValueError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
````

## `scripts/evaluate.py`

````python
#!/usr/bin/env python3
"""Evaluate one negative and one positive PCAP for Labtainer Checkwork."""
from __future__ import annotations
import argparse
import sys
from detect_openvpn import detect_pcap


def percentage(numerator: int, denominator: int) -> float:
    return (100.0 * numerator / denominator) if denominator else 0.0


def main() -> int:
    parser = argparse.ArgumentParser(description="Tính confusion matrix, precision và recall.")
    parser.add_argument("baseline_pcap", nargs="?", default="baseline.pcap")
    parser.add_argument("vpn_pcap", nargs="?", default="vpn-traffic.pcap")
    args = parser.parse_args()
    try:
        baseline = detect_pcap(args.baseline_pcap)
        vpn = detect_pcap(args.vpn_pcap)
    except (OSError, ValueError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        print("Hãy tạo baseline.pcap và vpn-traffic.pcap, sau đó kiểm tra tshark và tham số trong detect_openvpn.py.")
        return 2

    # File-level labels: baseline is negative; VPN capture is positive.
    fp = 1 if baseline["detected"] else 0
    tn = 1 - fp
    tp = 1 if vpn["detected"] else 0
    fn = 1 - tp
    precision = percentage(tp, tp + fp)
    recall = percentage(tp, tp + fn)
    accuracy = percentage(tp + tn, 2)

    print("=== LAB 1 EVALUATION ===")
    print(f"BASELINE_CLASSIFICATION={baseline['classification']}")
    print(f"VPN_CLASSIFICATION={vpn['classification']}")
    print(f"TP={tp} FP={fp} TN={tn} FN={fn}")
    print(f"PRECISION={precision:.2f}%")
    print(f"RECALL={recall:.2f}%")
    print(f"ACCURACY={accuracy:.2f}%")

    baseline_ok = not baseline["detected"]
    vpn_ok = vpn["detected"]
    if baseline_ok:
        print("BASELINE_EXPECTED_NO_OPENVPN")
    else:
        print("BASELINE_EXPECTED_NO_OPENVPN_MISSING")
    if vpn_ok:
        print("VPN_EXPECTED_OPENVPN")
    else:
        print("VPN_EXPECTED_OPENVPN_MISSING")

    if baseline_ok and vpn_ok:
        print("LAB1_RESULT_PASS")
        print("KẾT LUẬN: Phân biệt đúng cả baseline HTTP và lưu lượng có dấu hiệu OpenVPN trong bộ PCAP của bài lab.")
        return 0
    print("LAB1_RESULT_FAIL")
    print("KẾT LUẬN: Chưa phân loại đúng cả hai PCAP; hãy xem PORT_MATCHES, MATCHED_PACKETS và kiểm tra lại các ngưỡng.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
````

## `scripts/vpn-fingerprint-gateway.service`

````text
[Unit]
Description=VPN fingerprint lab router setup
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/gateway-startup.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
````

## `scripts/vpn-fingerprint-openvpn.service`

````text
[Unit]
Description=OpenVPN lab server (UDP 1194)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/local/sbin/vpn-startup.sh
Restart=on-failure
RestartSec=2

[Install]
WantedBy=multi-user.target
````

## `scripts/vpn-fingerprint-web.service`

````text
[Unit]
Description=HTTP web server for VPN fingerprint lab
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/local/sbin/web-startup.sh
Restart=on-failure
RestartSec=2

[Install]
WantedBy=multi-user.target
````

## `scripts/index.html`

````html
<!doctype html>
<html lang="vi">
<head><meta charset="utf-8"><title>VPN Fingerprint Lab</title></head>
<body>
<h1>VPN Fingerprint Lab</h1>
<p>HTTP server nội bộ hoạt động bình thường.</p>
<p>Thông điệp kiểm thử: WEB_SERVER_OK</p>
</body>
</html>
````

## `scripts/validate-source.sh`

````bash
#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LAB='vpn-fingerprint_openvpn-basic'
for c in client gateway vpn-server web-server; do
  f="$ROOT/dockerfiles/Dockerfile.$LAB.$c.student"
  test -s "$f" || { echo "MISSING $f"; exit 1; }
done
bash -n "$ROOT/scripts/gateway-startup.sh" "$ROOT/scripts/vpn-startup.sh" "$ROOT/scripts/web-startup.sh"
python3 -m py_compile "$ROOT/scripts/detect_openvpn.py" "$ROOT/scripts/evaluate.py"
test -s "$ROOT/config/start.config"
test -s "$ROOT/instr_config/results.config"
test -s "$ROOT/instr_config/goals.config"
echo 'SOURCE_VALIDATION_PASS'
echo 'Note: this is not a Docker/Labtainer runtime test.'
````

## `docs/student-guide.md`

````markdown
# HƯỚNG DẪN THỰC HÀNH LAB 1

## Phát hiện dấu hiệu OpenVPN từ gateway

**Tên lab:** `vpn-fingerprint_openvpn-basic`  
**Thời lượng:** 60 phút  
**Đối tượng:** Sinh viên ATTT năm 3-4; biết Linux và Python cơ bản.  
**Môi trường:** Labtainers trên Ubuntu; bốn container và hai subnet riêng.

## 1. Mục tiêu

Sau khi hoàn thành, sinh viên có thể thu thập hai bộ PCAP tại gateway, dùng `tshark` kiểm tra cổng UDP và kích thước frame, điều chỉnh tham số có sẵn trong `detect_openvpn.py`, rồi đánh giá kết quả bằng precision và recall. Không cần tự viết script phát hiện từ đầu.

## 2. Sơ đồ mạng

| Container | Địa chỉ | Vai trò |
|---|---|---|
| `client` | `10.0.1.100` | Tạo HTTP thường hoặc kết nối OpenVPN |
| `gateway` | `10.0.1.1`, `10.0.2.1` | Router, điểm thu thập PCAP, cài `tcpdump` và `tshark` |
| `vpn-server` | `10.0.2.10` | OpenVPN qua UDP/1194 |
| `web-server` | `10.0.2.20` | Máy chủ HTTP port 80 |

`client-net`: `10.0.1.0/24`. `external-net`: `10.0.2.0/24`.

> Các khóa và cấu hình VPN trong bài chỉ dùng trong mạng lab biệt lập, không dùng cho hệ thống thật.

## 3. Khởi động và kiểm tra dịch vụ (5 phút)

Trên terminal Labtainers host, chạy:

```bash
cd "$LABTAINER_DIR/scripts/labtainer-student"
labtainer vpn-fingerprint_openvpn-basic
```

Trong terminal của `client`:

```bash
ip -br addr
ip route
curl -i --max-time 5 http://10.0.2.20/
```

Trang HTTP phải trả về nội dung chứa `WEB_SERVER_OK`. Trong terminal `gateway`:

```bash
ip -br addr
ip route
sudo systemctl status vpn-fingerprint-gateway --no-pager
sudo tcpdump --version
 tshark --version | head -n 2
```

Nếu `sudo` hỏi mật khẩu, mật khẩu được cấu hình trong lab là `ubuntu`.

## 4. Thu baseline HTTP (10 phút)

**Bước A - gateway:** khởi động thu thập trong 25 giây:

```bash
sudo timeout 25s tcpdump -i any -nn -U \
  '(tcp port 80 or udp port 1194)' \
  -w /home/ubuntu/baseline.pcap
```

Trong khi lệnh đang chạy, chuyển sang terminal `client` và tạo nhiều yêu cầu HTTP:

```bash
for i in $(seq 1 10); do curl -sS --max-time 3 http://10.0.2.20/ >/dev/null; sleep 0.3; done
echo BASELINE_HTTP_GENERATED
```

Đợi tcpdump kết thúc. Kiểm tra trên `gateway`:

```bash
ls -lh /home/ubuntu/baseline.pcap
sudo tshark -r /home/ubuntu/baseline.pcap -q -z io,phs
```

## 5. Thu lưu lượng OpenVPN (15 phút)

**Bước A - client:** khởi động OpenVPN ở chế độ daemon:

```bash
sudo openvpn --config /home/ubuntu/client.ovpn \
  --daemon --writepid /tmp/openvpn-client.pid \
  --log /tmp/openvpn-client.log
sleep 2
ip addr show tun0
ip route get 10.0.2.20
```

Kiểm tra HTTP vẫn truy cập được qua tunnel:

```bash
curl -i --max-time 5 http://10.0.2.20/
```

Nếu tunnel chưa lên, xem `/tmp/openvpn-client.log`; không tiếp tục thu PCAP cho đến khi sửa xong.

**Bước B - gateway:** chạy lệnh dưới đây; khi tcpdump bắt đầu thì chuyển sang `client`:

```bash
sudo timeout 25s tcpdump -i any -nn -U \
  '(tcp port 80 or udp port 1194)' \
  -w /home/ubuntu/vpn-traffic.pcap
```

Trên `client`, tạo yêu cầu HTTP qua tunnel:

```bash
for i in $(seq 1 10); do curl -sS --max-time 3 http://10.0.2.20/ >/dev/null; sleep 0.3; done
echo VPN_HTTP_GENERATED
```

Khi tcpdump kết thúc, dừng VPN ở `client`:

```bash
sudo kill "$(cat /tmp/openvpn-client.pid)"
```

## 6. Phân tích với tshark (10 phút)

Các lệnh sau chạy trong terminal `gateway`:

```bash
sudo tshark -r /home/ubuntu/baseline.pcap -Y tcp -T fields \
  -e frame.len -e ip.src -e ip.dst -e tcp.srcport -e tcp.dstport | head -n 20
sudo tshark -r /home/ubuntu/vpn-traffic.pcap -Y udp -T fields \
  -e frame.len -e ip.src -e ip.dst -e udp.srcport -e udp.dstport | head -n 30
sudo tshark -r /home/ubuntu/vpn-traffic.pcap -Y 'udp.port == 1194' -T fields \
  -e frame.len -e udp.srcport -e udp.dstport | head -n 30
```

Ghi lại: số gói UDP, cổng UDP nguồn/đích, khoảng kích thước frame thường gặp và khác biệt giữa hai PCAP. Ở baseline, HTTP chủ yếu là TCP/80. Ở capture VPN, gateway nhìn thấy phiên UDP/1194 giữa client và VPN server; lưu lượng HTTP bên trong tunnel không xuất hiện như phiên TCP/80 đi trực tiếp từ client đến web-server.

## 7. Điều chỉnh rule và đánh giá (10 phút)

Mở `/home/ubuntu/detect_openvpn.py` trên `gateway` bằng editor có sẵn, ví dụ:

```bash
nano /home/ubuntu/detect_openvpn.py
```

Chỉ sửa bốn hằng số ở đầu file dựa trên số liệu PCAP:

```python
VPN_UDP_PORT = 1195
MIN_FRAME_SIZE = 100
MAX_FRAME_SIZE = 1000
MIN_MATCHING_PACKETS = 999
```

Yêu cầu: cổng đúng theo PCAP; dải kích thước bao phủ các gói phù hợp; ngưỡng số gói không được cao hơn số quan sát được của một capture VPN hợp lệ và vẫn đủ cao để tránh kết luận chỉ từ một gói đơn lẻ. Giữ nguyên phần logic bên dưới.

Chạy lần lượt:

```bash
cd /home/ubuntu
python3 detect_openvpn.py baseline.pcap
python3 detect_openvpn.py vpn-traffic.pcap
python3 evaluate.py baseline.pcap vpn-traffic.pcap
```

Kết quả mong muốn:

- `baseline.pcap` -> `DETECTION=NO_OPENVPN`
- `vpn-traffic.pcap` -> `DETECTION=OPENVPN`
- `evaluate.py` -> `TP=1 FP=0 TN=1 FN=0`, precision 100%, recall 100%, và `LAB1_RESULT_PASS`.

Các metric ở đây tính trên **hai file kiểm thử** được gán nhãn sẵn, dùng để kiểm tra bài lab; không đại diện cho hiệu năng của bộ phát hiện trên mọi loại lưu lượng thực tế.

## 8. Câu hỏi cuối bài (5 phút)

1. Những trường nào trong đầu ra `tshark` giúp phân biệt hai capture?
2. Vì sao gateway nhìn thấy UDP/1194 nhưng không thấy HTTP của client dưới dạng TCP/80 trực tiếp khi dùng tunnel?
3. `MIN_MATCHING_PACKETS` quá thấp có thể gây vấn đề gì? Quá cao thì sao?
4. Vì sao phát hiện theo port và packet size không đủ để kết luận chắc chắn mọi lưu lượng đó đều là OpenVPN?
5. Nêu một trường hợp sử dụng VPN hợp lệ trong doanh nghiệp và giải thích vì sao cần đối chiếu với chính sách thay vì tự động kết luận vi phạm.

## 9. Nộp bài và Checkwork

Trên terminal host Labtainers:

```bash
stoplab vpn-fingerprint_openvpn-basic
```

Ghi lại vị trí file ZIP kết quả do Labtainers in ra. Sau đó chạy:

```bash
checkwork vpn-fingerprint_openvpn-basic
```

Nếu phiên bản Labtainers không hỗ trợ `checkwork` tại student side, dùng `stoplab` để đóng gói kết quả và yêu cầu giảng viên kiểm tra bằng công cụ instructor tương ứng.

## 10. Khắc phục nhanh

- HTTP không truy cập được: kiểm tra trạng thái `vpn-fingerprint-web`, IP của web-server, route từ client và route forwarding ở gateway.
- VPN không lên: kiểm tra log `/tmp/openvpn-client.log`, log server bằng `sudo journalctl -u vpn-fingerprint-openvpn --no-pager -n 50`, port UDP/1194 và thiết bị `/dev/net/tun`.
- PCAP rỗng: đảm bảo tcpdump đã chạy trước vòng lặp `curl`; xác nhận interface `any` và đường dẫn file.
- `tshark` không đọc được: kiểm tra `sudo tshark -r <file.pcap> -q` và tên file.
- Detection không khớp: xem `PORT_MATCHES`, `MATCHED_PACKETS`, rồi chỉnh port, frame-size và minimum threshold.
- Checkwork chưa đạt: chạy `evaluate.py` cho cả hai file, xác nhận marker `LAB1_RESULT_PASS`, sau đó mới `stoplab`/`checkwork`.
````

## `docs/LABEDIT-GUI.md`

````markdown
# Tạo/cấu hình bằng Labedit GUI

> Tên nút thay đổi theo phiên bản Labtainers. Các mục dưới đây mô tả trường thông tin cần cấu hình; đối chiếu với Labedit đã cài. Hướng dẫn chính thức xác nhận dữ liệu cấu hình cuối cùng nằm ở `config/start.config`; Dockerfile và Results có cấu trúc riêng.

1. Trên Ubuntu VM, mở terminal trong môi trường Labtainers và chạy `labedit`.
2. Chọn chức năng tạo lab mới (thường là **New Lab** hoặc **Create Lab**). Điền tên `vpn-fingerprint_openvpn-basic` (chữ thường, không có khoảng trắng). Không ghi đè lab mẫu `cryp-attk-rsa_fermat`.
3. Trong màn hình **Containers/Computers**, tạo lần lượt `client`, `gateway`, `vpn-server`, `web-server`.
   - Tất cả: user `ubuntu`, script `NONE` để dùng `/sbin/init` trong image `labtainer.network2`.
   - `client`: `TERMINALS 1`.
   - `gateway`: `TERMINALS 1`.
   - `vpn-server`, `web-server`: `TERMINALS 0`.
4. Trong **Networks**, tạo `client-net`, mask `10.0.1.0/24`, network gateway `10.0.1.254`; tạo `external-net`, mask `10.0.2.0/24`, network gateway `10.0.2.254`. Các IP `.254` là gateway của bridge Labtainer, không phải router mô phỏng.
5. Gán IP mỗi container:
   - `client`: `client-net 10.0.1.100`, **LAB GATEWAY** `10.0.1.1`.
   - `gateway`: `client-net 10.0.1.1`, `external-net 10.0.2.1`; không đặt **LAB GATEWAY** cho router hai giao diện.
   - `vpn-server`: `external-net 10.0.2.10`, **LAB GATEWAY** `10.0.2.1`.
   - `web-server`: `external-net 10.0.2.20`, **LAB GATEWAY** `10.0.2.1`.
6. Lưu lab. Đóng Labedit, sao chép nội dung thư mục trong gói ZIP vào `$LABTAINER_DIR/labs/vpn-fingerprint_openvpn-basic/`, cho phép ghi đè các tệp mẫu vừa tạo. Giữ tên Dockerfile `Dockerfile.vpn-fingerprint_openvpn-basic.<container>.student`.
7. Mở `config/start.config`, xác nhận Labedit đã lưu đúng hai network, bốn container và IP. Dùng phiên bản hoàn chỉnh trong gói nếu trường GUI không hỗ trợ tất cả các tùy chọn.
8. Với bản Labtainers dùng cấu hình instructor hiện đại, kiểm tra `instr_config/results.config` và `instr_config/goals.config`. Bản phát hành cũ có thể có màn hình Results riêng; nếu GUI tạo một tệp `results.dat`, đừng giả định file đó được bản Labtainers hiện tại đọc tự động. Giữ nguyên cấu hình `instr_config` và xác thực bằng `checklab.py`/`gradelab`.
9. Build và smoke-test theo `README.md`. Nếu build thất bại ngay ở bước ADD một archive rỗng, chạy công cụ setup/rebuild của bản Labtainers đã cài để tạo lại các archive trong từng container rồi chạy `rebuild -f vpn-fingerprint_openvpn-basic`.

## Những điều cần xác minh theo bản cài [CẦN KIỂM TRA]

- Nhãn/nút chính xác trong cửa sổ Labedit.
- Lệnh và đường dẫn đầy đủ để gọi `labedit` trên VM của trường.
- Phiên bản Labtainers có đọc `instr_config/results.config`/`goals.config` hay dùng cấu hình Results cũ. Kiểm tra cấu trúc của lab mẫu sẵn có và lệnh `checklab.py` trong thư mục instructor.
````

## `docs/INSTRUCTOR-TEST.md`

````markdown
# Instructor smoke test / kiểm tra trước khi phát hành

## Kiểm tra cú pháp mã nguồn (host Labtainers VM)

```bash
cd "$LABTAINER_DIR/labs/vpn-fingerprint_openvpn-basic"
bash -n scripts/gateway-startup.sh scripts/vpn-startup.sh scripts/web-startup.sh
python3 -m py_compile scripts/detect_openvpn.py scripts/evaluate.py
```

## Kiểm tra cấu trúc Labtainer (host Labtainers VM)

```bash
cd "$LABTAINER_DIR/scripts/labtainer-instructor"
python3 ../../scripts/designer/bin/checklab.py vpn-fingerprint_openvpn-basic
```

Đường dẫn script kiểm tra có thể khác theo bản Labtainers; tìm `checklab.py` dưới `$LABTAINER_DIR/scripts/labtainer-instructor/bin/` nếu lệnh trên không tồn tại.

## Build sạch (host Labtainers VM)

```bash
cd "$LABTAINER_DIR/scripts/labtainer-student"
rebuild -f vpn-fingerprint_openvpn-basic
```

## Smoke test (terminal container)

```bash
# gateway
ip -br addr
sudo systemctl status vpn-fingerprint-gateway --no-pager
sudo tcpdump -D
sudo tshark --version | head -n 2

# vpn-server, từ host Labtainers VM nếu server không mở terminal
# Thay <container-id> bằng đúng tên container đang chạy:
docker ps --format 'table {{.Names}}\t{{.Status}}'
docker exec <container-id> systemctl status vpn-fingerprint-openvpn --no-pager

# web-server
docker exec <web-container-id> curl -I http://10.0.2.20/
```

## Chấm thử

1. Chạy lab như sinh viên, tạo đủ `baseline.pcap` và `vpn-traffic.pcap`.
2. Cập nhật các tham số trong `detect_openvpn.py` để tạo ra `DETECTION=NO_OPENVPN` trên baseline và `DETECTION=OPENVPN` trên capture VPN.
3. Chạy `python3 evaluate.py baseline.pcap vpn-traffic.pcap` trên gateway, xác nhận có marker `LAB1_RESULT_PASS`.
4. Chạy `stoplab`, sau đó dùng công cụ instructor tương ứng để grading. Nếu goal vẫn false, mở artifact stdout trong thư mục kết quả sinh viên và xác minh parser có nhận `gateway:*.stdout` ở bản hiện tại hay không.

**Giới hạn xác minh:** bộ mã nguồn này được dựng theo quy ước tài liệu Labtainer và được kiểm tra cú pháp. Môi trường tạo file hiện tại không có Docker/Labtainer chạy được nên chưa thể xác nhận build end-to-end trên VM của bạn. Bước smoke test trên là bắt buộc trước khi dùng để chấm sinh viên.
````

## `README.md`

````markdown
# vpn-fingerprint_openvpn-basic

Labtainers lab: phát hiện dấu hiệu OpenVPN/UDP bằng rule dựa trên packet fingerprint ở gateway.

## Lưu ý về tính tương thích

Gói này dùng cấu trúc Labtainer hiện đại: `config/start.config`, bốn Dockerfile theo tên `Dockerfile.<lab>.<container>.student`, và cấu hình instructor ở `instr_config/`. Các archive `.tar` rỗng được đưa vào làm placeholder để source tree có đủ tên tệp mà Dockerfile chuẩn tham chiếu; nếu Labedit/setup của bản cài sinh lại archive thì để Labtainers quản lý chúng.

## Cài vào Labtainers

```bash
# Host Labtainers VM
unzip vpn-fingerprint_openvpn-basic.zip -d "$LABTAINER_DIR/labs"
cd "$LABTAINER_DIR/scripts/labtainer-student"
rebuild -f vpn-fingerprint_openvpn-basic
labtainer vpn-fingerprint_openvpn-basic
```

Nếu bạn mở Labedit để tạo lab thủ công, xem `docs/LABEDIT-GUI.md`. Không ghi đè lab `cryp-attk-rsa_fermat`.

## Tạo PCAP và đánh giá

- Capture baseline: tại terminal `gateway`, ghi `/home/ubuntu/baseline.pcap`; trong lúc tcpdump chạy, chạy vòng lặp `curl` từ `client`.
- Capture VPN: khởi động OpenVPN tại `client`, chạy cùng vòng lặp `curl` và ghi `/home/ubuntu/vpn-traffic.pcap` từ `gateway`.
- Trên `gateway`, dùng `tshark` để xem UDP port/frame length, sau đó sửa bốn hằng số ở đầu `/home/ubuntu/detect_openvpn.py`.
- Chạy `python3 /home/ubuntu/evaluate.py /home/ubuntu/baseline.pcap /home/ubuntu/vpn-traffic.pcap`.

Chi tiết đầy đủ trong `docs/student-guide.md` và `docs/INSTRUCTOR-TEST.md`.

## Build / kiểm tra

```bash
cd "$LABTAINER_DIR/labs/vpn-fingerprint_openvpn-basic"
bash -n scripts/gateway-startup.sh scripts/vpn-startup.sh scripts/web-startup.sh
python3 -m py_compile scripts/detect_openvpn.py scripts/evaluate.py
cd "$LABTAINER_DIR/scripts/labtainer-student"
rebuild -f vpn-fingerprint_openvpn-basic
```

Để kiểm tra phần chấm điểm, sử dụng `docs/INSTRUCTOR-TEST.md`. Docker/Labtainer runtime chưa có trong môi trường tạo gói hiện tại, vì vậy cần chạy smoke test trên Labtainer VM trước khi phát hành cho sinh viên.
````

## `config/README.md`

````markdown
# Cấu hình Labtainer

- `start.config`: topology, IP, gateway và terminal cho bốn container.
- `instr_config/results.config` và `instr_config/goals.config`: cấu hình Checkwork theo quy ước Labtainers hiện đại.
- Labtainer cũ có thể đặt dữ liệu Results trong giao diện hoặc ở đường dẫn khác. Khi đó dùng màn hình Labedit để tạo cấu hình tương ứng, nhưng không xóa bản `instr_config`.

Hai địa chỉ `10.0.1.254` và `10.0.2.254` là gateway của mạng Docker/Labtainer. Router mô phỏng thật là container `gateway` với địa chỉ `.1`; `LAB GATEWAY` đặt route mặc định cho client và máy chủ.
````

## `results/README.md`

````markdown
# Results / Checkwork

Kết quả thực tế của mỗi lượt chạy Labtainer được tạo bởi `stoplab` trong thư mục trao đổi của Labtainers (thường là `labtainer-xfer/` hoặc vị trí in ra ở cuối lệnh). Thư mục `results/` này giữ ghi chú cấu hình trong bộ mã nguồn, không phải thư mục kết quả runtime.

`instr_config/results.config` thu các marker do `evaluate.py` in ra; `instr_config/goals.config` đặt goal `correct_detection`. Đạt goal khi baseline không bị đánh dấu là VPN và PCAP VPN được phát hiện là OpenVPN.
````

## `client/README.md`

````markdown
Container source placeholder for `client`.

Files are copied into images by `dockerfiles/Dockerfile.vpn-fingerprint_openvpn-basic.client.student`; the current empty `sys_tar/sys.tar` and `home_tar/home.tar` are valid placeholders.
````

## `gateway/README.md`

````markdown
Container source placeholder for `gateway`.

Files are copied into images by `dockerfiles/Dockerfile.vpn-fingerprint_openvpn-basic.gateway.student`; the current empty `sys_tar/sys.tar` and `home_tar/home.tar` are valid placeholders.
````

## `vpn-server/README.md`

````markdown
Container source placeholder for `vpn-server`.

Files are copied into images by `dockerfiles/Dockerfile.vpn-fingerprint_openvpn-basic.vpn-server.student`; the current empty `sys_tar/sys.tar` and `home_tar/home.tar` are valid placeholders.
````

## `web-server/README.md`

````markdown
Container source placeholder for `web-server`.

Files are copied into images by `dockerfiles/Dockerfile.vpn-fingerprint_openvpn-basic.web-server.student`; the current empty `sys_tar/sys.tar` and `home_tar/home.tar` are valid placeholders.
````

## `scripts/vpn-static.key`

Tệp khóa tĩnh OpenVPN được phát sinh riêng cho bài lab. Dùng trực tiếp từ gói ZIP, không thay bằng khóa cá nhân hoặc khóa sử dụng ngoài môi trường lab.

