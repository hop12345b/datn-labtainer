# Sửa lỗi Docker ADD không tìm thấy scripts/*

Bản sửa đặt các tệp cần ADD trong từng thư mục container tại `build_assets/`, rồi dùng đường dẫn chuẩn Labtainers `$labdir/$imagedir/build_assets/<file>`. Việc này tránh phụ thuộc vào thư mục `scripts/` ở gốc build context.

## Kiểm tra trước khi build

Tại host Ubuntu:

```bash
cd "$LABTAINER_DIR/labs/vpn-fingerprint_openvpn-basic"
test -f client/build_assets/client.ovpn
test -f client/build_assets/vpn-static.key
test -f vpn-server/build_assets/openvpn-server.conf
test -f vpn-server/build_assets/vpn-static.key
test -f gateway/build_assets/detect_openvpn.py
test -f web-server/build_assets/index.html
```

Nếu các lệnh `test` đều trả về mã 0, tiếp tục build bằng công cụ Labtainers của máy.
