# Cấu hình Labtainer

- `start.config`: topology, IP, gateway và terminal cho bốn container.
- `instr_config/results.config` và `instr_config/goals.config`: cấu hình Checkwork theo quy ước Labtainers hiện đại.
- Labtainer cũ có thể đặt dữ liệu Results trong giao diện hoặc ở đường dẫn khác. Khi đó dùng màn hình Labedit để tạo cấu hình tương ứng, nhưng không xóa bản `instr_config`.

Hai địa chỉ `10.0.1.254` và `10.0.2.254` là gateway của mạng Docker/Labtainer. Router mô phỏng thật là container `gateway` với địa chỉ `.1`; `LAB GATEWAY` đặt route mặc định cho client và máy chủ.
