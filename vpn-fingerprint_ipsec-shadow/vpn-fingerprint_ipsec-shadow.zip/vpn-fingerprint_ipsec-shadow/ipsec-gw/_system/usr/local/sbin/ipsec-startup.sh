#!/usr/bin/env bash
set -euo pipefail
LOG=/var/log/lab3-ipsec-startup.log
exec >>"$LOG" 2>&1
ip route replace 10.0.1.0/24 via 10.0.2.1
chmod 600 /etc/ipsec.secrets
# With the starter package installed, either systemd or `ipsec start` can
# launch charon; the fallback is useful across Labtainers base revisions.
systemctl start strongswan-starter.service 2>/dev/null || ipsec start
sleep 2
ipsec statusall || true
