#!/usr/bin/env bash
printf '220 lab3-smtp ESMTP simulator\r\n'
while IFS= read -r line; do
  case "${line^^}" in
    QUIT*) printf '221 2.0.0 Bye\r\n'; exit 0 ;;
    DATA*) printf '354 End data with <CR><LF>.<CR><LF>\r\n' ;;
    .*) printf '250 2.0.0 Message accepted for simulation\r\n' ;;
    *) printf '250 2.0.0 OK\r\n' ;;
  esac
done
