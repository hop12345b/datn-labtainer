#!/usr/bin/env bash
set -euo pipefail
LOG=/var/log/lab3-web-startup.log
exec >>"$LOG" 2>&1

SERVER_IP="$(ip -o -4 addr show | awk '$4 ~ /^10\.0\.2\.(10|30)\// {split($4, a, "/"); print a[1]; exit}')"
if [[ -z "$SERVER_IP" ]]; then
  echo "ERROR: cannot find expected web endpoint IP (10.0.2.10 or 10.0.2.30)" >&2
  ip -br addr >&2
  exit 1
fi
mkdir -p /var/www/html /etc/ssl/private /etc/ssl/certs /etc/nginx/sites-available /etc/nginx/sites-enabled
if [[ ! -s /etc/ssl/private/lab3-selfsigned.key || ! -s /etc/ssl/certs/lab3-selfsigned.crt ]]; then
  openssl req -x509 -nodes -days 3650 -newkey rsa:2048 \
    -keyout /etc/ssl/private/lab3-selfsigned.key \
    -out /etc/ssl/certs/lab3-selfsigned.crt \
    -subj "/CN=${SERVER_IP}" >/dev/null 2>&1
fi
chmod 600 /etc/ssl/private/lab3-selfsigned.key
cat > /var/www/html/index.html <<EOF
<!doctype html><html><head><meta charset="utf-8"><title>Lab 3 IPsec endpoint</title></head>
<body><h1>Lab 3 IPsec endpoint</h1><p>Server address: ${SERVER_IP}</p><p>Simulated internal web service for the IPsec fingerprinting exercise.</p></body></html>
EOF
cat > /etc/nginx/sites-available/lab3-default <<'NGINX'
server {
    listen 80 default_server;
    server_name _;
    root /var/www/html;
    index index.html;
}
server {
    listen 443 ssl default_server;
    server_name _;
    root /var/www/html;
    index index.html;
    ssl_certificate /etc/ssl/certs/lab3-selfsigned.crt;
    ssl_certificate_key /etc/ssl/private/lab3-selfsigned.key;
    ssl_protocols TLSv1.2 TLSv1.3;
}
NGINX
rm -f /etc/nginx/sites-enabled/default
ln -sfn ../sites-available/lab3-default /etc/nginx/sites-enabled/lab3-default
nginx -t
systemctl restart nginx.service

# DNS is deliberately local and deterministic: no external DNS is required for traffic generation.
cat > /etc/dnsmasq.conf <<EOF
port=53
no-resolv
no-hosts
bind-interfaces
listen-address=127.0.0.1,${SERVER_IP}
address=/example.com/203.0.113.80
address=/lab3.local/${SERVER_IP}
cache-size=0
EOF
systemctl restart dnsmasq.service || echo "WARNING_DNSMASQ_START_FAILED" >&2
systemctl restart ssh.service 2>/dev/null || systemctl restart sshd.service 2>/dev/null || true
printf 'WEB_ENDPOINT_IP=%s\n' "$SERVER_IP"
systemctl --no-pager --full status nginx.service 2>&1 | tail -n 20 || true
