#!/usr/bin/env bash
set -uo pipefail
MODE="${1:-normal}"
COUNT="${2:-80}"
if ! [[ "$COUNT" =~ ^[0-9]+$ ]] || (( COUNT < 1 )); then
  echo "Usage: $0 [normal|vpn] [iterations>=1]" >&2; exit 2
fi
TARGETS=(10.0.2.10 10.0.2.30)
run_http() {
  local host="$1"
  curl --noproxy '*' -fsS --connect-timeout 2 --max-time 3 "http://${host}/" -o /dev/null || true
  curl --noproxy '*' -kfsS --connect-timeout 2 --max-time 3 "https://${host}/" -o /dev/null || true
}
run_dns() {
  local host="$1"
  if command -v dig >/dev/null 2>&1; then
    dig +time=1 +tries=1 @"$host" example.com A >/dev/null 2>&1 || true
  fi
}
run_smtp_noise() {
  local host="$1"
  if command -v nc >/dev/null 2>&1; then
    printf 'HELO lab3.local\r\nMAIL FROM:<student@lab3.local>\r\nRCPT TO:<analyst@lab3.local>\r\nDATA\r\nLab traffic sample\r\n.\r\nQUIT\r\n' | nc -w 2 "$host" 25 >/dev/null 2>&1 || true
  fi
}
run_ssh_noise() {
  local host="$1"
  if command -v ssh >/dev/null 2>&1; then
    timeout 3 ssh -o BatchMode=yes -o PreferredAuthentications=none \
      -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
      -o ConnectTimeout=2 ubuntu@"$host" true >/dev/null 2>&1 || true
  fi
}

printf 'TRAFFIC_GENERATOR_MODE=%s iterations=%s\n' "$MODE" "$COUNT"
for ((i=1; i<=COUNT; i++)); do
  for host in "${TARGETS[@]}"; do
    run_http "$host"
    run_dns "$host"
    run_smtp_noise "$host"
    run_ssh_noise "$host"
  done
  # Keep enough packet volume while allowing other containers to share CPU.
  sleep 0.03
done
printf 'TRAFFIC_GENERATOR_DONE=%s\n' "$COUNT"
