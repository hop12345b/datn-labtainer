#!/usr/bin/env bash
set -euo pipefail
ip route replace 10.0.2.0/24 via 10.0.1.1
