#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LAB_NAME="vpn-fingerprint_ipsec-shadow"
CONTAINERS=(client1 client2 gateway ipsec-gw shadow-ipsec)
fail() { echo "PREFLIGHT=FAIL: $*" >&2; exit 1; }

command -v python3 >/dev/null 2>&1 || fail "python3 required for preflight"
python3 "$ROOT/scripts/normalize-links.py" || fail "could not normalize expected symlinks"
python3 "$ROOT/scripts/build-archives.py" || fail "could not regenerate Labtainers TAR archives"

[[ -f "$ROOT/config/start.config" ]] || fail "missing config/start.config"
[[ -f "$ROOT/config/parameter.config" ]] || fail "missing config/parameter.config"
[[ -s "$ROOT/docs/vpn-fingerprint_ipsec-shadow.pdf" ]] || fail "missing docs/vpn-fingerprint_ipsec-shadow.pdf"
grep -Eq '^GLOBAL_SETTINGS$' "$ROOT/config/start.config" || fail "GLOBAL_SETTINGS missing"
grep -Eiq '^[[:space:]]*LAB_MASTER_SEED[[:space:]]+[^[:space:]]+' "$ROOT/config/start.config" || fail "LAB_MASTER_SEED missing/value missing"
grep -Eiq '^[[:space:]]*COLLECT_DOCS[[:space:]]+yes[[:space:]]*$' "$ROOT/config/start.config" || fail "COLLECT_DOCS should match reference IModule syntax"
grep -Eiq '^[[:space:]]*CHECKWORK[[:space:]]+yes[[:space:]]*$' "$ROOT/config/start.config" || fail "CHECKWORK should match reference IModule syntax"
grep -Eiq '^[[:space:]]*REGISTRY[[:space:]]+[^[:space:]]+' "$ROOT/config/start.config" || fail "REGISTRY missing"
for network in client-net external-net; do grep -Eq "^NETWORK ${network}$" "$ROOT/config/start.config" || fail "missing network: $network"; done
if grep -Eq '^[[:space:]]*(LAB_NAME|BASE_REGISTRY)([[:space:]]|$)' "$ROOT/config/start.config"; then fail "unsupported setting copied into start.config"; fi
for c in "${CONTAINERS[@]}"; do
  grep -Eq "^CONTAINER ${c}$" "$ROOT/config/start.config" || fail "container missing from start.config: $c"
  grep -A9 -E "^CONTAINER ${c}$" "$ROOT/config/start.config" | grep -qE '^[[:space:]]+PASSWORD ubuntu$' || fail "$c: PASSWORD ubuntu missing"
  grep -A9 -E "^CONTAINER ${c}$" "$ROOT/config/start.config" | grep -qE '^[[:space:]]+SCRIPT NONE$' || fail "$c: SCRIPT NONE missing"
  dir="$ROOT/$c"
  [[ -d "$dir/_system" ]] || fail "$c: missing _system"
  [[ -s "$dir/sys_tar/sys.tar" ]] || fail "$c: missing sys_tar/sys.tar"
  [[ -f "$dir/home_tar/home.tar" ]] || fail "$c: missing home_tar/home.tar"
  tar -tf "$dir/sys_tar/sys.tar" >/dev/null || fail "$c: invalid sys.tar"
  tar -tf "$dir/home_tar/home.tar" >/dev/null || fail "$c: invalid home.tar"
  df="$ROOT/dockerfiles/Dockerfile.${LAB_NAME}.${c}.student"
  [[ -f "$df" ]] || fail "$c: missing Dockerfile"
  grep -Fq 'ADD $labdir/$imagedir/sys_tar/sys.tar /' "$df" || fail "$c: wrong sys.tar ADD syntax"
  grep -Fq 'ADD $labdir/$imagedir/home_tar/home.tar $HOME' "$df" || fail "$c: wrong home.tar ADD syntax"
  grep -Fq 'FROM $registry/labtainer.network3' "$df" || fail "$c: must use Labtainers network3 base image"
  for key in 'ARG password' 'ARG version' 'LABEL version=$version' 'CMD ["/usr/sbin/init"]'; do grep -Fq "$key" "$df" || fail "$c: missing Dockerfile template directive: $key"; done
  grep -Fq 'if ! id -u "$user_name"' "$df" || fail "$c: Dockerfile must create user idempotently"
  grep -Fq '"/home/$user_name/.local/bin"' "$df" || fail "$c: Dockerfile must pre-create Labtainers .local directories before lab_bin copy"
  grep -Fq '"/home/$user_name/.local/result"' "$df" || fail "$c: Dockerfile must pre-create .local/result for stoplab"
  grep -Fq 'ln -sfn /usr/bin/python3 /usr/bin/python' "$df" || fail "$c: Dockerfile must provide /usr/bin/python for Labtainers Student.py"
  if [[ -d "$dir/_system/etc/systemd/system/multi-user.target.wants" ]]; then
    while IFS= read -r -d '' want; do
      [[ -L "$want" ]] || fail "$c: systemd wants entry is not a symlink: $want"
      [[ -e "$want" ]] || fail "$c: broken systemd wants symlink: $want"
    done < <(find "$dir/_system/etc/systemd/system/multi-user.target.wants" -mindepth 1 -maxdepth 1 -print0)
  fi
done
for cmd in detect-baseline.sh detect-tunnel.sh evaluate-ipsec.sh validate-pcaps.sh zeek-run.sh; do
  link="$ROOT/gateway/_system/usr/local/bin/$cmd"
  [[ -L "$link" && -e "$link" ]] || fail "gateway PATH link missing/broken: $cmd"
done
for item in detect_ipsec.py evaluate.py esp_scapy_inspect.py validate-pcaps.sh zeek-run.sh; do
  tar -tf "$ROOT/gateway/home_tar/home.tar" | grep -Fxq "$item" || fail "gateway home.tar missing $item"
done
for cmd in detect-baseline.sh detect-tunnel.sh evaluate-ipsec.sh validate-pcaps.sh zeek-run.sh; do
  grep -Fxq "$cmd" "$ROOT/gateway/_bin/treataslocal" || fail "gateway treataslocal missing output-capture command: $cmd"
done

# Editable script copies must match the versions baked into container filesystems.
python3 - "$ROOT" <<'PYCOPIES'
from pathlib import Path
import sys
root=Path(sys.argv[1])
pairs=[
 ("scripts/gateway-startup.sh", "gateway/_system/usr/local/sbin/gateway-startup.sh"),
 ("scripts/ipsec-startup.sh", "ipsec-gw/_system/usr/local/sbin/ipsec-startup.sh"),
 ("scripts/shadow-startup.sh", "shadow-ipsec/_system/usr/local/sbin/shadow-startup.sh"),
 ("scripts/client-ipsec-startup.sh", "client2/_system/usr/local/sbin/client-ipsec-startup.sh"),
 ("scripts/client-route-startup.sh", "client1/_system/usr/local/sbin/client-route-startup.sh"),
 ("scripts/client-route-startup.sh", "client2/_system/usr/local/sbin/client-route-startup.sh"),
 ("scripts/web-startup.sh", "ipsec-gw/_system/usr/local/sbin/web-startup.sh"),
 ("scripts/web-startup.sh", "shadow-ipsec/_system/usr/local/sbin/web-startup.sh"),
 ("scripts/traffic-generator.sh", "client1/traffic-generator.sh"),
 ("scripts/traffic-generator.sh", "client2/traffic-generator.sh"),
 ("scripts/detect_ipsec.py", "gateway/detect_ipsec.py"),
 ("scripts/evaluate.py", "gateway/evaluate.py"),
 ("scripts/esp_scapy_inspect.py", "gateway/esp_scapy_inspect.py"),
 ("scripts/validate-pcaps.sh", "gateway/validate-pcaps.sh"),
 ("scripts/zeek-run.sh", "gateway/zeek-run.sh"),
]
for a,b in pairs:
    if (root/a).read_bytes() != (root/b).read_bytes():
        raise SystemExit("source/runtime script mismatch: {0} != {1}".format(a,b))
PYCOPIES

# Every systemd ExecStart pointing to a lab-local script must have that script in _system.
python3 - "$ROOT" <<'PYSERVICE'
from pathlib import Path
import sys
root=Path(sys.argv[1])
errors=[]
for container in ("client1", "client2", "gateway", "ipsec-gw", "shadow-ipsec"):
    system=root/container/"_system"
    for unit in (system/"etc/systemd/system").glob("*.service"):
        for line_no, line in enumerate(unit.read_text(encoding="utf-8").splitlines(),1):
            if not line.startswith("ExecStart="):
                continue
            command=line.split("=",1)[1].split()[0]
            if command.startswith("/usr/local/sbin/"):
                local=system/command.lstrip("/")
                if not local.is_file():
                    errors.append("{0}:{1}: missing ExecStart target {2}".format(unit, line_no, local))
if errors:
    print("\n".join(errors), file=sys.stderr)
    raise SystemExit(1)
PYSERVICE

gw="$ROOT/dockerfiles/Dockerfile.${LAB_NAME}.gateway.student"
grep -Fq '24.04) ZEEK_SERIES=8.0' "$gw" || fail "gateway Dockerfile lacks the Zeek 8.0 mapping for Ubuntu 24.04"
grep -Fq '22.04) ZEEK_SERIES=7.0' "$gw" || fail "gateway Dockerfile lacks the Zeek 7.0 mapping for Ubuntu 22.04"
grep -Fq 'xUbuntu_${VERSION_ID}' "$gw" || fail "gateway Dockerfile does not use the matching Zeek OBS repository"
grep -Fq 'install-scapy.py' "$gw" || fail "gateway Dockerfile lacks Scapy install script"
if grep -R -nE 'python3-scapy|home\.tar\.gz|sys\.tar\.gz' "$ROOT/dockerfiles"; then fail "obsolete package/archive reference found"; fi
for marker in BASELINE_EXPECTED_NO_IPSEC_PASS AUTHORIZED_EXPECTED_IPSEC_PASS SHADOW_EXPECTED_IPSEC_PASS PCAP_VALIDATION=PASS LAB3_RESULT_PASS; do
  grep -Fq "$marker" "$ROOT/instr_config/results.config" || fail "results.config does not test success-only marker: $marker"
done
for marker in BASELINE_EXPECTED_NO_IPSEC_PASS AUTHORIZED_EXPECTED_IPSEC_PASS SHADOW_EXPECTED_IPSEC_PASS LAB3_RESULT_PASS; do
  grep -Fq "$marker" "$ROOT/gateway/evaluate.py" || fail "evaluator does not emit success-only marker: $marker"
done

# Parse each Dockerfile RUN body with the /bin/sh available on the Labtainers VM.
python3 - "$ROOT/dockerfiles" <<'PYDOCKER'
from pathlib import Path
import subprocess, sys
folder = Path(sys.argv[1])
errors = []
for path in sorted(folder.glob("Dockerfile.*.student")):
    logical = []
    buffer = ""
    start_line = 0
    for line_no, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not buffer:
            start_line = line_no
            buffer = raw
        else:
            buffer += raw.strip()
        if buffer.endswith("\\"):
            buffer = buffer[:-1] + " "
            continue
        logical.append((start_line, buffer))
        buffer = ""
    if buffer:
        errors.append("{0}: dangling Dockerfile continuation".format(path.name))
    for line_no, instruction in logical:
        if instruction.startswith("RUN "):
            p = subprocess.run(["/bin/sh", "-n", "-c", instruction[4:]],
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
            if p.returncode:
                errors.append("{0}:{1}: {2}".format(path.name, line_no, p.stderr.strip()))
if errors:
    print("\n".join(errors), file=sys.stderr)
    raise SystemExit(1)
PYDOCKER

while IFS= read -r -d '' file; do bash -n "$file" || fail "bash syntax: $file"; done < <(find "$ROOT" -type f -name '*.sh' -print0)
while IFS= read -r -d '' file; do PYTHONPYCACHEPREFIX=/tmp/lab3-pycache python3 -m py_compile "$file" || fail "python syntax: $file"; done < <(find "$ROOT" -type f -name '*.py' -print0)

python3 - "$ROOT/instr_config/results.config" "$ROOT/instr_config/goals.config" <<'PYCFG'
import re, sys
results_path, goals_path = sys.argv[1:]
result_ids = set()
for n, raw in enumerate(open(results_path, encoding="utf-8"), 1):
    s = raw.strip()
    if not s or s.startswith("#"): continue
    m = re.match(r"^(_[A-Za-z0-9_]+)\s*=\s*gateway:\*\.stdout\s*:\s*CONTAINS\s*:\s*\S.+$", s)
    if not m: raise SystemExit("Invalid Labtainers results.config line {0}: {1}".format(n, s))
    result_ids.add(m.group(1))
goal_count = 0
for n, raw in enumerate(open(goals_path, encoding="utf-8"), 1):
    s = raw.strip()
    if not s or s.startswith("#"): continue
    m = re.match(r"^([A-Za-z0-9_]+)\s*=\s*boolean\s*:\s*\((.*)\)\s*$", s)
    if not m: raise SystemExit("Invalid Labtainers goals.config line {0}: {1}".format(n, s))
    refs = re.findall(r"_[A-Za-z0-9_]+", m.group(2))
    missing = [r for r in refs if r not in result_ids]
    if missing: raise SystemExit("Goal references missing result IDs: {0}".format(", ".join(missing)))
    goal_count += 1
if not result_ids or goal_count == 0: raise SystemExit("results.config/goals.config is empty")
PYCFG

# Verify the runtime installer and analyzer files contain no f-string syntax for legacy Python.
python3 - "$ROOT/gateway/_system/usr/local/sbin/install-scapy.py" "$ROOT/gateway/detect_ipsec.py" "$ROOT/gateway/evaluate.py" "$ROOT/gateway/esp_scapy_inspect.py" <<'PYCOMPAT'
import re, sys, tokenize
for path in sys.argv[1:]:
    with open(path, "r", encoding="utf-8") as f:
        for token in tokenize.generate_tokens(f.readline):
            if token.type == tokenize.STRING and re.match(r"(?i)^(fr|rf|f)[\"']", token.string):
                raise SystemExit("f-string found in legacy-compatible runtime file: {0}:{1}".format(path, token.start[0]))
PYCOMPAT

# Start-config networks and container addresses must be internally consistent.
python3 - "$ROOT/config/start.config" <<'PYTOPO'
from pathlib import Path
import ipaddress, re, sys
path=Path(sys.argv[1]); lines=path.read_text(encoding="utf-8").splitlines()
networks={}; container_ips={}; current=None
known_settings={"USER","PASSWORD","TERMINALS","SCRIPT","LAB_GATEWAY"}
for n, raw in enumerate(lines,1):
    s=raw.strip()
    if not s or s.startswith("#"): continue
    m=re.match(r"^NETWORK\s+(\S+)$",s)
    if m:
        current=("network",m.group(1)); networks.setdefault(m.group(1),{})
        continue
    m=re.match(r"^CONTAINER\s+(\S+)$",s)
    if m:
        current=("container",m.group(1)); continue
    if current and current[0]=="network":
        if s.startswith("MASK "):
            try: networks[current[1]]["mask"]=ipaddress.ip_network(s.split(None,1)[1], strict=False)
            except ValueError: raise SystemExit("invalid network mask at line {0}".format(n))
        continue
    if current and current[0]=="container":
        fields=s.split()
        if len(fields)==2 and fields[0] not in known_settings:
            net, addr=fields
            if net not in networks: raise SystemExit("container uses undefined network {0} at line {1}".format(net,n))
            try: ip=ipaddress.ip_address(addr)
            except ValueError: raise SystemExit("invalid container IP at line {0}".format(n))
            if "mask" not in networks[net] or ip not in networks[net]["mask"]:
                raise SystemExit("container IP outside network {0} at line {1}".format(net,n))
            if addr in container_ips: raise SystemExit("duplicate container IP {0}".format(addr))
            container_ips[addr]=current[1]
if len(container_ips)!=6:
    # 6 unique addresses: 5 containers, with gateway holding one address on each subnet.
    raise SystemExit("expected 6 unique container IPs, found {0}".format(len(container_ips)))
PYTOPO

echo 'PREFLIGHT=PASS'
echo 'NOTE=Static checks passed. Docker build and live IPsec/Zeek/PCAP runtime still require verification in the target Labtainers VM.'
