#!/usr/bin/env bash
set -euo pipefail
for host in 10.0.2.10 10.0.2.30; do
  echo "== $host =="
  curl --noproxy '*' -fsS --connect-timeout 2 "http://$host/" >/dev/null
  curl --noproxy '*' -kfsS --connect-timeout 2 "https://$host/" >/dev/null
  echo "HTTP and HTTPS reachable"
done
