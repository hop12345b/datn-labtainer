#!/usr/bin/env python3
"""Build Labtainers home_tar/home.tar and sys_tar/sys.tar from editable source trees."""
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[1]
CONTAINERS = ("client1", "client2", "gateway", "ipsec-gw", "shadow-ipsec")
EXCLUDE_HOME = {"_system", "_bin", "sys_tar", "home_tar", "INSTRUCTIONS.txt", "install_scapy.py"}

for name in CONTAINERS:
    cdir = ROOT / name
    system = cdir / "_system"
    if not system.is_dir():
        raise SystemExit(f"Missing {system}")
    sys_dir = cdir / "sys_tar"
    home_dir = cdir / "home_tar"
    sys_dir.mkdir(exist_ok=True)
    home_dir.mkdir(exist_ok=True)
    with tarfile.open(sys_dir / "sys.tar", "w", format=tarfile.PAX_FORMAT) as archive:
        for item in sorted(system.rglob("*")):
            archive.add(item, arcname=item.relative_to(system).as_posix(), recursive=False)
    with tarfile.open(home_dir / "home.tar", "w", format=tarfile.PAX_FORMAT) as archive:
        for item in sorted(cdir.iterdir()):
            if item.name in EXCLUDE_HOME or item.name.startswith("."):
                continue
            if item.is_file() or item.is_symlink():
                archive.add(item, arcname=item.name, recursive=False)
    with tarfile.open(sys_dir / "sys.tar", "r:") as archive:
        archive.getmembers()
    with tarfile.open(home_dir / "home.tar", "r:") as archive:
        archive.getmembers()
    print(f"ARCHIVES_OK={name}")
print("ARCHIVE_BUILD=PASS")
