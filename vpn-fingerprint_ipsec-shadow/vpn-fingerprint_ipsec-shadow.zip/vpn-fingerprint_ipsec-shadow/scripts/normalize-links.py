#!/usr/bin/env python3
"""Restore the exact, known Labtainers symlinks before building archives."""
import os
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LINKS = {
    "client1": {
        "_system/etc/systemd/system/multi-user.target.wants/lab3-route.service": "../lab3-route.service",
    },
    "client2": {
        "_system/etc/systemd/system/multi-user.target.wants/lab3-route.service": "../lab3-route.service",
        "_system/etc/systemd/system/multi-user.target.wants/lab3-client-ipsec.service": "../lab3-client-ipsec.service",
    },
    "gateway": {
        "_system/etc/systemd/system/multi-user.target.wants/lab3-gateway.service": "../lab3-gateway.service",
        "_system/usr/local/bin/detect-baseline.sh": "../sbin/detect-baseline.sh",
        "_system/usr/local/bin/detect-tunnel.sh": "../sbin/detect-tunnel.sh",
        "_system/usr/local/bin/evaluate-ipsec.sh": "../sbin/evaluate-ipsec.sh",
        "_system/usr/local/bin/validate-pcaps.sh": "../sbin/validate-pcaps.sh",
        "_system/usr/local/bin/zeek-run.sh": "../sbin/zeek-run.sh",
    },
    "ipsec-gw": {
        "_system/etc/systemd/system/multi-user.target.wants/lab3-ipsec.service": "../lab3-ipsec.service",
        "_system/etc/systemd/system/multi-user.target.wants/lab3-web.service": "../lab3-web.service",
        "_system/etc/systemd/system/multi-user.target.wants/lab3-smtp.service": "../lab3-smtp.service",
    },
    "shadow-ipsec": {
        "_system/etc/systemd/system/multi-user.target.wants/lab3-shadow-ipsec.service": "../lab3-shadow-ipsec.service",
        "_system/etc/systemd/system/multi-user.target.wants/lab3-web.service": "../lab3-web.service",
        "_system/etc/systemd/system/multi-user.target.wants/lab3-smtp.service": "../lab3-smtp.service",
    },
}

def remove_existing(path):
    if path.is_symlink() or path.is_file():
        path.unlink()
    elif path.is_dir():
        shutil.rmtree(str(path))

def main():
    for container, items in LINKS.items():
        croot = ROOT / container
        system_root = croot / "_system"
        if not system_root.is_dir():
            raise SystemExit("missing system tree: {0}".format(system_root))
        for rel, target in items.items():
            link = croot / rel
            resolved_target = (link.parent / target).resolve()
            if not resolved_target.exists():
                raise SystemExit("cannot create {0}: target missing: {1}".format(link, resolved_target))
            link.parent.mkdir(parents=True, exist_ok=True)
            if link.is_symlink() and os.readlink(str(link)) == target:
                continue
            remove_existing(link)
            os.symlink(target, str(link))
            print("SYMLINK_OK={0} -> {1}".format(link.relative_to(ROOT), target))
    print("SYMLINK_NORMALIZATION=PASS")

if __name__ == "__main__":
    main()
