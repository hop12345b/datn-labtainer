#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "$0")/.." && pwd)"
: "${LABTAINER_DIR:?LABTAINER_DIR is unset; open a new shell or source Labtainers environment}"
DEST="$LABTAINER_DIR/labs/vpn-fingerprint_ipsec-shadow"
if [[ -e "$DEST" ]]; then
  echo "Existing lab found: $DEST" >&2
  echo "Back it up first, e.g.: mv '$DEST' '${DEST}.old-$(date +%Y%m%d-%H%M%S)'" >&2
  exit 1
fi
mkdir -p "$(dirname "$DEST")"
cp -a "$SRC_DIR" "$DEST"
"$DEST/scripts/preflight.sh"
echo "Installed to $DEST"
if [[ -d "$LABTAINER_DIR/scripts/labtainer-student" ]]; then
  STUDENT_WORKDIR="$LABTAINER_DIR/scripts/labtainer-student"
elif [[ -d "$HOME/labtainer/labtainer-student" ]]; then
  STUDENT_WORKDIR="$HOME/labtainer/labtainer-student"
else
  STUDENT_WORKDIR="<Labtainers student working directory>"
fi
echo "Next: cd '$STUDENT_WORKDIR' && rebuild vpn-fingerprint_ipsec-shadow"
