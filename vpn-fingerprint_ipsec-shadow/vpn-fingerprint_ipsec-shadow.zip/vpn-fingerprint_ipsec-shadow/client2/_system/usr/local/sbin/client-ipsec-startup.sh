#!/usr/bin/env bash
set -euo pipefail
LOG=/var/log/lab3-client-ipsec-startup.log
exec >>"$LOG" 2>&1
chmod 600 /etc/ipsec.secrets
# Static route to the external subnet is managed by lab3-route.service.
systemctl start strongswan-starter.service 2>/dev/null || ipsec start
sleep 2
ipsec statusall || true
