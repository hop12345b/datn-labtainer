# Lab 3 output artifacts

These are generated during the exercise in the **gateway** container, not shipped as fabricated samples:

- `/home/ubuntu/baseline_no_ipsec.pcap`
- `/home/ubuntu/with_ipsec.pcap`
- `/home/ubuntu/zeek_logs/baseline/`
- `/home/ubuntu/zeek_logs/with_ipsec/`

Acceptance checks during deployment:
1. Both PCAPs have at least 500 packets: `tshark -r FILE -T fields -e frame.number | tail -n 1`.
2. `with_ipsec.pcap` has raw ESP packets: `tshark -r with_ipsec.pcap -Y 'ip.proto == 50' -T fields -e frame.number | wc -l` returns a positive count.
3. Corporate IKE uses NAT-T as negotiated in this topology; verify actual UDP/4500 packets.
4. `python3 evaluate.py` prints a `LAB3_RESULT` line.

If requirement 1 or 2 fails, do not substitute synthetic protocol-50 packets; rerun the capture with tunnels established and more traffic iterations.
