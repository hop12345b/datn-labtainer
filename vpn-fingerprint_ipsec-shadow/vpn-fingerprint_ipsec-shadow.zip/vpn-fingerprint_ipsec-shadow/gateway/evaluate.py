#!/usr/bin/env python3
"""PCAP-level evaluation for Lab 3. Metrics are per-PCAP shadow presence."""
import os
import subprocess
import sys

GROUND_TRUTH = {
    "baseline_no_ipsec.pcap": {"authorized": 0, "shadow": 0},
    "with_ipsec.pcap": {"authorized": 1, "shadow": 1},
}
DETECTOR = "/home/ubuntu/detect_ipsec.py"
PCAP_DIR = "/home/ubuntu"


def run_detector(pcap_path):
    result = subprocess.run(["python3", DETECTOR, pcap_path],
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            universal_newlines=True)
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip()
        raise RuntimeError("Detector failed for {0}: {1}".format(pcap_path, detail))
    counts = {"authorized": 0, "shadow": 0, "detection": "UNKNOWN"}
    for line in result.stdout.splitlines():
        if line.startswith("AUTHORIZED_SESSIONS="):
            counts["authorized"] = int(line.split("=", 1)[1].strip())
        elif line.startswith("SHADOW_SESSIONS="):
            counts["shadow"] = int(line.split("=", 1)[1].strip())
        elif line.startswith("DETECTION="):
            counts["detection"] = line.split("=", 1)[1].strip()
    return counts


def binary_metrics(detected_positive, truth_positive):
    tp = int(bool(detected_positive) and bool(truth_positive))
    fp = int(bool(detected_positive) and not bool(truth_positive))
    tn = int(not bool(detected_positive) and not bool(truth_positive))
    fn = int(not bool(detected_positive) and bool(truth_positive))
    precision = tp / float(tp + fp) if tp + fp else 0.0
    recall = tp / float(tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {"tp": tp, "fp": fp, "tn": tn, "fn": fn,
            "precision": precision, "recall": recall, "f1": f1}


def main():
    detected_by_file = {}
    results = []
    for name, truth in GROUND_TRUTH.items():
        path = os.path.join(PCAP_DIR, name)
        if not os.path.isfile(path):
            print("MISSING_PCAP={0}".format(path))
            print("LAB3_RESULT=INCOMPLETE")
            return 2
        try:
            detected = run_detector(path)
        except RuntimeError as exc:
            print("DETECTOR_ERROR={0}".format(exc))
            print("LAB3_RESULT=FAIL")
            return 1
        detected_by_file[name] = detected
        metrics = binary_metrics(detected["shadow"] > 0, truth["shadow"] > 0)
        results.append((name, detected, truth, metrics))

    baseline = detected_by_file["baseline_no_ipsec.pcap"]
    combined = detected_by_file["with_ipsec.pcap"]
    baseline_ok = baseline["authorized"] == 0 and baseline["shadow"] == 0 and baseline["detection"] == "NO_IPSEC"
    authorized_ok = combined["authorized"] == 1
    shadow_ok = combined["shadow"] == 1
    print("BASELINE_EXPECTED_NO_IPSEC={0}".format("PASS" if baseline_ok else "FAIL"))
    print("AUTHORIZED_EXPECTED_IPSEC={0}".format("PASS" if authorized_ok else "FAIL"))
    print("SHADOW_EXPECTED_IPSEC={0}".format("PASS" if shadow_ok else "FAIL"))
    # Unique tokens are emitted only on success so Labtainers CONTAINS checks
    # cannot pass merely because the word prefix also occurs in a FAIL line.
    if baseline_ok:
        print("BASELINE_EXPECTED_NO_IPSEC_PASS")
    if authorized_ok:
        print("AUTHORIZED_EXPECTED_IPSEC_PASS")
    if shadow_ok:
        print("SHADOW_EXPECTED_IPSEC_PASS")
    print("LAB3_METRIC_SCOPE=per-PCAP shadow-presence, not per-packet accuracy")
    print("=" * 64)
    print("LAB 3 EVALUATION - IPSEC SHADOW VPN")
    print("=" * 64)
    tp = fp = tn = fn = 0
    for name, detected, truth, metrics in results:
        print("\nPCAP: {0}".format(name))
        print("  Detected: authorized={0}, shadow={1}, detection={2}".format(
            detected["authorized"], detected["shadow"], detected["detection"]))
        print("  Truth:    authorized={0}, shadow={1}".format(
            truth["authorized"], truth["shadow"]))
        print("  TP={tp} FP={fp} TN={tn} FN={fn}".format(**metrics))
        print("  Precision={:.2%} Recall={:.2%} F1={:.2%}".format(
            metrics["precision"], metrics["recall"], metrics["f1"]))
        tp += metrics["tp"]
        fp += metrics["fp"]
        tn += metrics["tn"]
        fn += metrics["fn"]
    precision = tp / float(tp + fp) if tp + fp else 0.0
    recall = tp / float(tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    total = tp + fp + tn + fn
    accuracy = (tp + tn) / float(total) if total else 0.0
    print("\nOVERALL TP={0} FP={1} TN={2} FN={3}".format(tp, fp, tn, fn))
    print("Precision={:.2%} Recall={:.2%} F1={:.2%} Accuracy={:.2%}".format(
        precision, recall, f1, accuracy))
    all_expected = baseline_ok and authorized_ok and shadow_ok
    passed = all_expected and f1 >= 0.8
    print("LAB3_RESULT={0}".format("PASS" if passed else "FAIL"))
    if passed:
        print("LAB3_RESULT_PASS")
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
