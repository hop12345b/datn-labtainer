#!/usr/bin/env bash
set -euo pipefail
PCAP="${1:?Usage: zeek-run.sh <pcap> [output-dir]}"
OUTDIR="${2:-$HOME/zeek_logs/$(basename "$PCAP" .pcap)}"
command -v zeek >/dev/null 2>&1 || { echo "zeek not found in PATH" >&2; exit 127; }
[[ -s "$PCAP" ]] || { echo "PCAP missing or empty: $PCAP" >&2; exit 2; }
mkdir -p "$OUTDIR"
cd "$OUTDIR"
zeek -r "$PCAP"
printf 'ZEEK_OUTPUT=%s\n' "$OUTDIR"
printf 'ZEEK_LOG_FILES=\n'
find "$OUTDIR" -maxdepth 1 -type f -name '*.log' -printf '%f\n' | sort
