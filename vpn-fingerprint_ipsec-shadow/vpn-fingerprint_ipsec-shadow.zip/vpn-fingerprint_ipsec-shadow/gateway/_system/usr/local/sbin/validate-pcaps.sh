#!/usr/bin/env bash
set -euo pipefail
BASELINE="${1:-/home/ubuntu/baseline_no_ipsec.pcap}"
WITH_IPSEC="${2:-/home/ubuntu/with_ipsec.pcap}"
for f in "$BASELINE" "$WITH_IPSEC"; do
  if [[ ! -s "$f" ]]; then echo "ERROR=missing_or_empty:$f"; exit 2; fi
done
count_frames() { tshark -n -r "$1" -T fields -e frame.number 2>/dev/null | wc -l; }
BASELINE_FRAMES="$(count_frames "$BASELINE" | tr -d ' ')"
WITH_FRAMES="$(count_frames "$WITH_IPSEC" | tr -d ' ')"
ESP_COUNT="$(tshark -n -r "$WITH_IPSEC" -Y 'ip.proto == 50' -T fields -e frame.number 2>/dev/null | wc -l | tr -d ' ')"
IKE500_COUNT="$(tshark -n -r "$WITH_IPSEC" -Y 'udp.port == 500' -T fields -e frame.number 2>/dev/null | wc -l | tr -d ' ')"
NATT4500_COUNT="$(tshark -n -r "$WITH_IPSEC" -Y 'udp.port == 4500' -T fields -e frame.number 2>/dev/null | wc -l | tr -d ' ')"
printf 'BASELINE_FRAMES=%s\nWITH_IPSEC_FRAMES=%s\nIKE_UDP500_PACKETS=%s\nNATT_UDP4500_PACKETS=%s\nESP_PROTO50_PACKETS=%s\n' \
  "$BASELINE_FRAMES" "$WITH_FRAMES" "$IKE500_COUNT" "$NATT4500_COUNT" "$ESP_COUNT"
if (( BASELINE_FRAMES >= 500 && WITH_FRAMES >= 500 && IKE500_COUNT > 0 && NATT4500_COUNT > 0 && ESP_COUNT > 0 )); then
  echo 'PCAP_VALIDATION=PASS'
  exit 0
fi
echo 'PCAP_VALIDATION=FAIL'
echo 'Kiểm tra lại thời điểm capture, phiên SA, NAT-T, interface và traffic generator.' >&2
exit 1
