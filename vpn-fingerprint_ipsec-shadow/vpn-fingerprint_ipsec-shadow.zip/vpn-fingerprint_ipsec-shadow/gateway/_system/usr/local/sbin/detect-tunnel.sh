#!/usr/bin/env bash
set -euo pipefail
exec python3 /home/ubuntu/detect_ipsec.py /home/ubuntu/with_ipsec.pcap
