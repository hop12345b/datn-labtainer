#!/usr/bin/env bash
set -euo pipefail
exec python3 /home/ubuntu/evaluate.py
