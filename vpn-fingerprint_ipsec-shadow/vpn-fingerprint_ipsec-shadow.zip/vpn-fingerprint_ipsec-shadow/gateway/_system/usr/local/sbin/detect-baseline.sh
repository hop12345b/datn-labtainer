#!/usr/bin/env bash
set -euo pipefail
exec python3 /home/ubuntu/detect_ipsec.py /home/ubuntu/baseline_no_ipsec.pcap
