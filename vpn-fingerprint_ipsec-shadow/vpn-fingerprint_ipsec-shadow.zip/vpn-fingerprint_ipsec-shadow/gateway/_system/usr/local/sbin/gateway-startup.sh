#!/usr/bin/env bash
set -euo pipefail
LOG=/var/log/lab3-gateway-startup.log
exec >>"$LOG" 2>&1

get_if_for_ip() {
  local wanted="$1"
  ip -o -4 addr show | awk -v addr="$wanted" '$4 ~ ("^" addr "/") {print $2; exit}'
}
CLIENT_IF="$(get_if_for_ip 10.0.1.1)"
EXTERNAL_IF="$(get_if_for_ip 10.0.2.1)"
if [[ -z "$CLIENT_IF" || -z "$EXTERNAL_IF" ]]; then
  echo "ERROR: cannot map interfaces by IP; expected 10.0.1.1 and 10.0.2.1" >&2
  ip -br addr >&2
  exit 1
fi

echo "[$(date -Is)] Lab 3 router client_if=$CLIENT_IF external_if=$EXTERNAL_IF"
sysctl -w net.ipv4.ip_forward=1
iptables -C FORWARD -i "$CLIENT_IF" -o "$EXTERNAL_IF" -s 10.0.1.0/24 -d 10.0.2.0/24 -j ACCEPT 2>/dev/null || \
  iptables -A FORWARD -i "$CLIENT_IF" -o "$EXTERNAL_IF" -s 10.0.1.0/24 -d 10.0.2.0/24 -j ACCEPT
iptables -C FORWARD -i "$EXTERNAL_IF" -o "$CLIENT_IF" -s 10.0.2.0/24 -d 10.0.1.0/24 -j ACCEPT 2>/dev/null || \
  iptables -A FORWARD -i "$EXTERNAL_IF" -o "$CLIENT_IF" -s 10.0.2.0/24 -d 10.0.1.0/24 -j ACCEPT
# Selectively NAT only UDP IKE/NAT-T to the authorized corporate gateway.
for p in 500 4500; do
  iptables -t nat -C POSTROUTING -s 10.0.1.0/24 -d 10.0.2.10/32 -p udp --dport "$p" -j MASQUERADE 2>/dev/null || \
    iptables -t nat -A POSTROUTING -s 10.0.1.0/24 -d 10.0.2.10/32 -p udp --dport "$p" -j MASQUERADE
done
mkdir -p /home/ubuntu/zeek_logs
chown -R ubuntu:ubuntu /home/ubuntu/zeek_logs || true
printf 'ip_forward='; sysctl -n net.ipv4.ip_forward
iptables -S FORWARD
iptables -t nat -S POSTROUTING
echo "[$(date -Is)] router rules ready"
