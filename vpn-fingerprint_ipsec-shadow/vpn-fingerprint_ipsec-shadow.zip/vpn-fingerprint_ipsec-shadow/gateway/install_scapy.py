#!/usr/bin/env python3
"""Compatibility note: the authoritative build-time installer lives at _system/usr/local/sbin/install-scapy.py.
It is copied into the image as /usr/local/sbin/install-scapy.py via sys_tar/sys.tar.
"""
print("Use /usr/local/sbin/install-scapy.py inside the built gateway image.")
