#!/usr/bin/env python3
"""Count and inspect real IPv4 ESP (IP protocol 50) packets in a PCAP."""
import sys
from scapy.all import PcapReader, IP
from scapy.layers.ipsec import ESP


def main():
    if len(sys.argv) != 2:
        print("Usage: {0} <pcap>".format(sys.argv[0]))
        return 2
    total = 0
    decoded = 0
    shown = 0
    try:
        with PcapReader(sys.argv[1]) as packets:
            for packet in packets:
                if IP not in packet or int(packet[IP].proto) != 50:
                    continue
                total += 1
                src, dst = packet[IP].src, packet[IP].dst
                if ESP in packet:
                    decoded += 1
                    spi = int(packet[ESP].spi)
                    seq = int(packet[ESP].seq)
                    if shown < 10:
                        print("ESP src={0} dst={1} spi=0x{2:08x} seq={3} len={4}".format(
                            src, dst, spi, seq, len(packet)))
                        shown += 1
                elif shown < 10:
                    print("IP_PROTO_50 src={0} dst={1} len={2} (ESP layer not decoded)".format(
                        src, dst, len(packet)))
                    shown += 1
    except (IOError, ValueError) as exc:
        print("ERROR: {0}".format(exc), file=sys.stderr)
        return 1
    print("IP_PROTO_50_PACKETS={0}".format(total))
    print("SCAPY_ESP_DECODED={0}".format(decoded))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
