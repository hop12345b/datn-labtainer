#!/usr/bin/env python3
"""IPsec / shadow-VPN detector for the Lab 3 exercise.
Printed keys match the Lab 1-style interface. UDP/4500 can carry both IKE NAT-T
control packets and ESP-in-UDP, so this detector treats it as a transport clue.
"""
import ipaddress
import os
import subprocess
import sys
from collections import defaultdict

IKE_PORTS = [500, 4500]
ESP_IP_PROTOCOL = 50
MIN_FRAME_SIZE = 100
MAX_FRAME_SIZE = 1500
MIN_MATCHING_PACKETS = 5
AUTHORIZED_GATEWAYS = []  # Students fill in the corporate gateway trust policy.
CLIENT_NETWORK = ipaddress.ip_network("10.0.1.0/24")
EXTERNAL_NETWORK = ipaddress.ip_network("10.0.2.0/24")
ROUTER_NAT_IPS = {"10.0.2.1"}
NAT_CLIENT_MAP = {"10.0.2.1": "10.0.1.101"}


def run_tshark(pcap_path, display_filter, fields):
    if not os.path.isfile(pcap_path):
        raise IOError("Không tìm thấy PCAP: {0}".format(pcap_path))
    command = ["tshark", "-n", "-r", pcap_path, "-Y", display_filter,
               "-T", "fields", "-E", "separator=\t", "-E", "occurrence=f"]
    for field in fields:
        command.extend(["-e", field])
    completed = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               universal_newlines=True)
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout).strip()
        raise RuntimeError("tshark không đọc được PCAP. Chi tiết: {0}".format(detail))
    rows = []
    for line in completed.stdout.splitlines():
        parts = line.split("\t")
        if len(parts) < len(fields):
            parts.extend([""] * (len(fields) - len(parts)))
        rows.append(parts)
    return rows


def read_ike_packets(pcap_path):
    filter_expr = " || ".join("udp.port == {0}".format(port) for port in IKE_PORTS)
    rows = run_tshark(pcap_path, "({0})".format(filter_expr),
                      ["frame.len", "ip.src", "ip.dst", "udp.srcport", "udp.dstport"])
    packets = []
    for row in rows:
        try:
            sport, dport = int(row[3]), int(row[4])
            layer = "IKE_UDP500" if 500 in (sport, dport) else "NAT_T_UDP4500"
            packets.append({"frame_len": int(row[0]), "ip_src": row[1], "ip_dst": row[2],
                            "sport": sport, "dport": dport, "layer": layer})
        except (ValueError, IndexError):
            continue
    return packets


def read_esp_packets(pcap_path):
    rows = run_tshark(pcap_path, "ip.proto == {0}".format(ESP_IP_PROTOCOL),
                      ["frame.len", "ip.src", "ip.dst", "esp.spi", "esp.sequence"])
    packets = []
    for row in rows:
        try:
            packets.append({"frame_len": int(row[0]), "ip_src": row[1], "ip_dst": row[2],
                            "sport": None, "dport": None, "layer": "ESP",
                            "spi": row[3], "sequence": row[4]})
        except (ValueError, IndexError):
            continue
    return packets


def is_in(ip_text, network):
    try:
        return ipaddress.ip_address(ip_text) in network
    except ValueError:
        return False


def normalize_session(src, dst):
    trusted = set(AUTHORIZED_GATEWAYS)
    if src in ROUTER_NAT_IPS and is_in(dst, EXTERNAL_NETWORK):
        return NAT_CLIENT_MAP.get(src, src), dst
    if dst in ROUTER_NAT_IPS and is_in(src, EXTERNAL_NETWORK):
        return NAT_CLIENT_MAP.get(dst, dst), src
    if dst in trusted:
        return src, dst
    if src in trusted:
        return dst, src
    if is_in(src, CLIENT_NETWORK) and is_in(dst, EXTERNAL_NETWORK):
        return src, dst
    if is_in(dst, CLIENT_NETWORK) and is_in(src, EXTERNAL_NETWORK):
        return dst, src
    if is_in(dst, EXTERNAL_NETWORK) and not is_in(src, EXTERNAL_NETWORK):
        return src, dst
    if is_in(src, EXTERNAL_NETWORK) and not is_in(dst, EXTERNAL_NETWORK):
        return dst, src
    return tuple(sorted((src, dst)))


def build_sessions(packets):
    sessions = defaultdict(list)
    for packet in packets:
        if not packet.get("ip_src") or not packet.get("ip_dst"):
            continue
        sessions[normalize_session(packet["ip_src"], packet["ip_dst"])].append(packet)
    return sessions


def classify_session(session_key, packets):
    client_ip, server_ip = session_key
    matched = [p for p in packets if MIN_FRAME_SIZE <= p["frame_len"] <= MAX_FRAME_SIZE]
    detected = len(matched) >= MIN_MATCHING_PACKETS
    layers = sorted(set(p["layer"] for p in packets))
    ports = sorted(set(port for p in packets for port in (p.get("sport"), p.get("dport"))
                        if port in IKE_PORTS))
    if not detected:
        classification = "NO_IPSEC"
    elif server_ip in AUTHORIZED_GATEWAYS:
        classification = "AUTHORIZED_IPSEC"
    else:
        classification = "SHADOW_IPSEC"
    return {"client_ip": client_ip, "server_ip": server_ip, "layers": layers,
            "ike_ports": ports, "total_packets": len(packets),
            "matched_packets": len(matched), "classification": classification,
            "detected": detected}


def analyze_pcap(pcap_path):
    packets = read_ike_packets(pcap_path) + read_esp_packets(pcap_path)
    sessions = build_sessions(packets)
    results = [classify_session(key, items) for key, items in sessions.items()]
    return {"pcap": os.path.basename(pcap_path), "total_packets": len(packets),
            "total_sessions": len(results), "sessions": results}


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 detect_ipsec.py <pcap_file>")
        return 2
    pcap_path = sys.argv[1]
    try:
        result = analyze_pcap(pcap_path)
    except (IOError, RuntimeError, OSError) as exc:
        print("ERROR={0}".format(exc), file=sys.stderr)
        return 1
    print("PCAP={0}".format(result["pcap"]))
    print("IPSEC_PACKETS={0}".format(result["total_packets"]))
    print("SESSIONS={0}".format(result["total_sessions"]))
    print("RULE=ports {0}, esp_proto {1}, frame.len {2}..{3}, min {4}, whitelist {5}".format(
        IKE_PORTS, ESP_IP_PROTOCOL, MIN_FRAME_SIZE, MAX_FRAME_SIZE,
        MIN_MATCHING_PACKETS, AUTHORIZED_GATEWAYS))
    print()
    for session in result["sessions"]:
        layers = "+".join(session["layers"])
        ports = ",".join(str(p) for p in session["ike_ports"]) or "none"
        print("SESSION: client={client_ip} server={server_ip} layers={layers} ports={ports} "
              "packets={matched_packets}/{total_packets} class={classification}".format(
                  client_ip=session["client_ip"], server_ip=session["server_ip"],
                  layers=layers, ports=ports,
                  matched_packets=session["matched_packets"],
                  total_packets=session["total_packets"],
                  classification=session["classification"]))
    authorized = sum(1 for s in result["sessions"] if s["classification"] == "AUTHORIZED_IPSEC")
    shadow = sum(1 for s in result["sessions"] if s["classification"] == "SHADOW_IPSEC")
    print()
    print("AUTHORIZED_SESSIONS={0}".format(authorized))
    print("SHADOW_SESSIONS={0}".format(shadow))
    if shadow > 0:
        print("DETECTION=SHADOW_VPN_FOUND")
    elif authorized > 0:
        print("DETECTION=AUTHORIZED_VPN_ONLY")
    else:
        print("DETECTION=NO_IPSEC")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
