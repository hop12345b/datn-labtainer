# Lab 3 — vpn-fingerprint_ipsec-shadow

Labtainers exercise: fingerprinting IPsec/IKE traffic and distinguishing an approved corporate gateway from a shadow VPN by an explicit gateway trust policy.

## Before rebuilding

1. Extract this directory into `$LABTAINER_DIR/labs/vpn-fingerprint_ipsec-shadow` on the Labtainers Linux VM. Do not extract on Windows and copy the files if that operation flattens Linux symbolic links.
2. Run `bash scripts/preflight.sh` from this directory. The script normalizes the required symlinks, regenerates `home_tar/home.tar` and `sys_tar/sys.tar`, and checks the Labtainers configuration and scripts.
3. Only after `PREFLIGHT=PASS`, run `rebuild vpn-fingerprint_ipsec-shadow` from the Labtainers student directory.

## Topology

- `client1`: 10.0.1.100, normal background traffic
- `client2`: 10.0.1.101, IKEv2 authorized peer and IKEv1 shadow peer
- `gateway`: 10.0.1.1 / 10.0.2.1, routing, selective NAT, capture and analysis
- `ipsec-gw`: 10.0.2.10, approved corporate gateway
- `shadow-ipsec`: 10.0.2.30, unapproved gateway
- `client-net`: 10.0.1.0/24; `external-net`: 10.0.2.0/24

## Build-time packages

All five images use the Labtainers `labtainer.network3` base. `gateway` installs tshark, Scapy 2.5.0 from a source archive pinned by SHA-256, and a Zeek LTS package from the official Zeek OBS repository. The Dockerfile selects Zeek 7.0 on Ubuntu 22.04 and Zeek 8.0 on Ubuntu 24.04, and the build needs HTTPS access to Ubuntu package sources, `files.pythonhosted.org` and `download.opensuse.org`. See [Zeek installation documentation](https://docs.zeek.org/en/current/install.html).

## Files

- `config/start.config`: Labtainers topology
- `dockerfiles/`: five Dockerfiles using Labtainers archive conventions
- `<container>/_system/`: service units and system files baked into `sys_tar/sys.tar`
- `<container>/home_tar/home.tar`: generated home archive
- `instr_config/results.config`, `instr_config/goals.config`: marker-based Checkwork in the same form as the provided reference IModule
- `docs/student-guide.pdf` and Markdown source: student instructions

## Important validation limit

`PREFLIGHT=PASS` means static package validation passed. It does not prove that Docker images built, that the host VM allows XFRM/IPsec, or that runtime PCAPs contain ESP. The final runtime acceptance sequence is in `docs/build-and-verify.md`. Do not describe synthetic traffic as real ESP; validate `with_ipsec.pcap` using `scripts/validate-pcaps.sh`.


## Fix for Labtainers startup/stoplab file-copy errors (v6)

All five Dockerfiles pre-create `/home/$user_name/.local/bin`, `.local/result`, `.local/instr_config`, `.local/config`, and `.local/zip`, then set ownership to the configured user. This is required because the Labtainers framework copies its `lab_bin` into `.local/bin` during parameterization, and `stoplab` later uses `.local/result` and `Student.py` to collect artifacts.

The topology intentionally declares five containers: `client1`, `client2`, `gateway`, `ipsec-gw`, and `shadow-ipsec`. `rebuild` reporting “Started 5 containers” matches the intended topology. If `docker ps -a` shows other containers, filter by the `vpn-fingerprint_ipsec-shadow` prefix before removing anything; do not delete containers belonging to other labs.


## Fix v7: Labtainers stoplab Python alias

Labtainers' `Student.py` is invoked using `/usr/bin/env python`. The five images now install `python3` explicitly and create `/usr/bin/python -> /usr/bin/python3` during Docker build. This is required so `stoplab` can execute Student.py and collect results. The preflight script verifies the alias setup in all five Dockerfiles.
