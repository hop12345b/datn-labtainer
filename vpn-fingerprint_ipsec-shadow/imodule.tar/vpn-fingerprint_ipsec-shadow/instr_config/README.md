# Automated assessment

Labtainers convention stores grading configuration in `instr_config/results.config` and `instr_config/goals.config`. These checks use distinct wrapper outputs from `detect-baseline.sh`, `detect-tunnel.sh`, `evaluate-ipsec.sh`, and `validate-pcaps.sh`. The wrapper commands are listed in `gateway/_bin/treataslocal` so their stdout artifacts remain separate for Checkwork.

Validation required on the target Labtainers version: run `checkwork` after an end-to-end test and inspect the grade report. Labtainers versions can differ in artifact collection details. `evaluate.py` is PCAP-level binary scoring for shadow presence; it does not compute per-flow or per-packet precision/recall.
