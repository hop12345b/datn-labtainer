# Build and verify — Lab 3 IPsec Shadow VPN

## 1. Bám đúng cấu trúc Labtainers

Gói được làm theo `imodule.tar` của Lab 2 mà bạn cung cấp. Cấu hình sử dụng `config/start.config`, `config/parameter.config`, năm Dockerfile theo mẫu `Dockerfile.<lab>.<container>.student`, `instr_config/results.config`/`goals.config`, và các archive `sys_tar/sys.tar` cùng `home_tar/home.tar`.

Hai lệnh Dockerfile quan trọng phải giữ nguyên đúng tên archive:

```dockerfile
ADD $labdir/$imagedir/sys_tar/sys.tar /
ADD $labdir/$imagedir/home_tar/home.tar $HOME
```

Không đổi sang `.tar.gz`: các archive trong lab có phần mở rộng `.tar`.

## 2. Preflight trước khi rebuild

Sau khi giải nén dưới `$LABTAINER_DIR/labs/`:

```bash
cd "$LABTAINER_DIR/labs/vpn-fingerprint_ipsec-shadow"
bash scripts/preflight.sh
```

Script đồng bộ symlink systemd đã khai báo, tái tạo các archive từ `_system`/home source tree rồi kiểm tra cú pháp cấu hình, tên Dockerfile, đường dẫn `ADD`, archive, Bash/Python và `results.config`/`goals.config`.

Chỉ khi thấy `PREFLIGHT=PASS` mới chuyển sang build. Kết quả này là static preflight, không thay cho kiểm thử Docker hoặc IPsec runtime.

## 3. Build bằng Labtainers

```bash
cd "$HOME/labtainer/labtainer-student"
rebuild vpn-fingerprint_ipsec-shadow
```

Nếu đường dẫn `labtainer-student` của bản cài đặt khác, dùng đúng đường dẫn thực tế của máy. Đọc lỗi đầu tiên trong `$LABTAINER_DIR/logs/docker_build.log`; dòng cuối `exit code` không đủ để chẩn đoán.

## 4. Package Scapy và APT

Không Dockerfile nào gọi `apt install python3-scapy`. Trên Ubuntu images, package này thuộc component `universe`; vì các image/customized APT sources có thể không bật component này, gateway cài Scapy 2.5.0 từ source archive PyPI đã cố định SHA-256 rồi xác nhận import `scapy.all` và `scapy.layers.ipsec.ESP`. Script cài được viết không dùng f-string, để tránh lỗi trên Python cũ. Build cần HTTPS truy cập `files.pythonhosted.org`.

## 5. Zeek — nguồn gói và xác minh

Gateway sử dụng kho chính thức của Zeek trên openSUSE Build Service. Dockerfile chọn dòng LTS theo hệ điều hành: Ubuntu 22.04 dùng `zeek-7.0`; Ubuntu 24.04 dùng `zeek-8.0`. Đây là lựa chọn có chủ đích vì các nhánh phân phối khác nhau có thể cung cấp dòng LTS khác nhau. Build cần truy cập HTTPS tới `download.opensuse.org`.

Sau khi lab khởi động, trên `gateway`:

```bash
zeek --version
tshark --version
python3 -c 'from scapy.all import IP; from scapy.layers.ipsec import ESP; print("SCAPY_IMPORT=PASS")'
```

Chạy phân tích PCAP:

```bash
zeek-run.sh /home/ubuntu/baseline_no_ipsec.pcap /home/ubuntu/zeek_logs/baseline
zeek-run.sh /home/ubuntu/with_ipsec.pcap /home/ubuntu/zeek_logs/with_ipsec
find /home/ubuntu/zeek_logs -maxdepth 2 -type f -name '*.log' -print
```

Zeek tạo các log dựa trên analyzer và giao thức nhìn thấy. Không mặc định rằng `ike.log`/`esp.log` phải xuất hiện trong Zeek core mặc định; dùng `conn.log` cùng `tshark`/Scapy cho dữ liệu IKE/ESP nếu chưa cài analyzer chuyên biệt.

## 6. Runtime checklist

1. `gateway`: `ip -br addr`, `ip route`, `sysctl net.ipv4.ip_forward`, `iptables -S FORWARD`.
2. `ipsec-gw`, `shadow-ipsec`: `ipsec statusall`, `ss -ulnp | grep -E ':(500|4500)\b'`.
3. `client2`: `ipsec statusall`, `ip xfrm state`, `ip xfrm policy`.
4. Capture baseline trước khi chạy tunnel; capture `with_ipsec.pcap` trước khi tạo lại handshake để có IKE.
5. Validator yêu cầu mỗi PCAP ít nhất 500 frame; PCAP thứ hai còn phải có UDP 500, UDP 4500 và raw ESP protocol 50. ESP protocol 50 là yêu cầu riêng của kịch bản; NAT-T traffic có thể mang ESP-in-UDP ở port 4500, không tự động hiển thị dưới `ip.proto == 50`.
6. Chạy `detect-baseline.sh`, `detect-tunnel.sh`, `evaluate-ipsec.sh`, `validate-pcaps.sh` trong terminal `gateway`, rồi thực hiện Checkwork.

## 7. Những gì chưa thể chứng minh từ ZIP

Không thể xác minh hoàn toàn Docker build, kernel XFRM, capability của container hoặc sự hình thành CHILD_SA chỉ bằng file ZIP. Việc nghiệm thu cần build trong VM Labtainers đích, chạy `ipsec up` thành công và xác minh PCAP chứa ESP thật. Không dùng dữ liệu tổng hợp để thay thế.


### Repair included in v6: Labtainers `.local` directories

Each Dockerfile creates the following paths before container parameterization:

- `/home/ubuntu/.local/bin`
- `/home/ubuntu/.local/result`
- `/home/ubuntu/.local/instr_config`
- `/home/ubuntu/.local/config`
- `/home/ubuntu/.local/zip`

This avoids the framework's `docker cp ... lab_bin/. ...:/home/ubuntu/.local/bin/` failure and allows `Student.py` to create result archives when `stoplab` runs. The lab topology contains exactly five lab containers.


### `stoplab` reports `/usr/bin/env: python: No such file or directory`

This indicates the image has no `python` command. v7 installs `python3` in every image and creates `/usr/bin/python` as a symlink to `/usr/bin/python3`; rebuild all five lab images after updating the Dockerfiles.
