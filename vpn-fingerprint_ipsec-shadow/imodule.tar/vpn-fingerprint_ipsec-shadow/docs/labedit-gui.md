# Hướng dẫn `labedit` — Lab 3 `vpn-fingerprint_ipsec-shadow`

Tài liệu này bám theo cú pháp trong IModule Lab 2 mẫu do người dùng cung cấp: `GLOBAL_SETTINGS`, `NETWORK`, `CONTAINER`, `PASSWORD`, `SCRIPT NONE`, `instr_config/results.config` và `instr_config/goals.config`.

## A. Cài gói lab và mở bằng labedit

1. Trong VM Labtainers, chạy `echo "$LABTAINER_DIR"`.
2. Giải nén thư mục `vpn-fingerprint_ipsec-shadow` vào `$LABTAINER_DIR/labs/`. Đường dẫn cuối phải là `$LABTAINER_DIR/labs/vpn-fingerprint_ipsec-shadow/config/start.config`.
3. Trong thư mục lab, chạy `bash scripts/preflight.sh`. Chỉ tiếp tục khi hiện `PREFLIGHT=PASS`.
4. Chạy `labedit` → **File → Open lab** → `vpn-fingerprint_ipsec-shadow`.
5. Xác nhận có đúng năm container và hai mạng. Không tạo lại các container nếu topology đã được tải.

## B. Topology cần đối chiếu

| Container | User / password | Terminals | Network/IP |
|---|---|---:|---|
| `client1` | `ubuntu` / `ubuntu` | 1 | `client-net` — `10.0.1.100` |
| `client2` | `ubuntu` / `ubuntu` | 1 | `client-net` — `10.0.1.101` |
| `gateway` | `ubuntu` / `ubuntu` | 2 | `client-net` — `10.0.1.1`; `external-net` — `10.0.2.1` |
| `ipsec-gw` | `ubuntu` / `ubuntu` | 1 | `external-net` — `10.0.2.10` |
| `shadow-ipsec` | `ubuntu` / `ubuntu` | 1 | `external-net` — `10.0.2.30` |

Network names are case-sensitive in documentation and must match exactly: `client-net` = `10.0.1.0/24` and `external-net` = `10.0.2.0/24`. Both external network gateway settings are `.254`, while the lab's `gateway` container routes between `.1` addresses. Per-container `LAB_GATEWAY` settings are written in `config/start.config`.

## C. Dockerfile and Zeek

For each container, its Dockerfile must be named `dockerfiles/Dockerfile.vpn-fingerprint_ipsec-shadow.<container>.student`. The network3 base image is Ubuntu-based. The `gateway` Dockerfile installs `tshark`, Python, verified Scapy source and Zeek 8.0. The official Zeek OBS repository currently publishes the `zeek-8.0` package for Ubuntu 24.04; the image must be able to access Ubuntu APT, PyPI's file host and `download.opensuse.org` during build. Do not manually edit package names unless you have the complete APT error.

## D. Results và Goals

Trong `labedit`, mở **Results** và đối chiếu đúng các ID trong `instr_config/results.config`:

- `_baseline_ok`
- `_authorized_ok`
- `_shadow_ok`
- `_pcap_ok`
- `_eval_pass`

Mở **Goals** và đối chiếu goal `correct_ipsec_fingerprinting`. Đây là cú pháp dạng marker `CONTAINS` giống IModule mẫu. Các marker được in bởi `evaluate-ipsec.sh` và `validate-pcaps.sh`; goal chỉ đạt khi đã tạo PCAP và chạy các script đánh giá trong terminal gateway, chứ không phải ngay sau khi build.

## E. Build và kiểm tra mạng

1. Chọn **Run → Build and run**.
2. Nếu build lỗi, mở log build và tìm lỗi đầu tiên, không chỉ dòng `exit code: 100`.
3. Trên VM host, kiểm tra `docker ps` để xác nhận container được tạo.
4. Trong `gateway`, chạy `ip -br addr` và `ip route`. Tìm interface theo IP `10.0.1.1` và `10.0.2.1`; đừng giả định mạng ngoài luôn là `eth0`.
5. Ping `10.0.2.10` và `10.0.2.30` từ `gateway`. Sau đó kiểm tra `ipsec statusall` trên hai server và trên `client2`.
6. Chạy theo `docs/student-guide.md`. Đối với capture, dùng `tcpdump -ni any` để không phụ thuộc thứ tự interface.
7. Cuối bài, chạy `validate-pcaps.sh`, `detect-baseline.sh`, `detect-tunnel.sh`, `evaluate-ipsec.sh`, rồi **Run → Checkwork**.

## F. Khắc phục lỗi rebuild

- `PREFLIGHT=FAIL ... symlink`: giải nén ZIP bằng `unzip` vào Linux filesystem, chạy lại `bash scripts/preflight.sh`; script dựng lại các symlink đã khai báo rồi rebuild archive.
- `Unable to locate package`: kiểm tra phần `E:` đầy đủ trong log. Dockerfile thêm component `universe` trong `.list`/`.sources`; không thêm `python3-scapy` vào APT vì Scapy được cài từ source archive đã xác minh.
- lỗi Zeek: kiểm tra `curl`, `gpg`, DNS và kết nối `download.opensuse.org`, sau đó đọc APT error gần nhất. Không bỏ qua lỗi Zeek chỉ để Docker build có vẻ thành công.
- `Operation not permitted` khi khởi tạo IPsec: đây là lỗi quyền/kernel XFRM cần kiểm tra trên VM đích; `preflight` tĩnh không thể xác nhận capability runtime.
