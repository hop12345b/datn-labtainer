# Troubleshooting — Lab 3

## 1. strongSwan không khởi động / `Operation not permitted`

Trên container bị lỗi, xem `systemctl status strongswan-starter`, `journalctl -u strongswan-starter -n 80`, `ipsec statusall`, `ip xfrm state`. IPsec dùng kernel của host VM; không thể khắc phục chỉ bằng cài thêm package trong container nếu kernel không có XFRM hoặc container thiếu quyền mạng. Xác minh VM/kernel hỗ trợ XFRM và Labtainers không chạy container với chế độ cấm network administration. Chỉ trong lab cô lập mới cân nhắc sửa cấu hình quyền; không bật privileged cho dịch vụ không cần thiết.

## 2. `no trusted key` / `peer not authenticated`

So sánh local/remote IKE ID (`@client2-corp`, `@corp-gateway`, `@client2-shadow`, `@shadow-gateway`) với thứ tự ID trong `/etc/ipsec.secrets` ở cả hai đầu. Kiểm tra quyền file `600`, PSK khớp ký tự và version `keyexchange`. Xem log bằng `journalctl -u strongswan-starter` hoặc tăng `charondebug` tạm thời.

## 3. NAT-T xuất hiện khác dự kiến

NAT-T là kết quả thương lượng; router của lab SNAT có chọn lọc các gói UDP hướng đến corporate peer. Kiểm tra `iptables -t nat -S POSTROUTING`, `tcpdump -ni any 'udp port 500 or udp port 4500'` và `ipsec statusall`. Đừng dùng `forceencaps=yes` như cách sửa mặc định nếu mục tiêu là quan sát sự khác nhau do NAT thật.

## 4. ESP không hiện hoặc `esp.spi` rỗng trong tshark

Trước tiên chạy `tshark -G protocols | grep -Ei 'ESP|Encapsulating Security'`. Capture trên `gateway` bằng `tcpdump -ni any` cần nhìn thấy traffic raw ESP của phiên không dùng NAT-T; traffic ESP-in-UDP sẽ được nhìn dưới UDP 4500 và cần dissect khác. Xác minh `ip xfrm state`, `ip xfrm policy`, `ipsec statusall`, interface capture và PCAP đúng thời gian tunnel. `tcpdump` không thể hiện protocol 50 nếu mọi dữ liệu đang được đóng gói trong UDP/4500.

## 5. Xung đột subnet 10.8.0.0/24

Lab này dùng hai mạng outer topology 10.0.1.0/24 và 10.0.2.0/24 cùng traffic selectors host `/32`. Không tự ý dùng cùng một subnet selector cho hai connection; điều đó có thể tạo policy route chồng lấn. So sánh `ip route`, `ip xfrm policy` và selector hai connection; giữ từng selector tách biệt hoặc dùng subnet khác không trùng topology.

## 6. PCAP toàn TCP, không có ESP

Có thể tunnel chưa lên, request bị lỗi hoặc chọn sai interface. Trên client2 chạy `ipsec statusall`, `ip xfrm state`, `ip xfrm policy`; trên server kiểm tra CHILD_SA; sau đó capture đồng thời trên `gateway` và thử `curl -v http://10.0.2.30/` khi tunnel shadow đang up. Tăng số lần request. Không giả lập ESP bằng packet thủ công để vượt qua kiểm tra.

## 7. Zeek không tạo `ike.log`

Đây không mặc định là lỗi PCAP. Zeek standard logs thường có `conn.log` và log cho analyzer nhận diện được. Xác minh `zeek --version`, xem log lỗi đầu ra và danh sách file đã tạo. Dùng tshark/Scapy cho IKE/ESP khi chưa triển khai package/script Zeek hỗ trợ tương ứng; chỉ kỳ vọng `ike.log`/`esp.log` khi script đó được cài và kiểm thử.
