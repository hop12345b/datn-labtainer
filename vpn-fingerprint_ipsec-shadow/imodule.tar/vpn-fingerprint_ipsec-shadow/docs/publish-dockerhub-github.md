# Publish Lab 3 lên Docker Hub và GitHub

Tài liệu này dành cho người phát triển lab. Chỉ phát hành sau khi đã build, khởi động cả năm container và kiểm tra phiên IPsec trên chính VM Labtainers đang dùng.

## 1. Chuẩn bị

- Docker Hub account với quyền đẩy repository.
- `LABTAINER_DIR` trỏ tới đúng cây `trunk` của bản Labtainers.
- Lab đã nằm dưới `$LABTAINER_DIR/labs/vpn-fingerprint_ipsec-shadow`.
- Bộ công cụ designer/publish được cài. Nếu `publish.py` không tồn tại, cài phần Lab Designer theo hướng dẫn NPS (`update-designer.sh`) cho đúng bản Labtainers.

`REGISTRY` trong `start.config` giữ namespace Docker Hub cho image của lab theo mẫu IModule tham chiếu. Không thêm `BASE_REGISTRY` vào `start.config`: parser của phiên bản Labtainers tham chiếu trong mẫu không nhận thiết lập này. Các Dockerfile giữ `ARG registry=labtainers` làm mặc định cho image nền `labtainer.network3`; lệnh publish của Labtainers truyền tham số registry riêng trong quá trình build. Nếu Docker ID thật của bạn khác `hop12345b`, sửa giá trị `REGISTRY` trước khi phát hành.

## 2. Đăng nhập và publish image

Trên VM host, không phải trong container lab:

```bash
docker login --username <DOCKER_ID>
cd "$LABTAINER_DIR/distrib"
./publish.py -d -l vpn-fingerprint_ipsec-shadow
```

Thay `<DOCKER_ID>` bằng Docker ID thật. Nên dùng Docker Hub Personal Access Token thay vì mật khẩu. Đọc toàn bộ output; chỉ xem là thành công khi push của từng image kết thúc không có lỗi. Sau đó mở Docker Hub, kiểm tra image names được in ra bởi `publish.py` và để repository Public nếu sinh viên phải pull mà không cần đăng nhập.

Nếu `publish.py` không nhận cờ ở bản hiện tại, chạy `./publish.py -h` và theo hướng dẫn của chính bản cài; không đoán tên option. Không đẩy image khi build đang lỗi hoặc tunnel chưa được kiểm tra.

## 3. GitHub source và IModule

Đưa mã nguồn lab (config, Dockerfile, thư mục container, scripts, instr_config, docs) vào repository Git đã được tổ chức cho Labtainers IModule. Không chỉ upload ZIP chứa mã nguồn nếu mục tiêu là import bằng lệnh `imodule`.

Trong cây Labtainers có hỗ trợ IModule, tìm helper được cài thực tế:

```bash
command -v create-imodules.sh || find "$LABTAINER_DIR" -name create-imodules.sh -type f
```

Dùng đúng quy trình của repository IModule để tạo `imodule.tar`; không tự tạo TAR chỉ từ thư mục Dockerfile. Mở kết quả và xác nhận trong archive có đường dẫn `labs/vpn-fingerprint_ipsec-shadow/` cùng các archive `home_tar/home.tar` và `sys_tar/sys.tar` của cả năm container. Phát hành file `imodule.tar` như một GitHub Release asset cùng tag/version, và giữ mã nguồn trong Git để có lịch sử thay đổi.

## 4. Kiểm thử từ VM sạch

Trên VM Labtainers khác, tải file từ GitHub Release rồi chạy `imodule <URL-hoặc-file-theo-hướng-dẫn-IModule-của-bản-cài>`. Sau khi import, chạy:

```bash
labtainer vpn-fingerprint_ipsec-shadow
```

Xác nhận người dùng sạch có thể pull các image công khai và lab bắt đầu mà không phải build lại tại chỗ. Nếu `imodule` yêu cầu cấu trúc URL khác, dùng thông báo `imodule -h` của bản cài để làm theo đúng cú pháp.

## 5. Giới hạn cần ghi nhận

Đẩy thành công image và import thành công IModule là hai phép kiểm tra khác nhau. Trước khi phát hành lớp học, cần kiểm tra cả hai, cộng với `ipsec statusall`, `ip xfrm state`, validator PCAP và Checkwork. Bài lab này yêu cầu ESP thật trong PCAP; không thay bằng gói giả.

Tài liệu tham khảo:

- Labtainers repository: https://github.com/mfthomps/Labtainers
- NPS Labtainers: https://nps.edu/web/c3o/labtainers
- Lab Designer: https://nps.edu/documents/107523844/117289221/labdesigner.pdf
