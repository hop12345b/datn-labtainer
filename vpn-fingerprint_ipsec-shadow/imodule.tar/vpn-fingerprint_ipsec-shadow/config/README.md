# Lab 3 configuration

`start.config` follows the same Labtainers configuration conventions as the supplied working Lab 2 IModule. The gateway interfaces are discovered by IP address at startup; scripts do not depend on eth0/eth1 ordering.
