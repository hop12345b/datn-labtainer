#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LAB_NAME=vpn-fingerprint_stunnel-https
CONTAINERS=(client gateway stunnel-srv https-srv fake-https)
fail(){ echo "PREFLIGHT=FAIL: $*" >&2; exit 1; }
command -v python3 >/dev/null 2>&1 || fail 'python3 is required'
command -v openssl >/dev/null 2>&1 || fail 'openssl is required to generate demo certificates if missing'
# Certificates are pre-generated in the package; generate them only if missing.
bash "$ROOT/scripts/gen-certs.sh" || fail 'certificate generation failed'
python3 "$ROOT/scripts/normalize-links.py" || fail 'systemd link normalization failed'
python3 "$ROOT/scripts/build-archives.py" || fail 'archive generation failed'
[[ -s "$ROOT/config/start.config" ]] || fail 'missing config/start.config'
[[ -s "$ROOT/instr_config/results.config" ]] || fail 'missing instr_config/results.config'
[[ -s "$ROOT/instr_config/goals.config" ]] || fail 'missing instr_config/goals.config'
[[ -s "$ROOT/docs/student-guide.pdf" ]] || fail 'missing docs/student-guide.pdf'
grep -q '^GLOBAL_SETTINGS$' "$ROOT/config/start.config" || fail 'GLOBAL_SETTINGS missing'
grep -Eq '^[[:space:]]+LAB_MASTER_SEED[[:space:]]+[^[:space:]]+' "$ROOT/config/start.config" || fail 'LAB_MASTER_SEED missing'
grep -Eq '^[[:space:]]+COLLECT_DOCS yes$' "$ROOT/config/start.config" || fail 'COLLECT_DOCS syntax unexpected'
grep -Eq '^[[:space:]]+CHECKWORK yes$' "$ROOT/config/start.config" || fail 'CHECKWORK syntax unexpected'
for c in "${CONTAINERS[@]}"; do
  grep -q "^CONTAINER $c$" "$ROOT/config/start.config" || fail "container missing from start.config: $c"
  [[ -s "$ROOT/$c/sys_tar/sys.tar" ]] || fail "$c sys_tar/sys.tar missing"
  [[ -s "$ROOT/$c/home_tar/home.tar" ]] || fail "$c home_tar/home.tar missing"
  tar -tf "$ROOT/$c/sys_tar/sys.tar" >/dev/null || fail "$c sys.tar unreadable"
  tar -tf "$ROOT/$c/home_tar/home.tar" >/dev/null || fail "$c home.tar unreadable"
  [[ -f "$ROOT/dockerfiles/Dockerfile.$LAB_NAME.$c.student" ]] || fail "$c Dockerfile missing"
  grep -q 'ADD \$labdir/\$imagedir/sys_tar/sys.tar /' "$ROOT/dockerfiles/Dockerfile.$LAB_NAME.$c.student" || fail "$c Dockerfile sys.tar ADD missing"
  grep -q 'ADD \$labdir/\$imagedir/home_tar/home.tar \$HOME' "$ROOT/dockerfiles/Dockerfile.$LAB_NAME.$c.student" || fail "$c Dockerfile home.tar ADD missing"
  grep -q 'ln -sfn /usr/bin/python3 /usr/bin/python' "$ROOT/dockerfiles/Dockerfile.$LAB_NAME.$c.student" || fail "$c Dockerfile Python compatibility alias missing"
done
# Topology sanity: count unique container IP addresses from the documented network assignments.
python3 - "$ROOT/config/start.config" <<'PYTOPO'
import ipaddress,re,sys
text=open(sys.argv[1],encoding='utf-8').read().splitlines(); networks={}; current=None; ips=[]; containers=[]
for n,raw in enumerate(text,1):
 s=raw.strip()
 if not s or s.startswith('#'): continue
 m=re.match(r'^NETWORK\s+(\S+)$',s)
 if m: current=('net',m.group(1)); networks[current[1]]={}; continue
 m=re.match(r'^CONTAINER\s+(\S+)$',s)
 if m: current=('container',m.group(1)); containers.append(current[1]); continue
 if current and current[0]=='net':
  if s.startswith('MASK '): networks[current[1]]['mask']=ipaddress.ip_network(s.split()[1],strict=False)
  continue
 if current and current[0]=='container':
  p=s.split()
  if len(p)==2 and p[0] in networks:
   addr=ipaddress.ip_address(p[1])
   if 'mask' not in networks[p[0]] or addr not in networks[p[0]]['mask']: raise SystemExit('invalid IP/network at line {}'.format(n))
   ips.append(str(addr))
if containers != ['client','gateway','stunnel-srv','https-srv','fake-https']: raise SystemExit('unexpected container order/names: {}'.format(containers))
if len(set(ips)) != 6 or len(ips) != 6: raise SystemExit('expected 6 unique IPs across 5 containers (gateway has two), got {}'.format(ips))
print('TOPOLOGY=PASS')
PYTOPO
# Link integrity: exact source links must remain symlinks and point to service files.
python3 - "$ROOT" <<'PYLINK'
import os,sys
from pathlib import Path
root=Path(sys.argv[1])
for c in ('gateway','stunnel-srv','https-srv','fake-https'):
 wants=root/c/'_system/etc/systemd/system/multi-user.target.wants'
 if not wants.is_dir(): raise SystemExit('WANTS_DIR_MISSING: {}'.format(wants))
 for link in wants.iterdir():
  if not link.is_symlink(): raise SystemExit('SYSTEMD_WANTS_NOT_SYMLINK: {}'.format(link))
  if not (link.parent/os.readlink(str(link))).resolve().exists(): raise SystemExit('SYSTEMD_LINK_TARGET_MISSING: {}'.format(link))
PYLINK
# Validate Dockerfile services/scripts are present in system archive/source tree.
for item in \
 'client/_system/etc/stunnel/stunnel-client.conf' \
 'client/_system/etc/openvpn/client/client.ovpn' \
 'stunnel-srv/_system/etc/stunnel/stunnel-srv.conf' \
 'stunnel-srv/_system/etc/openvpn/server/server.conf' \
 'https-srv/_system/etc/nginx/sites-available/default' \
 'fake-https/_system/etc/stunnel/fake-https.conf' \
 'gateway/detect_stunnel.py' 'gateway/evaluate.py' 'gateway/entropy_analyzer.py' 'gateway/ja3.zeek'; do
 [[ -s "$ROOT/$item" ]] || fail "required file missing/empty: $item"
done
# Shell syntax checks
while IFS= read -r -d '' f; do bash -n "$f" || fail "bash syntax error: ${f#$ROOT/}"; done < <(find "$ROOT" -type f -name '*.sh' -print0)
# Python syntax compile without writing .pyc files
python3 - "$ROOT" <<'PYCHECK'
from pathlib import Path
import sys
root=Path(sys.argv[1])
for p in root.rglob('*.py'):
 try: compile(p.read_text(encoding='utf-8'), str(p), 'exec')
 except Exception as exc: raise SystemExit('PYTHON_SYNTAX_ERROR {}: {}'.format(p,exc))
print('PYTHON_SYNTAX=PASS')
PYCHECK
# Check Results/Goals IDs and syntax against reference format.
python3 - "$ROOT/instr_config/results.config" "$ROOT/instr_config/goals.config" <<'PYCFG'
import re,sys
res=set()
for i,line in enumerate(open(sys.argv[1],encoding='utf-8'),1):
 s=line.strip()
 if not s or s.startswith('#'): continue
 m=re.match(r'^(_[A-Za-z0-9_]+)\s*=\s*gateway:\*\.stdout\s*:\s*CONTAINS\s*:\s*\S.+$',s)
 if not m: raise SystemExit('bad results.config line {}: {}'.format(i,s))
 res.add(m.group(1))
goals=0
for i,line in enumerate(open(sys.argv[2],encoding='utf-8'),1):
 s=line.strip()
 if not s or s.startswith('#'): continue
 m=re.match(r'^([A-Za-z0-9_]+)\s*=\s*boolean\s*:\s*\((.*)\)\s*$',s)
 if not m: raise SystemExit('bad goals.config line {}: {}'.format(i,s))
 refs=re.findall(r'_[A-Za-z0-9_]+',m.group(2))
 missing=[x for x in refs if x not in res]
 if missing: raise SystemExit('goal references missing result ids: {}'.format(missing))
 goals+=1
if not res or not goals: raise SystemExit('empty results/goals config')
print('RESULTS_GOALS_CONFIG=PASS')
PYCFG
# Ensure JA3 field references align with supported tshark field and no secret private key outside lab cert folder.
grep -q 'tls.handshake.ja3' "$ROOT/gateway/detect_stunnel.py" || fail 'detector missing tshark JA3 field'
grep -q 'PCAP_VALIDATION=PASS' "$ROOT/scripts/validate-pcaps.sh" || fail 'validator PASS marker missing'
for p in "$ROOT"/*/home_tar/home.tar "$ROOT"/*/sys_tar/sys.tar; do [[ -s "$p" ]] || fail "missing archive $p"; done
echo 'PREFLIGHT=PASS'
echo 'NOTE=Static checks only. Docker build, TUN access, live TLS/JA3 traffic and Checkwork require execution on the target Labtainers VM.'
