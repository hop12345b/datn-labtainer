#!/usr/bin/env python3
"""Populate Labtainers _system trees from the checked-in demo PKI and create valid home/sys TAR archives."""
import os, shutil, subprocess, tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONTAINERS = ("client", "gateway", "stunnel-srv", "https-srv", "fake-https")
CERTS = ROOT / "certs"
if not (CERTS / "ca.crt").exists():
    subprocess.run(["bash", str(ROOT / "scripts" / "gen-certs.sh")], check=True)

def copy(src, dst, mode=None):
    src, dst = Path(src), Path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    if mode is not None:
        os.chmod(dst, mode)

# Client: OpenVPN client PKI and local trusted lab CA used by curl/openssl.
copy(CERTS / "ca.crt", ROOT / "client" / "_system/etc/openvpn/client/pki/ca.crt")
copy(CERTS / "openvpn-client.crt", ROOT / "client" / "_system/etc/openvpn/client/pki/client.crt")
copy(CERTS / "openvpn-client.key", ROOT / "client" / "_system/etc/openvpn/client/pki/client.key", 0o600)
copy(CERTS / "ca.crt", ROOT / "client/lab4-ca.crt")

# OpenVPN server behind stunnel; stunnel terminates the outer TLS wrapper.
copy(CERTS / "ca.crt", ROOT / "stunnel-srv/_system/etc/openvpn/server/pki/ca.crt")
copy(CERTS / "openvpn-server.crt", ROOT / "stunnel-srv/_system/etc/openvpn/server/pki/server.crt")
copy(CERTS / "openvpn-server.key", ROOT / "stunnel-srv/_system/etc/openvpn/server/pki/server.key", 0o600)
copy(CERTS / "stunnel-srv.pem", ROOT / "stunnel-srv/_system/etc/stunnel/lab4-stunnel.pem", 0o600)

# Real HTTPS certificate is signed by the lab CA so the client can verify it explicitly.
copy(CERTS / "shop.crt", ROOT / "https-srv/_system/etc/ssl/lab4/shop.crt")
copy(CERTS / "shop.key", ROOT / "https-srv/_system/etc/ssl/lab4/shop.key", 0o600)

# Fake TLS endpoint deliberately has a self-signed certificate and a silent non-HTTP backend.
copy(CERTS / "fake-https.pem", ROOT / "fake-https/_system/etc/stunnel/lab4-fake.pem", 0o600)

EXCLUDE_HOME = {"_system", "_bin", "sys_tar", "home_tar", "INSTRUCTIONS.txt"}
for name in CONTAINERS:
    croot = ROOT / name
    sysroot = croot / "_system"
    if not sysroot.is_dir():
        raise SystemExit("Missing system tree: " + str(sysroot))
    sys_dir = croot / "sys_tar"
    home_dir = croot / "home_tar"
    sys_dir.mkdir(exist_ok=True)
    home_dir.mkdir(exist_ok=True)
    for archive_path, source_root in ((sys_dir / "sys.tar", sysroot), (home_dir / "home.tar", croot)):
        with tarfile.open(archive_path, "w", format=tarfile.PAX_FORMAT) as tar:
            if source_root == sysroot:
                for item in sorted(source_root.rglob("*")):
                    tar.add(item, arcname=item.relative_to(source_root).as_posix(), recursive=False)
            else:
                for item in sorted(source_root.iterdir()):
                    if item.name in EXCLUDE_HOME or item.name.startswith("."):
                        continue
                    # Only files and links belong in the normal home archive; config trees stay in the source lab.
                    if item.is_file() or item.is_symlink():
                        tar.add(item, arcname=item.name, recursive=False)
        with tarfile.open(archive_path, "r:") as tar:
            tar.getmembers()
    print("ARCHIVES_OK=" + name)
print("ARCHIVE_BUILD=PASS")
