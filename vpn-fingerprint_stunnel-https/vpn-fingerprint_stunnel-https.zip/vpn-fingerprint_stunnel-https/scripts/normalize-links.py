#!/usr/bin/env python3
"""Restore known Labtainers systemd symlinks without hiding missing service targets."""
import os, shutil
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
LINKS = {
  "gateway": {"_system/etc/systemd/system/multi-user.target.wants/lab4-gateway.service": "../lab4-gateway.service"},
  "stunnel-srv": {
    "_system/etc/systemd/system/multi-user.target.wants/lab4-openvpn-server.service": "../lab4-openvpn-server.service",
    "_system/etc/systemd/system/multi-user.target.wants/lab4-stunnel-server.service": "../lab4-stunnel-server.service",
  },
  "https-srv": {
    "_system/etc/systemd/system/multi-user.target.wants/lab4-https.service": "../lab4-https.service",
    "_system/etc/systemd/system/multi-user.target.wants/lab4-dnsmasq.service": "../lab4-dnsmasq.service",
  },
  "fake-https": {"_system/etc/systemd/system/multi-user.target.wants/lab4-fake-https.service": "../lab4-fake-https.service"},
}
def remove(p):
    if p.is_symlink() or p.is_file(): p.unlink()
    elif p.is_dir(): shutil.rmtree(str(p))
for container, values in LINKS.items():
    for rel, target in values.items():
        p = ROOT / container / rel
        target_path = (p.parent / target).resolve()
        if not target_path.exists():
            raise SystemExit("SYMLINK_TARGET_MISSING: {} -> {}".format(p.relative_to(ROOT), target_path))
        p.parent.mkdir(parents=True, exist_ok=True)
        if not (p.is_symlink() and os.readlink(str(p)) == target):
            remove(p)
            os.symlink(target, str(p))
        print("SYMLINK_OK={} -> {}".format(p.relative_to(ROOT), target))
print("SYMLINK_NORMALIZATION=PASS")
