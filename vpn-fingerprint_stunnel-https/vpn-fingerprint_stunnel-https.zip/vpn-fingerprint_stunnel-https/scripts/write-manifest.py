#!/usr/bin/env python3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
lines=[]
for p in sorted(ROOT.rglob('*')):
    if p.is_file() and p.name != 'MANIFEST.txt' and '__pycache__' not in p.parts:
        lines.append('{}\t{} bytes'.format(p.relative_to(ROOT).as_posix(),p.stat().st_size))
for p in sorted(ROOT.rglob('*')):
    if p.is_symlink(): lines.append('{}\tSYMLINK -> {}'.format(p.relative_to(ROOT).as_posix(),p.readlink()))
(ROOT/'MANIFEST.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('MANIFEST_FILES={}'.format(len(lines)))
