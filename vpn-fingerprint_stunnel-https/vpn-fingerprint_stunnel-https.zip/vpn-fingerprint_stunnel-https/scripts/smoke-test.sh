#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
echo 'SMOKE_TEST=STATIC_ONLY'
bash "$ROOT/scripts/preflight.sh"
echo 'NEXT_ON_LABTAINER_HOST: rebuild vpn-fingerprint_stunnel-https -f'
echo 'NEXT_IN_LAB: baseline capture -> stop tunnel -> mixed capture -> validate-pcaps.sh -> zeek-run.sh -> python3 evaluate.py'
echo 'SMOKE_TEST=PASS_STATIC_NOT_RUNTIME'
