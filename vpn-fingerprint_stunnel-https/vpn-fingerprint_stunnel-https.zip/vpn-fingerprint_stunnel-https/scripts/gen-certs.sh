#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CERT_DIR="$ROOT/certs"
FORCE="${1:-}"
mkdir -p "$CERT_DIR"
if [[ "$FORCE" != "--force" && -s "$CERT_DIR/ca.crt" && -s "$CERT_DIR/shop.crt" && -s "$CERT_DIR/openvpn-server.crt" && -s "$CERT_DIR/openvpn-client.crt" && -s "$CERT_DIR/stunnel-srv.crt" && -s "$CERT_DIR/fake-https.crt" ]]; then
  echo 'CERTIFICATES_ALREADY_PRESENT=1'
  exit 0
fi
rm -f "$CERT_DIR"/*
cd "$CERT_DIR"

openssl genrsa -out ca.key 2048
openssl req -x509 -new -key ca.key -sha256 -days 3650 \
  -subj '/CN=Lab 4 Training CA/O=Labtainers Training Only' -out ca.crt

issue_ca_signed() {
  name="$1"; cn="$2"; san="$3"; eku="$4"
  openssl genrsa -out "$name.key" 2048
  openssl req -new -key "$name.key" -subj "/CN=$cn/O=Labtainers Training Only" -out "$name.csr"
  cat > "$name.ext" <<EXT
basicConstraints=critical,CA:FALSE
keyUsage=critical,digitalSignature,keyEncipherment
extendedKeyUsage=$eku
subjectAltName=$san
EXT
  openssl x509 -req -in "$name.csr" -CA ca.crt -CAkey ca.key -CAcreateserial \
    -out "$name.crt" -days 1825 -sha256 -extfile "$name.ext"
}
issue_ca_signed shop 'shop.example.com' 'DNS:shop.example.com' 'serverAuth'
issue_ca_signed openvpn-server 'vpn.example.test' 'DNS:vpn.example.test,IP:10.0.2.10' 'serverAuth'
issue_ca_signed openvpn-client 'lab4-client' 'DNS:lab4-client' 'clientAuth'

openssl req -x509 -newkey rsa:2048 -nodes -keyout stunnel-srv.key -out stunnel-srv.crt \
  -days 1825 -sha256 -subj '/CN=stunnel-srv/O=Labtainers Training Only' \
  -addext 'subjectAltName=IP:10.0.2.10,DNS:stunnel-srv' \
  -addext 'keyUsage=digitalSignature,keyEncipherment' \
  -addext 'extendedKeyUsage=serverAuth'
openssl req -x509 -newkey rsa:2048 -nodes -keyout fake-https.key -out fake-https.crt \
  -days 1825 -sha256 -subj '/CN=fake-https/O=Labtainers Training Only' \
  -addext 'subjectAltName=IP:10.0.2.30,DNS:fake-https' \
  -addext 'keyUsage=digitalSignature,keyEncipherment' \
  -addext 'extendedKeyUsage=serverAuth'

cat shop.crt shop.key > shop.pem
cat stunnel-srv.crt stunnel-srv.key > stunnel-srv.pem
cat fake-https.crt fake-https.key > fake-https.pem
chmod 600 *.key *.pem
chmod 644 *.crt
rm -f *.csr *.ext ca.srl
cat > README.txt <<'TXT'
Lab 4 disposable training certificates. These keys and the included private training CA are ONLY for this isolated class lab. Never deploy them in production or reuse them in a real service.
shop.example.com is signed by the included lab CA. The stunnel and fake-https endpoints intentionally use self-signed certificates.
TXT
chmod 644 README.txt
printf 'CERTIFICATE_GENERATION=PASS\n'
