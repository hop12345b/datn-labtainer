#!/usr/bin/env bash
set -euo pipefail
sudo systemctl start lab4-stunnel-client.service
sleep 1
sudo systemctl start lab4-openvpn-client.service
for _ in $(seq 1 25); do
  if ip link show tun0 >/dev/null 2>&1; then
    echo 'OPENVPN_TUN0=UP'
    sudo systemctl --no-pager --full status lab4-openvpn-client.service || true
    exit 0
  fi
  sleep 1
done
echo 'OPENVPN_TUN0=NOT_UP; inspect journalctl -u lab4-openvpn-client -n 80'
sudo journalctl -u lab4-openvpn-client.service -n 40 --no-pager || true
exit 1
