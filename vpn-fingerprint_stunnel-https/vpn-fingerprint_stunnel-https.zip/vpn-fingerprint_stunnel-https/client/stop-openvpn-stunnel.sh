#!/usr/bin/env bash
set -u
sudo systemctl stop lab4-openvpn-client.service || true
sudo systemctl stop lab4-stunnel-client.service || true
echo 'OPENVPN_STUNNEL_STOPPED'
