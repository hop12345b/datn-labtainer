#!/usr/bin/env bash
set -euo pipefail
exec /home/ubuntu/traffic-generator.sh "$@"
