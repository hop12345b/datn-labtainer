#!/usr/bin/env bash
set -euo pipefail
mkdir -p /var/log/openvpn
if [ ! -c /dev/net/tun ]; then
  echo 'TUN_DEVICE_MISSING: /dev/net/tun is not available. Check the Labtainers runtime host/device configuration.' >&2
  exit 1
fi
exec /usr/sbin/openvpn --config /etc/openvpn/client/client.ovpn
