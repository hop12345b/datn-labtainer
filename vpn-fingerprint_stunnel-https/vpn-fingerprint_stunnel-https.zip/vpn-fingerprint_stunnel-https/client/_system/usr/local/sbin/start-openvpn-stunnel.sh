#!/usr/bin/env bash
set -euo pipefail
exec /home/ubuntu/start-openvpn-stunnel.sh "$@"
