#!/usr/bin/env bash
set -euo pipefail
exec /home/ubuntu/stop-openvpn-stunnel.sh "$@"
