#!/usr/bin/env bash
set -u
MODE="${1:-mixed}"
COUNT="${2:-100}"
if ! [[ "$COUNT" =~ ^[0-9]+$ ]] || (( COUNT < 1 )); then
  echo "Usage: traffic-generator.sh [https-only|mixed|noise] [iterations>=1]" >&2
  exit 2
fi
CA="/home/ubuntu/lab4-ca.crt"
https_real() {
  curl --noproxy '*' --connect-timeout 3 --max-time 8 --silent --show-error \
    --cacert "$CA" --resolve shop.example.com:443:10.0.2.20 \
    --http1.1 https://shop.example.com/ -o /dev/null
}
http_noise() {
  curl --noproxy '*' --connect-timeout 2 --max-time 3 -fsS http://10.0.2.20/ -o /dev/null
}
dns_noise() {
  if command -v dig >/dev/null 2>&1; then dig +time=1 +tries=1 @10.0.2.20 shop.example.com A >/dev/null 2>&1; fi
}
case "$MODE" in
  https-only|baseline)
    echo 'TRAFFIC_MODE=HTTPS_ONLY'
    https_real || { echo 'HTTPS_REAL_REQUEST=FAIL'; exit 1; }
    echo 'HTTPS_REAL_REQUEST=PASS'
    ;;
  noise)
    echo "TRAFFIC_MODE=NOISE COUNT=$COUNT"
    for ((i=1; i<=COUNT; i++)); do http_noise || true; dns_noise; sleep 0.02; done
    ;;
  mixed)
    echo "TRAFFIC_MODE=MIXED COUNT=$COUNT"
    # Restart after gateway capture starts so the outer TLS ClientHello is inside mixed_tls.pcap.
    if [ -x /home/ubuntu/start-openvpn-stunnel.sh ]; then
      /home/ubuntu/start-openvpn-stunnel.sh || echo 'OPENVPN_TUNNEL_START=FAIL'
    fi
    sleep 2
    https_real || echo 'HTTPS_REAL_REQUEST=FAIL'
    # One TLS client to the decoy, deliberately no SNI and no HTTP protocol.
    timeout 8 openssl s_client -connect 10.0.2.30:443 -brief </dev/null >/tmp/lab4-fake-client.log 2>&1 || true
    # Generate enough plain HTTP and DNS traffic to make the capture mixed/noisy.
    for ((i=1; i<=COUNT; i++)); do
      http_noise || true
      dns_noise || true
      if (( i % 10 == 0 )); then
        if ip link show tun0 >/dev/null 2>&1; then ping -I tun0 -c 1 -W 1 10.8.0.1 >/dev/null 2>&1 || true; fi
      fi
      sleep 0.025
    done
    echo 'MIXED_TRAFFIC_GENERATION=DONE'
    ;;
  *) echo "Unknown mode: $MODE" >&2; exit 2 ;;
esac
