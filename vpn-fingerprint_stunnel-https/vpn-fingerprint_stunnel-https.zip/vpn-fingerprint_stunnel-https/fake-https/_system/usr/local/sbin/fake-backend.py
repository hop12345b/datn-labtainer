#!/usr/bin/env python3
"""Accept forwarded TLS-plaintext connections but deliberately do not implement HTTP."""
import socketserver, time
class Handler(socketserver.BaseRequestHandler):
    def handle(self):
        self.request.settimeout(1.0)
        end = time.time() + 12.0
        while time.time() < end:
            try:
                data = self.request.recv(1024)
                if not data: time.sleep(0.2)
            except Exception:
                time.sleep(0.2)
class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True
if __name__ == '__main__':
    with Server(('127.0.0.1', 4444), Handler) as srv: srv.serve_forever()
