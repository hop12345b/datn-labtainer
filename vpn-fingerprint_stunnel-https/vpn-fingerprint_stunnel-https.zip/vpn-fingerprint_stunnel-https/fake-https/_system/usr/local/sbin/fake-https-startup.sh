#!/usr/bin/env bash
set -euo pipefail
mkdir -p /var/log/stunnel
/usr/bin/python3 /usr/local/sbin/fake-backend.py &
exec "$(command -v stunnel4 || command -v stunnel)" /etc/stunnel/fake-https.conf
