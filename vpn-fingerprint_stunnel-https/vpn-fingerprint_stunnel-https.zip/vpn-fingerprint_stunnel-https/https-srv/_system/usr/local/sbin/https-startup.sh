#!/usr/bin/env bash
set -euo pipefail
exec /usr/sbin/nginx -g 'daemon off;'
