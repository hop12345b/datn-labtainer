# Lab 4 configuration

`start.config` follows the syntax from the supplied working IModule example. The topology contains exactly five student containers and two isolated networks. `gateway` has two terminals, but is one container.

The OpenVPN inner connection intentionally uses **TCP/1194**, not UDP/1194, because stunnel forwards a TCP byte stream. Wrapping an OpenVPN UDP service with a TCP-only stunnel listener would not work as specified.

`parameter.config` is empty because this lab has no parameter substitutions beyond the standard Labtainers values.
