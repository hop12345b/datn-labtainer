# LAB 4 - TLS Fingerprinting: OpenVPN qua stunnel so với HTTPS thật

**Tên lab:** `vpn-fingerprint_stunnel-https`  
**Thời lượng khuyến nghị:** 2-3 giờ  
**Vai trò:** Network Security Analyst / Blue Team  
**Công cụ:** `tcpdump`, `tshark`, Zeek, Scapy (hỗ trợ), OpenSSL, stunnel, OpenVPN, Python 3.

> **Lưu ý kỹ thuật quan trọng:** stunnel bọc một dịch vụ TCP trong TLS. Vì vậy OpenVPN bên trong stunnel của lab này chạy **TCP/1194**, không phải UDP/1194. Một stunnel TCP listener không thể chuyển tiếp trực tiếp dịch vụ OpenVPN UDP như một luồng byte TCP.

> **Lưu ý về TLS:** sau khi TLS handshake hoàn tất, nội dung HTTP bên trong HTTPS được mã hóa. Một PCAP thông thường không thể hiển thị trực tiếp `GET /` ở bên trong TLS nếu không giải mã. Lab này so sánh SNI, JA3, TLS certificate (TLS 1.2 có chủ đích để certificate message dễ quan sát), metadata luồng và nhật ký server. Không dùng `http.request` như bằng chứng rằng HTTPS plaintext có sẵn trong PCAP.

## 1. Mục tiêu

Sau bài thực hành, sinh viên có thể:

1. Thu thập traffic của HTTPS thật, OpenVPN được bọc bởi stunnel và một TLS endpoint không cung cấp web.
2. So sánh SNI, JA3, phiên bản TLS và certificate chain quan sát được.
3. Dùng `tshark` và Zeek để phân tích TLS; biết JA3 trong Zeek cần script/package bổ sung.
4. Chỉnh tham số cấu hình của `detect_stunnel.py` và đánh giá phân loại flow.
5. Trình bày giới hạn của SNI, certificate, JA3 và entropy khi phát hiện tunnel.

## 2. Sơ đồ topology

| Container | IP | Vai trò |
|---|---|---|
| `client` | `10.0.1.100` | HTTPS, noise, stunnel client và OpenVPN client |
| `gateway` | `10.0.1.1`, `10.0.2.1` | Router, điểm capture, tshark/Zeek/detector |
| `stunnel-srv` | `10.0.2.10` | stunnel listener TCP/443 chuyển tới OpenVPN TCP/1194 trên localhost |
| `https-srv` | `10.0.2.20` | Nginx HTTP/80 và HTTPS/443 với SNI `shop.example.com` |
| `fake-https` | `10.0.2.30` | TLS listener TCP/443, self-signed cert, backend không phải HTTP |

- `CLIENT_NET`: `10.0.1.0/24`
- `EXTERNAL_NET`: `10.0.2.0/24`

`gateway` có hai terminal nhưng vẫn là một container. `client` không tự động bật tunnel khi khởi động; điều đó giúp tạo baseline trước khi có OpenVPN-stunnel.

## 3. Bước 1 - Khởi động và khám phá

### Trên Ubuntu host

```bash
cd /home/student/labtainer/labtainer-student
labtainer vpn-fingerprint_stunnel-https
```

### Trên Ubuntu host: kiểm tra đúng 5 container của lab

```bash
docker ps --filter 'name=vpn-fingerprint_stunnel-https' --format 'table {{.Names}}\t{{.Status}}'
```

### Trên `gateway`

```bash
ip -br addr
ip route
```

Xác nhận interface nối `10.0.2.1`; script capture tự tìm interface này thay vì giả định luôn là `eth0`.

### Trên `client`: kiểm tra HTTPS thật và SNI

```bash
timeout 8 openssl s_client -connect 10.0.2.20:443 -servername shop.example.com -CAfile /home/ubuntu/lab4-ca.crt -verify_return_error -brief </dev/null
```

Kiểm tra nội dung web:

```bash
curl --cacert /home/ubuntu/lab4-ca.crt --resolve shop.example.com:443:10.0.2.20 https://shop.example.com/
```

Kết quả HTML phải có `REAL_HTTPS_OK`.

## 4. Bước 2 - Bắt baseline HTTPS thật, chưa có tunnel

### Trên `gateway`, terminal 1

```bash
capture-traffic.sh start baseline
```

### Trên `client`

```bash
traffic-generator.sh https-only 1
```

### Trên `gateway`, terminal 1

```bash
capture-traffic.sh stop
ls -lh /home/ubuntu/https_only.pcap
```

Baseline phải được tạo trước khi chạy `start-openvpn-stunnel.sh`. Nó chứa HTTPS thật tới `10.0.2.20` và không có kết nối TLS tới `10.0.2.10`.

## 5. Bước 3 - Trích xuất SNI và JA3 từ baseline

### Trên `gateway`

Liệt kê ClientHello, destination, SNI và JA3:

```bash
tshark -n -r /home/ubuntu/https_only.pcap -Y 'tcp.port == 443 && tls.handshake.type == 1' -T fields -E header=y -e frame.time -e ip.src -e ip.dst -e tcp.srcport -e tls.handshake.extensions_server_name -e tls.handshake.ja3
```

Ghi nhận JA3 của HTTPS thật (destination `10.0.2.20`). Không chép một hash mẫu từ Internet: hash phụ thuộc TLS implementation, phiên bản OpenSSL/libcurl, TLS options và ClientHello được quan sát trong chính PCAP.

Kiểm tra tshark có JA3 field:

```bash
tshark -G fields | grep -F 'tls.handshake.ja3'
```

Chạy Zeek với script JA3 kèm theo:

```bash
zeek-run.sh /home/ubuntu/https_only.pcap /home/ubuntu/zeek_logs/https_only
```

Xem log TLS:

```bash
cat /home/ubuntu/zeek_logs/https_only/ssl.log | zeek-cut ts id.orig_h id.resp_h id.resp_p version server_name ja3
```

`ssl.log` chuẩn của Zeek cung cấp metadata TLS và SNI; trường `ja3` được thêm bởi `ja3.zeek` đi kèm lab. Xem `x509.log` nếu log certificate được tạo bởi phiên bản Zeek đã cài.

## 6. Bước 4 - Khởi động OpenVPN qua stunnel

### Trên `stunnel-srv`

```bash
sudo systemctl status lab4-openvpn-server.service --no-pager
sudo systemctl status lab4-stunnel-server.service --no-pager
sudo ss -ltnp | grep -E ':(443|1194)\b'
```

Kỳ vọng: stunnel nghe TCP/443 tại `10.0.2.10`; OpenVPN nghe TCP/1194 trên loopback. Không kỳ vọng UDP/1194 vì lab dùng stunnel TCP.

### Trên `client`

```bash
sudo systemctl start lab4-stunnel-client.service
sudo systemctl start lab4-openvpn-client.service
```

Hoặc dùng wrapper:

```bash
start-openvpn-stunnel.sh
```

Xác nhận tunnel:

```bash
ip -br addr show tun0
ip route
sudo systemctl --no-pager --full status lab4-openvpn-client.service
```

Gửi ping qua tunnel:

```bash
ping -I tun0 -c 4 -W 2 10.8.0.1
```

Nếu không có `tun0`, xem log:

```bash
sudo journalctl -u lab4-openvpn-client.service -n 80 --no-pager
sudo journalctl -u lab4-stunnel-client.service -n 80 --no-pager
```

Sau khi xác nhận được tunnel, dừng client tunnel để mixed capture ghi được handshake mới:

```bash
stop-openvpn-stunnel.sh
```

## 7. Bước 5 - Thu thập mixed TLS và noise (>=500 frame)

### Trên `gateway`, terminal 1

```bash
capture-traffic.sh start mixed
```

### Trên `client`

Lệnh này khởi động lại stunnel/OpenVPN sau khi capture bắt đầu, tạo một kết nối HTTPS thật, một TLS tới fake endpoint, lưu lượng HTTP/80 và DNS/53, đồng thời thử ping qua `tun0`:

```bash
traffic-generator.sh mixed 100
```

Chờ `MIXED_TRAFFIC_GENERATION=DONE`.

### Trên `gateway`, terminal 1

```bash
capture-traffic.sh stop
```

### Trên `gateway`: kiểm tra gói

```bash
ls -lh /home/ubuntu/mixed_tls.pcap

tshark -n -r /home/ubuntu/mixed_tls.pcap -Y 'tcp.port == 443 && tls.handshake.type == 1' -T fields -e ip.src -e ip.dst -e tcp.srcport -e tls.handshake.extensions_server_name -e tls.handshake.ja3
```

Đếm frame:

```bash
tshark -n -r /home/ubuntu/mixed_tls.pcap -T fields -e frame.number | tail -n 1
```

Kiểm tra endpoint TLS phải có ClientHello tới `10.0.2.10`, `10.0.2.20`, `10.0.2.30`. Dấu hiệu dự kiến: HTTPS thật gửi SNI `shop.example.com`; stunnel client và fake TLS probe không gửi SNI.

## 8. Bước 6 - Phân tích với tshark và Zeek

### Trên `gateway`

TLS ClientHello:

```bash
tshark -n -r /home/ubuntu/mixed_tls.pcap -Y 'tcp.port == 443 && tls.handshake.type == 1' -T fields -E header=y -e frame.time -e ip.src -e ip.dst -e tls.handshake.extensions_server_name -e tls.handshake.ja3
```

Tổng hợp JA3 theo endpoint:

```bash
tshark -n -r /home/ubuntu/mixed_tls.pcap -Y 'tls.handshake.type == 1 && tls.handshake.ja3' -T fields -e ip.dst -e tls.handshake.extensions_server_name -e tls.handshake.ja3 | sort -u
```

Certificate TLS 1.2 trong capture:

```bash
tshark -n -r /home/ubuntu/mixed_tls.pcap -Y 'tls.handshake.type == 11' -T fields -e ip.src -e ip.dst -e tls.handshake.certificate
```

Chạy Zeek:

```bash
zeek-run.sh /home/ubuntu/mixed_tls.pcap /home/ubuntu/zeek_logs/mixed_tls
```

Xem SSL/SNI/JA3:

```bash
cat /home/ubuntu/zeek_logs/mixed_tls/ssl.log | zeek-cut ts id.orig_h id.resp_h id.resp_p version server_name ja3
```

Xem connection:

```bash
cat /home/ubuntu/zeek_logs/mixed_tls/conn.log | zeek-cut id.orig_h id.resp_h id.resp_p proto service orig_bytes resp_bytes conn_state
```

Xem HTTP thường (port 80):

```bash
cat /home/ubuntu/zeek_logs/mixed_tls/http.log | zeek-cut id.orig_h id.resp_h method host uri status_code
```

Lưu ý: `http.log` ghi HTTP không mã hóa có thể phân tích được. Nó không tự giải mã HTTP bên trong HTTPS. Thông tin certificate có thể nằm trong `x509.log`; các log khác phụ thuộc traffic và analyzer.

## 9. Bước 7 - Phân tích entropy

```bash
python3 /home/ubuntu/entropy_analyzer.py /home/ubuntu/mixed_tls.pcap 10.0.2.10 10.0.2.20 10.0.2.30
```

Entropy cao là một tín hiệu không đặc hiệu: TLS hợp lệ, nén và nhiều định dạng binary cũng có thể có entropy cao. Không dùng entropy đơn lẻ làm kết luận VPN.

## 10. Bước 8 - Chỉnh detector có sẵn

Mở file:

```bash
nano /home/ubuntu/detect_stunnel.py
```

Các tham số ở đầu file:

- `TLS_PORT`: cổng TLS được quan sát.
- `EXPECTED_SNI`: SNI hợp lệ của website thật.
- `REQUIRE_SNI`: quyết định có đánh dấu flow thiếu SNI là đáng ngờ hay không.
- `JA3_WHITELIST`: danh sách hash thu từ HTTPS thật trong PCAP baseline.
- `MIN_JA3_HITS`: số flow mang JA3 không được whitelist trước khi áp dụng heuristic JA3.

Thử từng thay đổi, mỗi lần chạy detector trên cả hai PCAP và ghi lại false positive/false negative. Không chép sẵn một JA3 hash cố định vì môi trường và TLS implementation có thể khác nhau.

```bash
python3 /home/ubuntu/detect_stunnel.py /home/ubuntu/https_only.pcap
python3 /home/ubuntu/detect_stunnel.py /home/ubuntu/mixed_tls.pcap
```

## 11. Bước 9 - Đánh giá và lưu minh chứng

Chạy validator (kiểm tra thủ công về chất lượng PCAP):

```bash
validate-pcaps.sh
```

Sau đó chạy evaluator; đây là một lần gọi duy nhất và phát các marker dùng cho Checkwork:

```bash
python3 /home/ubuntu/evaluate.py
```

Khi đã hoàn tất, trên Ubuntu host:

```bash
stoplab
checkwork vpn-fingerprint_stunnel-https
```

Tài liệu minh chứng nên có: topology/IP, trạng thái tunnel, số frame PCAP, ClientHello/SNI/JA3 theo endpoint, trích đoạn `ssl.log`, tham số detector trước/sau, và output evaluator.

## 12. Câu hỏi thảo luận

1. Nếu kẻ tấn công thêm SNI giả `shop.example.com`, chỉ kiểm tra SNI còn đủ không?
2. Vì sao JA3 của hai client dùng TLS library/option khác nhau có thể khác, và vì sao JA3 không xác định chắc chắn ứng dụng?
3. JA3 phụ thuộc những thành phần nào của ClientHello? Điều gì có thể làm hash thay đổi giữa phiên bản thư viện?
4. Vì sao không thấy `GET /` trong PCAP HTTPS dù client đã truy cập web thành công?
5. Khi TLS 1.3 được dùng, certificate handshake có còn hiển thị giống TLS 1.2 trong capture thụ động không?
6. Certificate self-signed có phải bằng chứng chắc chắn của VPN không? Nêu các dịch vụ hợp lệ cũng dùng private/self-signed certificates.
7. Vì sao ba endpoint cùng TCP/443 vẫn có thể phân biệt được qua metadata mà không đọc payload ứng dụng?

## 13. Gợi ý 3 tầng

- **Tầng nhẹ:** tập trung vào cổng, SNI và sự hiện diện của JA3.
- **Tầng vừa:** đối chiếu JA3 giữa baseline và mixed capture, kiểm tra các trường hợp thiếu/không đúng SNI.
- **Tầng mạnh:** kết hợp metadata TLS, certificate, flow direction, log server và entropy; ghi lại false positive/false negative khi thay đổi tham số.

Không dùng một dấu hiệu duy nhất để kết luận có VPN. Mục tiêu là lập luận dựa trên nhiều bằng chứng.
