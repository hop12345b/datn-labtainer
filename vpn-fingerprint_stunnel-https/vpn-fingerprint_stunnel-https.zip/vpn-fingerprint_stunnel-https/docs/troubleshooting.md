# Lab 4 - Lỗi thường gặp

## 1. stunnel không forward

Trên `stunnel-srv`:
```bash
sudo journalctl -u lab4-stunnel-server.service -n 80 --no-pager
sudo ss -ltnp | grep ':443'
```
Kiểm tra `accept = 10.0.2.10:443`, `connect = 127.0.0.1:1194`, `lab4-stunnel.pem` tồn tại và OpenVPN server nghe TCP/1194.

## 2. OpenVPN client không kết nối qua stunnel

Trên `client`:
```bash
sudo journalctl -u lab4-openvpn-client.service -n 80 --no-pager
sudo journalctl -u lab4-stunnel-client.service -n 80 --no-pager
ss -ltnp | grep ':1443'
```
`client.ovpn` phải dùng `proto tcp-client` và `remote 127.0.0.1 1443`; stunnel phải chuyển tới `10.0.2.10:443`. `float` là tùy chọn gắn với thay đổi địa chỉ peer trong một số cấu hình OpenVPN, không phải cách sửa mặc định cho lỗi TCP/stunnel.

## 3. OpenVPN báo không mở được TUN

```bash
ls -l /dev/net/tun
sudo journalctl -u lab4-openvpn-client.service -n 80 --no-pager
```
Nếu thiếu `/dev/net/tun` hoặc báo `Operation not permitted`, xác minh TUN kernel và device/capability mà Labtainers cấp cho container. Cài package OpenVPN không tự cung cấp quyền truy cập thiết bị TUN.

## 4. JA3 không hiện trong tshark

```bash
tshark --version
tshark -G fields | grep -F 'tls.handshake.ja3'
```
Trường JA3 được Wireshark hỗ trợ từ các phiên bản bắt đầu ở dòng 3.6. Nếu thiếu field, kiểm tra phiên bản Wireshark/tshark. Capture phải chứa TLS ClientHello đầy đủ.

## 5. SNI không hiện

SNI nằm trong ClientHello khi client gửi extension server_name. `stunnel` đang kết nối tới địa chỉ IP và cấu hình không khai báo SNI, nên SNI trống là dấu hiệu dự kiến. Đừng nhầm SNI rỗng với lỗi tshark nếu chỉ endpoint stunnel/fake bị rỗng.

## 6. Certificate không khớp domain hoặc bị self-signed

HTTPS thật dùng `shop.example.com`, cert SAN phù hợp và lab CA tại `/home/ubuntu/lab4-ca.crt`. Thử:
```bash
curl --cacert /home/ubuntu/lab4-ca.crt --resolve shop.example.com:443:10.0.2.20 https://shop.example.com/
```
Không dùng `-k` để chứng minh certificate hợp lệ; `-k` tắt xác minh. stunnel/fake endpoint cố ý dùng self-signed cert.

## 7. fake-https handshake rồi EOF/timeout

Trên `fake-https`:
```bash
sudo journalctl -u lab4-fake-https.service -n 80 --no-pager
sudo ss -ltnp | grep -E ':(443|4444)'
```
Backend chỉ giữ socket và không phục vụ HTTP. Client có thể hoàn tất TLS rồi chờ/nhận EOF; điều này là một phần kịch bản, không phải HTTPS thật bị lỗi.

## 8. Nginx không start vì port 443 bận

Nginx chỉ thuộc `https-srv` (`10.0.2.20`). stunnel server dùng `10.0.2.10:443`; fake-https dùng `10.0.2.30:443`. Kiểm tra IP/interface thực tế và không khởi động hai listener trên cùng địa chỉ IP:cổng bên trong cùng container.

## 9. Zeek không tạo JA3 trong ssl.log

Stock Zeek không nhất thiết có trường `ja3`. Dùng script kèm lab:
```bash
zeek-run.sh /home/ubuntu/mixed_tls.pcap /home/ubuntu/zeek_logs/mixed_tls
```
Sau đó kiểm tra `ssl.log`, `tlsfp.log` và `zeek-run.sh` output. Nếu Zeek báo lỗi script, lưu phiên bản Zeek và log; không tự xóa `@load`/script để ép tiếp tục.

## 10. Validator báo mixed PCAP ít hơn 500 frame hoặc thiếu endpoint

Bảo đảm capture bắt đầu trước khi khởi động lại tunnel. Trên client chạy `traffic-generator.sh mixed 100`, rồi stop capture sau khi có `MIXED_TRAFFIC_GENERATION=DONE`. Kiểm tra `ip route`, trạng thái `tun0`, và ClientHello tới cả ba IP `10.0.2.10`, `.20`, `.30`.
