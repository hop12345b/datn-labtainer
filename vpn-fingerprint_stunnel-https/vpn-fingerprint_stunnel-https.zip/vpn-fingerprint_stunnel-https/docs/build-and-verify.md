# Build, run and verify

## On the Labtainers VM host

```bash
cd "$LABTAINER_DIR/labs/vpn-fingerprint_stunnel-https"
bash scripts/preflight.sh
```

If preflight passes:

```bash
cd "$LABTAINER_DIR/scripts/labtainer-student"
rebuild vpn-fingerprint_stunnel-https -f
```

Then run:

```bash
labtainer vpn-fingerprint_stunnel-https
```

## Runtime smoke test

1. On `gateway`, verify two interfaces and forwarding: `ip -br addr`, `sysctl net.ipv4.ip_forward`.
2. On `https-srv`, check `systemctl status lab4-https lab4-dnsmasq` and `ss -ltnup`.
3. On `stunnel-srv`, check `systemctl status lab4-openvpn-server lab4-stunnel-server` and listeners 10.0.2.10:443 + loopback:1194.
4. On `fake-https`, check `systemctl status lab4-fake-https` and listener 10.0.2.30:443.
5. Do not start the client tunnel yet. Capture and generate `https_only.pcap`.
6. Start tunnel and verify tun0, then stop tunnel to prepare a mixed-capture handshake.
7. Start mixed capture, run `traffic-generator.sh mixed 100`, then stop capture.
8. Run `validate-pcaps.sh`, `zeek-run.sh`, `detect_stunnel.py` and `evaluate.py`.
9. On the host run `stoplab`, then `checkwork vpn-fingerprint_stunnel-https`.

## Build portability

The gateway Dockerfile uses Zeek's official OBS repositories and selects Zeek 7.0 on Ubuntu 22.04, Zeek 8.0 on Ubuntu 24.04/26.04. Other base OS versions fail explicitly. Current Zeek support matrix/repository availability can change; if the image base differs, adjust only after checking official Zeek package instructions.

## Docker Hub / IModule distribution

Set `REGISTRY` in `config/start.config` to the publisher's Docker Hub namespace before publication. Use the `publish.py` and IModule workflow from the installed Labtainers distribution, not ad-hoc `docker tag` naming. Publish public images or ensure students have registry access; create and test the IModule TAR using the mechanism in the installed Labtainers version.
