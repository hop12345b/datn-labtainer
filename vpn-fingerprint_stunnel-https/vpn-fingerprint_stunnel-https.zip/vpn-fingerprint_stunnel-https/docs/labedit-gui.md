# Tạo/kiểm tra Lab 4 bằng labedit

1. Sao chép thư mục `vpn-fingerprint_stunnel-https` vào `$LABTAINER_DIR/labs/`.
2. Mở terminal Ubuntu host và chạy `labedit`.
3. Chọn **File -> Open Lab** (tên menu có thể khác giữa các bản) và chọn `vpn-fingerprint_stunnel-https`.
4. Đối chiếu 5 container: `client`, `gateway`, `stunnel-srv`, `https-srv`, `fake-https`.
5. Đối chiếu hai network `CLIENT_NET` (`10.0.1.0/24`) và `EXTERNAL_NET` (`10.0.2.0/24`).
6. `gateway` có 2 terminals; các container còn lại có 1 terminal. Hai terminal không có nghĩa là hai container.
7. Trong phần build/run, dùng thao tác force rebuild tương đương `rebuild vpn-fingerprint_stunnel-https -f` sau khi thay Dockerfile/service/image.
8. Trong Results/Goals, đối chiếu `instr_config/results.config` và `instr_config/goals.config`. Chỉ goal phát hiện TLS tunnel là goal Checkwork; validate PCAP là kiểm tra thủ công.
9. Chạy test thực tế trước khi phát hành; `labedit` chỉ là giao diện quản lý cấu hình, không chứng minh runtime đã chạy thành công.
