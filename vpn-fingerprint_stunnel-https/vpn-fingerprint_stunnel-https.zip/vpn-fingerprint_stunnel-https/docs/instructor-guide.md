# Lab 4 - Instructor / Technical Notes

## Architecture and ground truth

Expected TLS ClientHello endpoints in `mixed_tls.pcap`:

- `10.0.2.20:443`: real HTTPS. Client sends SNI `shop.example.com`; server certificate is signed by the lab CA. This flow should be legitimate.
- `10.0.2.10:443`: stunnel outer TLS. Stunnel connects to an IP and intentionally sends no SNI. TLS plaintext is forwarded to an OpenVPN TCP/1194 listener on loopback.
- `10.0.2.30:443`: self-signed decoy TLS endpoint. It serves no HTTP application protocol and holds the forwarded connection briefly.

The detector is parameter-driven. The untouched defaults do not require SNI and start with an empty JA3 allowlist; the learner is expected to modify parameters before the evaluation goal passes.

## Important corrections to the original problem statement

1. stunnel wraps TCP streams. OpenVPN must use TCP/1194 for this design; UDP/1194 cannot be forwarded as an ordinary stunnel TCP stream.
2. HTTP inside HTTPS is encrypted. A passive PCAP without TLS decryption keys does not expose `GET /` as a cleartext `http.request`. Use SNI/JA3/certificate/ALPN/flow metadata plus endpoint logs; do not treat absence of `http.request` in a TLS flow as direct proof that no HTTP was used.
3. Stock Zeek writes `ssl.log`, but JA3 fields require a package/script. The included `ja3.zeek` adapts the Salesforce JA3 Zeek script (BSD-3-Clause). `tshark` also provides `tls.handshake.ja3` on supported Wireshark releases.
4. The source specification refers to a Chrome JA3 but the topology provides no browser container. The lab uses curl/OpenSSL and differentiates observed ClientHello values through SNI/extension differences. It does not claim to reproduce a fixed Chrome JA3.

## Before release

- On the target VM, run `bash scripts/preflight.sh` after extracting the ZIP.
- Run `rebuild vpn-fingerprint_stunnel-https -f`.
- Verify all five container services. The client tunnel services must remain disabled at boot so the baseline is collected before starting OpenVPN-stunnel.
- Confirm `/dev/net/tun` and permissions in the Labtainers runtime. If not available, OpenVPN cannot create `tun0`; check the host/container runtime configuration rather than faking successful tunnel traffic.
- Capture `https_only.pcap`, stop the tunnel, start capture before restarting the tunnel, generate `mixed_tls.pcap`, and run `validate-pcaps.sh`.
- Run `zeek-run.sh`, check `ssl.log` and `tlsfp.log`, then tune detector and run `evaluate.py`.
- Run `stoplab`; verify Student.py is executable and `/usr/bin/python` points to Python 3, then run Checkwork.

## Expected evaluation markers

`evaluate.py` emits these in one command:
- `HTTPS_ONLY_EXPECTED_LEGITIMATE_PASS`
- `MIXED_EXPECTED_TUNNEL_DETECTED_PASS`
- `LAB4_RESULT_PASS`

`validate-pcaps.sh` is intentionally a manual evidence check, not a separate Checkwork goal, to avoid cross-command timestamp ambiguity in the target Labtainers release.
