#!/usr/bin/env python3
"""Optional Scapy inspection helper. tshark remains authoritative for TCP reassembly and JA3."""
import sys
from scapy.all import PcapReader, TCP, IP
from scapy.layers.tls.handshake import TLSClientHello

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 scapy_tls_inspect.py <pcap>"); return 2
    n = 0
    with PcapReader(sys.argv[1]) as reader:
        for packet in reader:
            if packet.haslayer(IP) and packet.haslayer(TCP):
                tcp = packet[TCP]
                if tcp.dport == 443 or tcp.sport == 443:
                    n += 1
                    if packet.haslayer(TLSClientHello):
                        print("SCAPY_CLIENT_HELLO frame={} {}:{} -> {}:{}".format(
                            n, packet[IP].src, tcp.sport, packet[IP].dst, tcp.dport))
    print("SCAPY_TLS_PORT_PACKETS={}".format(n))
    print("NOTE=Scapy reads packets individually; use tshark for reassembled handshake fields")
    return 0
if __name__ == "__main__":
    try: sys.exit(main())
    except ImportError as exc:
        print("SCAPY_IMPORT_ERROR=" + str(exc)); sys.exit(2)
