#!/usr/bin/env python3
"""Flow-level Lab 4 evaluator. The required markers are emitted in one command stdout."""
import os
import re
import subprocess
import sys

DETECTOR = "/home/ubuntu/detect_stunnel.py"
PCAP_DIR = "/home/ubuntu"
GROUND_TRUTH = {
    "https_only.pcap": {"10.0.2.20": "LEGITIMATE_TLS"},
    "mixed_tls.pcap": {
        "10.0.2.10": "SUSPICIOUS_TLS",
        "10.0.2.20": "LEGITIMATE_TLS",
        "10.0.2.30": "SUSPICIOUS_TLS",
    },
}
FLOW_RE = re.compile(r"^FLOW: \S+:\d+ -> ([0-9.]+):\d+ .* class=(SUSPICIOUS_TLS|LEGITIMATE_TLS) ", re.M)

def run_detector(path):
    proc = subprocess.run(["python3", DETECTOR, path], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
    if proc.returncode != 0:
        raise RuntimeError("detector returned {} for {}:\n{}".format(proc.returncode, path, proc.stdout))
    flows = {}
    for ip, label in FLOW_RE.findall(proc.stdout):
        # Expected endpoints are unique in the controlled lab. The latest row for an IP is retained.
        flows[ip] = label
    return flows, proc.stdout

def main():
    missing = [os.path.join(PCAP_DIR, name) for name in GROUND_TRUTH if not os.path.isfile(os.path.join(PCAP_DIR, name))]
    print("=" * 66)
    print("LAB 4 EVALUATION - TLS TUNNEL DETECTION")
    print("METRIC_SCOPE=endpoint-labelled_TLS_flows_in_the_two_lab_PC​​APs")
    print("=" * 66)
    if missing:
        for path in missing: print("MISSING_PCAP=" + path)
        print("LAB4_RESULT=FAIL")
        return 2
    tp = fp = tn = fn = 0
    all_ok = True
    for name, expected in GROUND_TRUTH.items():
        path = os.path.join(PCAP_DIR, name)
        try:
            detected, detector_output = run_detector(path)
        except Exception as exc:
            print("EVALUATION_ERROR=" + str(exc))
            print("LAB4_RESULT=FAIL")
            return 2
        print("\nPCAP=" + name)
        for ip, truth in expected.items():
            guess = detected.get(ip, "MISSING_FLOW")
            ok = (guess == truth)
            print("ENDPOINT={} EXPECTED={} DETECTED={} RESULT={}".format(ip, truth, guess, "PASS" if ok else "FAIL"))
            if not ok: all_ok = False
            if truth == "SUSPICIOUS_TLS" and guess == "SUSPICIOUS_TLS": tp += 1
            elif truth == "SUSPICIOUS_TLS" and guess != "SUSPICIOUS_TLS": fn += 1
            elif truth == "LEGITIMATE_TLS" and guess == "SUSPICIOUS_TLS": fp += 1
            elif truth == "LEGITIMATE_TLS" and guess == "LEGITIMATE_TLS": tn += 1
        # The capture must contain every expected endpoint, not merely a non-zero suspicious count.
        unexpected = sorted(set(detected) - set(expected))
        if unexpected:
            print("UNEXPECTED_TLS_ENDPOINTS=" + ",".join(unexpected))
            all_ok = False
        if name == "https_only.pcap" and detected.get("10.0.2.20") == "LEGITIMATE_TLS":
            print("HTTPS_ONLY_EXPECTED_LEGITIMATE_PASS")
        if name == "mixed_tls.pcap" and all(detected.get(ip) == label for ip, label in expected.items()):
            print("MIXED_EXPECTED_TUNNEL_DETECTED_PASS")
    precision = float(tp) / (tp + fp) if tp + fp else 0.0
    recall = float(tp) / (tp + fn) if tp + fn else 0.0
    f1 = 2.0 * precision * recall / (precision + recall) if precision + recall else 0.0
    accuracy = float(tp + tn) / (tp + tn + fp + fn) if tp + tn + fp + fn else 0.0
    print("\nCONFUSION_MATRIX TP={} FP={} TN={} FN={}".format(tp, fp, tn, fn))
    print("Precision={:.2%} Recall={:.2%} F1={:.2%} Accuracy={:.2%}".format(precision, recall, f1, accuracy))
    passed = all_ok and f1 >= 0.80
    print("LAB4_RESULT={}".format("PASS" if passed else "FAIL"))
    if passed:
        print("LAB4_RESULT_PASS")
    return 0 if passed else 1

if __name__ == "__main__":
    sys.exit(main())
