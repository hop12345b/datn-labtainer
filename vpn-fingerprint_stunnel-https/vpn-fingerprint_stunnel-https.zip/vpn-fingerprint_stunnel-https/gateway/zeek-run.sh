#!/usr/bin/env bash
set -euo pipefail
PCAP="${1:-}"
OUTDIR="${2:-}"
if [ -z "$PCAP" ] || [ ! -s "$PCAP" ]; then echo 'Usage: zeek-run.sh <pcap> [output_dir]' >&2; exit 2; fi
if [ -z "$OUTDIR" ]; then OUTDIR="/home/ubuntu/zeek_logs/$(basename "$PCAP" .pcap)"; fi
mkdir -p "$OUTDIR"
cd "$OUTDIR"
# The included JA3 script adds ja3 to ssl.log; stock Zeek alone does not promise this field.
zeek -C -r "$PCAP" /home/ubuntu/ja3.zeek
printf 'ZEEK_RUN=PASS\nZEEK_PCAP=%s\nZEEK_LOG_DIR=%s\n' "$PCAP" "$OUTDIR"
find "$OUTDIR" -maxdepth 1 -type f -name '*.log' -printf 'ZEEK_LOG=%f\n' | sort
