#!/usr/bin/env bash
set -euo pipefail
ACTION="${1:-}"
KIND="${2:-}"
HOME_DIR=/home/ubuntu
PIDFILE=/tmp/lab4-tcpdump.pid
LOGFILE=/tmp/lab4-tcpdump.log
case "$ACTION" in
 start)
   case "$KIND" in
     baseline|https-only) OUT="$HOME_DIR/https_only.pcap" ;;
     mixed) OUT="$HOME_DIR/mixed_tls.pcap" ;;
     *) echo "Usage: capture-traffic.sh start [baseline|mixed] | stop" >&2; exit 2 ;;
   esac
   if [ -f "$PIDFILE" ] && sudo kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
     echo "CAPTURE_ALREADY_RUNNING pid=$(cat "$PIDFILE")"; exit 1
   fi
   IFACE="$(ip -o -4 addr show | awk '$4 ~ /^10\.0\.2\.1\// {print $2; exit}')"
   if [ -z "$IFACE" ]; then IFACE=any; fi
   rm -f "$OUT" "$LOGFILE"
   sudo tcpdump -nni "$IFACE" -s 0 -U -w "$OUT" 'tcp port 443 or tcp port 80 or port 53 or icmp' >"$LOGFILE" 2>&1 &
   PID=$!
   echo "$PID" > "$PIDFILE"
   sleep 1
   if ! sudo kill -0 "$PID" 2>/dev/null; then cat "$LOGFILE"; exit 1; fi
   echo "CAPTURE_STARTED=PASS"
   echo "CAPTURE_IFACE=$IFACE"
   echo "CAPTURE_PCAP=$OUT"
   echo "CAPTURE_PID=$PID"
   ;;
 stop)
   if [ ! -f "$PIDFILE" ]; then echo 'CAPTURE_STOP=NO_PIDFILE'; exit 1; fi
   PID="$(cat "$PIDFILE")"
   sudo kill -INT "$PID" 2>/dev/null || true
   for _ in $(seq 1 10); do sudo kill -0 "$PID" 2>/dev/null || break; sleep 0.2; done
   rm -f "$PIDFILE"
   cat "$LOGFILE" || true
   echo 'CAPTURE_STOPPED=PASS'
   ;;
 *) echo "Usage: capture-traffic.sh start [baseline|mixed] | stop" >&2; exit 2 ;;
esac
