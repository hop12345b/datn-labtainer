#!/usr/bin/env python3
"""Compute a coarse Shannon entropy over TCP payload bytes grouped by destination IP.

This is a teaching heuristic, not a TLS decryption tool. TLS payload is encrypted; entropy alone
cannot identify VPN traffic reliably and can also be high for compression or other binary data.
"""
import math
import subprocess
import sys
from collections import Counter

def shannon(data):
    if not data: return 0.0
    counts = Counter(data); n = float(len(data))
    return -sum((count / n) * math.log(count / n, 2) for count in counts.values())

def payload_bytes(pcap, dst):
    cmd = ["tshark", "-n", "-r", pcap, "-Y", "ip.dst == {} && tcp.payload".format(dst), "-T", "fields", "-e", "tcp.payload"]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip())
    blob = bytearray()
    for line in proc.stdout.splitlines():
        try: blob.extend(bytes.fromhex(line.replace(":", "")))
        except ValueError: pass
    return bytes(blob)

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 entropy_analyzer.py <pcap> <dst_ip> [dst_ip ...]", file=sys.stderr); return 2
    for dst in sys.argv[2:]:
        data = payload_bytes(sys.argv[1], dst)
        print("DST={} BYTES={} ENTROPY={:.4f}".format(dst, len(data), shannon(data)))
    print("INTERPRETATION=heuristic_only; high entropy does not prove VPN")
    return 0
if __name__ == "__main__": sys.exit(main())
