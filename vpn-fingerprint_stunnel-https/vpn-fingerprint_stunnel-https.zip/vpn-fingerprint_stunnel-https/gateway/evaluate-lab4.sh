#!/usr/bin/env bash
set -euo pipefail
cd /home/ubuntu
exec python3 /home/ubuntu/evaluate.py
