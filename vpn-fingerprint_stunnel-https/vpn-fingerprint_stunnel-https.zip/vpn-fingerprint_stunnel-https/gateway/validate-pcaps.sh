#!/usr/bin/env bash
set -euo pipefail
HOME_DIR=/home/ubuntu
PCAP="$HOME_DIR/mixed_tls.pcap"
BASE="$HOME_DIR/https_only.pcap"
fail() { echo "PCAP_VALIDATION=FAIL reason=$*"; exit 1; }
[ -s "$BASE" ] || fail 'missing https_only.pcap'
[ -s "$PCAP" ] || fail 'missing mixed_tls.pcap'
command -v tshark >/dev/null 2>&1 || fail 'tshark missing'
if ! tshark -G fields 2>/dev/null | grep -q $'tls.handshake.ja3\t'; then
  fail 'tshark field tls.handshake.ja3 is unavailable; verify Wireshark >= 3.6'
fi
frames="$(tshark -n -r "$PCAP" -T fields -e frame.number 2>/dev/null | wc -l)"
[ "$frames" -ge 500 ] || fail "mixed PCAP has only $frames frames; need >=500"
for ip in 10.0.2.10 10.0.2.20 10.0.2.30; do
  count="$(tshark -n -r "$PCAP" -Y "tcp.port == 443 && tls.handshake.type == 1 && ip.dst == $ip" -T fields -e frame.number 2>/dev/null | wc -l)"
  [ "$count" -ge 1 ] || fail "missing TLS ClientHello to $ip"
done
http_count="$(tshark -n -r "$PCAP" -Y 'tcp.dstport == 80 && tcp.flags.syn == 1 && tcp.flags.ack == 0' -T fields -e frame.number 2>/dev/null | wc -l)"
dns_count="$(tshark -n -r "$PCAP" -Y 'udp.port == 53' -T fields -e frame.number 2>/dev/null | wc -l)"
[ "$http_count" -ge 1 ] || fail 'missing HTTP/80 noise'
[ "$dns_count" -ge 1 ] || fail 'missing DNS/53 noise'
# Report field visibility; the filter returns ClientHello observations, not a guarantee of unique TCP flows.
ja3_count="$(tshark -n -r "$PCAP" -Y 'tls.handshake.type == 1 && tls.handshake.ja3' -T fields -e tls.handshake.ja3 2>/dev/null | sed '/^$/d' | wc -l)"
[ "$ja3_count" -ge 3 ] || fail "only $ja3_count JA3-bearing ClientHello rows"
echo "PCAP_VALIDATION=PASS"
echo "MIXED_FRAME_COUNT=$frames"
echo "TLS_CLIENTHELLO_COUNT=$ja3_count"
echo "HTTP80_SYN_COUNT=$http_count"
echo "DNS53_PACKET_COUNT=$dns_count"
