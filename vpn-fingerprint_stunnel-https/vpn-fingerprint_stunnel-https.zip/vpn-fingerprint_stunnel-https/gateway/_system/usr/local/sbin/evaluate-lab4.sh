#!/usr/bin/env bash
set -euo pipefail
exec /home/ubuntu/evaluate-lab4.sh "$@"
