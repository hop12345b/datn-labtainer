#!/usr/bin/env python3
"""Install a verified Scapy source package compatible with older Python 3."""
import hashlib
import io
import os
import shutil
import sysconfig
import tarfile
import time
import urllib.request

VERSION = "2.5.0"
SDIST_URL = (
    "https://files.pythonhosted.org/packages/67/a1/"
    "2a60d5b6f0fed297dd0c0311c887d5e8a30ba1250506585b897e5a662f4c/"
    "scapy-2.5.0.tar.gz"
)
EXPECTED_SHA256 = "5b260c2b754fd8d409ba83ee7aee294ecdbb2c235f9f78fe90bc11cb6e5debc2"


def download():
    last_error = None
    for attempt in range(3):
        try:
            request = urllib.request.Request(
                SDIST_URL,
                headers={"User-Agent": "Labtainers-Lab3-Scapy-Installer/" + VERSION},
            )
            with urllib.request.urlopen(request, timeout=45) as response:
                data = response.read()
            digest = hashlib.sha256(data).hexdigest()
            if digest != EXPECTED_SHA256:
                raise RuntimeError("SHA256 mismatch for Scapy source archive: " + digest)
            return data
        except Exception as exc:
            last_error = exc
            if attempt < 2:
                time.sleep(2 ** (attempt + 1))
    raise RuntimeError(
        "Cannot download verified Scapy " + VERSION + " source archive: " + str(last_error)
    )


def install():
    paths = sysconfig.get_paths()
    target = paths.get("purelib") or paths.get("platlib")
    if not target:
        raise RuntimeError("Python sysconfig did not provide purelib/platlib")
    if not os.path.isdir(target):
        os.makedirs(target)

    package_target = os.path.join(target, "scapy")
    prefix = "scapy-" + VERSION + "/scapy/"
    archive_data = download()
    found_init = False
    extracted_count = 0

    tar = tarfile.open(fileobj=io.BytesIO(archive_data), mode="r:gz")
    try:
        for member in tar.getmembers():
            if not member.name.startswith(prefix):
                continue
            relative = member.name[len(prefix):].rstrip("/")
            if not relative:
                continue
            parts = relative.split("/")
            if relative.startswith("/") or any(part in ("", ".", "..") for part in parts):
                raise RuntimeError("Unsafe path in Scapy source archive: " + member.name)
            destination = os.path.join(package_target, *parts)

            if member.isdir():
                if not os.path.isdir(destination):
                    os.makedirs(destination)
                continue
            if not member.isfile():
                raise RuntimeError("Unsupported archive entry: " + member.name)

            parent = os.path.dirname(destination)
            if not os.path.isdir(parent):
                os.makedirs(parent)
            source = tar.extractfile(member)
            if source is None:
                raise RuntimeError("Cannot read archive entry: " + member.name)
            with source:
                with open(destination, "wb") as output:
                    shutil.copyfileobj(source, output)
            try:
                os.chmod(destination, member.mode & 0o777)
            except OSError:
                pass
            extracted_count += 1
            if relative == "__init__.py":
                found_init = True
    finally:
        tar.close()

    if not found_init or extracted_count == 0:
        raise RuntimeError("Scapy source archive did not contain scapy/__init__.py")
    print("SCAPY_INSTALLED=" + VERSION)
    print("SCAPY_TARGET=" + package_target)
    print("SCAPY_FILES=" + str(extracted_count))


if __name__ == "__main__":
    install()
    from scapy.all import IP, PcapReader
    from scapy.layers.ipsec import ESP
    print("SCAPY_IMPORT=PASS")
