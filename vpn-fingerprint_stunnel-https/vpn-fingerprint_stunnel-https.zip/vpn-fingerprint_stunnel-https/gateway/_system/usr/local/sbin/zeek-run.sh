#!/usr/bin/env bash
set -euo pipefail
exec /home/ubuntu/zeek-run.sh "$@"
