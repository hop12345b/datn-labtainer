#!/usr/bin/env bash
set -euo pipefail
sysctl -w net.ipv4.ip_forward=1
iptables -P FORWARD ACCEPT || true
# No NAT is needed: external lab containers route their replies via 10.0.2.1.
echo 'GATEWAY_FORWARDING=PASS'
