#!/usr/bin/env bash
set -euo pipefail
exec /home/ubuntu/capture-traffic.sh "$@"
