#!/usr/bin/env bash
set -euo pipefail
exec /home/ubuntu/validate-pcaps.sh "$@"
