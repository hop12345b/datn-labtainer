#!/usr/bin/env python3
"""Lab 4 TLS tunnel detector. Students edit only the CONFIG section first."""
import os
import re
import subprocess
import sys
from collections import Counter, defaultdict

# ===== STUDENT CONFIG =====
TLS_PORT = 443
EXPECTED_SNI = ["shop.example.com"]
# Start false to let students observe the effect of missing SNI before enabling this rule.
REQUIRE_SNI = False
# Fill from the known-good HTTPS baseline, if using JA3 allowlisting.
JA3_WHITELIST = []
# A non-whitelisted JA3 must appear at least this many times before the JA3 rule fires.
MIN_JA3_HITS = 1
# ===== END CONFIG =====


def tshark_rows(pcap_path, display_filter, fields):
    if not os.path.isfile(pcap_path):
        raise FileNotFoundError("PCAP not found: " + pcap_path)
    cmd = ["tshark", "-n", "-r", pcap_path, "-Y", display_filter,
           "-T", "fields", "-E", "separator=\\t", "-E", "occurrence=f"]
    for field in fields:
        cmd.extend(["-e", field])
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
    if proc.returncode != 0:
        raise RuntimeError("tshark failed: " + proc.stderr.strip())
    rows = []
    for line in proc.stdout.splitlines():
        values = line.split("\t")
        if len(values) < len(fields):
            values.extend([""] * (len(fields) - len(values)))
        rows.append(values)
    return rows


def collect_flows(pcap_path):
    flt = "tcp.port == {} && tls.handshake.type == 1".format(TLS_PORT)
    rows = tshark_rows(pcap_path, flt, [
        "ip.src", "ip.dst", "tcp.srcport", "tcp.dstport",
        "tls.handshake.extensions_server_name", "tls.handshake.ja3"
    ])
    flows = {}
    for row in rows:
        key = (row[0], row[1], row[2], row[3])
        flow = flows.setdefault(key, {
            "src": row[0], "dst": row[1], "sport": row[2], "dport": row[3],
            "sni": "", "ja3": "", "handshakes": 0
        })
        flow["handshakes"] += 1
        if row[4] and not flow["sni"]:
            flow["sni"] = row[4]
        if row[5] and not flow["ja3"]:
            flow["ja3"] = row[5]
    # Counts are packet/ClientHello observations grouped by JA3. They are deliberately exposed for students.
    counts = Counter(flow["ja3"] for flow in flows.values() if flow["ja3"])
    for flow in flows.values():
        flow["ja3_hits"] = counts.get(flow["ja3"], 0) if flow["ja3"] else 0
    return list(flows.values())


def classify(flow):
    reasons = []
    sni = flow["sni"]
    ja3 = flow["ja3"]
    if REQUIRE_SNI and not sni:
        reasons.append("no-sni")
    if sni and sni not in EXPECTED_SNI:
        reasons.append("unexpected-sni")
    if JA3_WHITELIST:
        if not ja3:
            reasons.append("no-ja3")
        elif ja3 not in JA3_WHITELIST and flow["ja3_hits"] >= max(1, int(MIN_JA3_HITS)):
            reasons.append("non-whitelisted-ja3")
    suspicious = len(reasons) > 0
    return {
        "src": flow["src"], "dst": flow["dst"], "sport": flow["sport"], "dport": flow["dport"],
        "sni": sni or "-", "ja3": ja3 or "-", "ja3_hits": flow["ja3_hits"],
        "handshakes": flow["handshakes"],
        "classification": "SUSPICIOUS_TLS" if suspicious else "LEGITIMATE_TLS",
        "reasons": ",".join(reasons) if reasons else "-"
    }


def analyze(pcap_path):
    flows = collect_flows(pcap_path)
    return [classify(flow) for flow in flows]


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 detect_stunnel.py <pcap_file>", file=sys.stderr)
        return 2
    pcap_path = sys.argv[1]
    try:
        results = analyze(pcap_path)
    except Exception as exc:
        print("DETECTOR_ERROR=" + str(exc))
        return 2
    print("PCAP=" + os.path.basename(pcap_path))
    print("TLS_PORT={}".format(TLS_PORT))
    print("TLS_FLOWS={}".format(len(results)))
    print("RULE=expected_sni {}, require_sni {}, ja3_whitelist_count {}, min_ja3_hits {}".format(
        EXPECTED_SNI, REQUIRE_SNI, len(JA3_WHITELIST), MIN_JA3_HITS))
    for flow in results:
        print("FLOW: {src}:{sport} -> {dst}:{dport} sni={sni} ja3={ja3} ja3_hits={ja3_hits} hs={handshakes} class={classification} reasons={reasons}".format(**flow))
    suspicious = sum(1 for f in results if f["classification"] == "SUSPICIOUS_TLS")
    legitimate = len(results) - suspicious
    print("LEGITIMATE_FLOWS={}".format(legitimate))
    print("SUSPICIOUS_FLOWS={}".format(suspicious))
    print("DETECTION={}".format("TUNNEL_SUSPECTED" if suspicious else "NO_TUNNEL"))
    return 0

if __name__ == "__main__":
    sys.exit(main())
