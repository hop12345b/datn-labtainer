#!/usr/bin/env bash
set -euo pipefail
mkdir -p /var/log/stunnel
STUNNEL_BIN="$(command -v stunnel4 || command -v stunnel)"
exec "$STUNNEL_BIN" /etc/stunnel/stunnel-srv.conf
