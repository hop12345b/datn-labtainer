#!/usr/bin/env bash
set -euo pipefail
mkdir -p /var/log/openvpn
if [ ! -c /dev/net/tun ]; then
  echo 'TUN_DEVICE_MISSING: /dev/net/tun is unavailable; verify Labtainers runtime privileges and host TUN support.' >&2
  exit 1
fi
exec /usr/sbin/openvpn --config /etc/openvpn/server/server.conf
