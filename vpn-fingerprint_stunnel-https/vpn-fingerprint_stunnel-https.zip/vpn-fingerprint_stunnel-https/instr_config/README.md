# Lab 4 Checkwork

The goal depends only on three markers emitted by one `python3 evaluate.py` invocation. PCAP validation is a student/instructor evidence check, not a separate Checkwork goal, because the Labtainers release being targeted may collect different command output timestamps for separate commands.

The evaluator exits nonzero if a PCAP is missing, the real HTTPS flow is not legitimate, or either the stunnel or fake TLS flow is not flagged suspicious. Do not insert PASS markers manually.
