# Xử lý sự cố thường gặp

1. **Service không tự active khi lab vừa khởi động.** Source final tạo liên kết autostart cho cả `default.target` và `multi-user.target`, đồng thời startup script chờ IP trước khi bind. Sau khi mở lab, chờ 5–10 giây và kiểm tra trên đúng container: `systemctl is-enabled <unit>`, `systemctl --no-pager --full status <unit>`, `ip -br addr`, `journalctl -b -u <unit> --no-pager -n 100`. Nếu unit `disabled` hoặc preflight báo `missing autostart link`/smoke test báo `invalid autostart link`, không tạo thủ công từng liên kết: chạy `bash scripts/preflight.sh`. Bước này tự khôi phục symlink bị mất khi giải nén và tạo lại archive. Sau đó rebuild bằng workflow `rebuild vpn-fingerprint_advanced-evasion`. Nếu log ghi `timeout waiting for lab IP`, đối chiếu topology/IP với `config/start.config`. Chỉ dùng `systemctl start <unit>` làm phép thử phục hồi sau khi lưu log; không dùng nó thay cho việc sửa autostart.
2. **Traffic DNS mô phỏng không có phản hồi.** Trên `victim`, kiểm tra bằng `dig @10.0.1.10 probe.exfil.example.local A +time=2 +tries=1`. Trên `corp-dns`, xem `sudo journalctl -u lab-dns.service --no-pager -n 80` và `/var/log/corp-dns-lab.log`; trên `exfil-dns`, xem cùng unit và `/var/log/dnsmasq-lab.log`. Kiểm tra route tới `10.0.3.20` và listener UDP/53. Gói phía ngoài có thể hiện resolver `10.0.1.10` là nguồn query.
3. **Không thấy trường JA3 trong tshark hoặc Zeek.** JA3 không được bảo đảm có trong cấu hình mặc định. Xác nhận plugin/gói phân tích JA3 đã được cài và tương thích phiên bản; không tự đoán hoặc hard-code hash.
4. **SOCKS simulator không khởi động.** Trên `relay-proxy`, kiểm tra `sudo systemctl status lab-relay.service --no-pager`, `sudo journalctl -u lab-relay.service --no-pager -n 100` và `sudo ss -lntp | grep ':1080'`. Đây là trình mô phỏng chỉ xử lý handshake, không phải microsocks và không chuyển tiếp traffic.
5. **Suricata báo lỗi rule hoặc cấu hình.** Dùng cấu hình mặc định của gói cài đặt và file rule hợp nhất `/home/ubuntu/suricata/all.rules`. File `config/suricata/suricata.yaml` trong source là overlay/ghi chú, không phải cấu hình YAML hoàn chỉnh thay thế cấu hình package. Kiểm tra bằng `suricata -V` và `sudo suricata -T -c /etc/suricata/suricata.yaml -S /home/ubuntu/suricata/all.rules`.
6. **TLS mô phỏng dừng sớm hoặc không kết nối được.** Trên `c2-server`, kiểm tra service `lab-c2.service`, file `/home/ubuntu/c2/server.crt`, `/home/ubuntu/c2/server.key` và listener TCP/443. TLS responder chỉ trả nội dung cố định cho đường dẫn `/beacon`, không cung cấp kênh điều khiển.
7. **PCAP rỗng hoặc thiếu gói.** Chạy `record-pcap.sh` trên `gateway` trước ba script ở `victim`, rồi chạy traffic ngay sau `CAPTURE_START`. Kiểm tra interface mang IP `10.0.3.1`, quyền bắt gói và thời lượng 45 giây. Không bắt đầu pha B nếu file PCAP rỗng.
8. **Zeek không tạo log hoặc log nằm sai thư mục.** Chạy `run-zeek.sh` trên `gateway`, sau đó kiểm tra `/home/ubuntu/zeek_logs/dns.log`. Wrapper chuyển working directory sang thư mục này trước khi chạy Zeek. Có thể chạy lại trực tiếp: `cd /home/ubuntu/zeek_logs && zeek -C -r /home/ubuntu/red_phase.pcap /home/ubuntu/zeek/local.zeek`.
9. **`checkwork` lỗi trong grader.** Nếu có `UnicodeDecodeError: 'ascii' codec can't decode`, kiểm tra `config/parameter.config`; file tùy chọn này nên để trống nếu không khai báo runtime parameter. Nếu lỗi khác, lấy traceback trong `logs/grader.log` và `/tmp/instructor.log` của grader. Không chỉnh threshold detector khi lỗi xảy ra trước bước chấm mục tiêu.

## Zeek tạo `dns.<timestamp>.log` nhưng không tạo `dns.log`

**Nguyên nhân:** `config/zeek/local.zeek` hoặc `gateway/home_tar/zeek/local.zeek` có dòng `redef Log::default_rotation_interval = 1hr;`. Khi xử lý PCAP offline, Zeek có thể xoay log thành tên có timestamp; script kiểm tra và analyzer của lab lại cần `dns.log`.

**Sửa trong container gateway để thử ngay:**

```bash
sudo cp -a /home/ubuntu/zeek/local.zeek /home/ubuntu/zeek/local.zeek.bak
sudo sed -i '/Log::default_rotation_interval/d' /home/ubuntu/zeek/local.zeek
sudo mv /home/ubuntu/zeek_logs "/home/ubuntu/zeek_logs.bak-$(date +%Y%m%d-%H%M%S)"
sudo install -d -o ubuntu -g ubuntu /home/ubuntu/zeek_logs
sudo run-zeek.sh
ls -lh /home/ubuntu/zeek_logs/dns.log
```

**Sửa lâu dài trên máy host:** xóa cùng dòng trong cả `config/zeek/local.zeek` và `gateway/home_tar/zeek/local.zeek`, sau đó chạy `python3 scripts/build-archives.py` và `rebuild vpn-fingerprint_advanced-evasion` theo workflow Labtainers đã cài. Chỉ xác nhận sửa thành công khi xuất hiện `/home/ubuntu/zeek_logs/dns.log` và script in `LABZEEK_RESULT=PASS`.


10. **Các lệnh và analyzer đều PASS nhưng Checkwork không lên điểm.** Trên gateway chạy `sudo checkwork-evidence.sh`; xác minh `CHECKWORK_EVIDENCE=PASS`. Sau `stoplab`, kiểm tra `.lab` mới bằng `scripts/verify-checkwork-artifact.py`. Nếu artifact không có `checkwork-evidence.txt`, kiểm tra `results.config` và việc thu file. Nếu artifact có file nhưng goal không đạt, vào grader debug, tìm file dưới `.local/result`, so khớp bản `results.config`/`goals.config` đã copy và đọc `/tmp/instructor.log`. Giữ identity nhất quán, sao lưu/tách `.lab` cũ của identity khác. Xem `docs/checkwork-diagnostics.md`.
