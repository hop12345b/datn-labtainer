# Build, run and verify

This file is a compact build checklist. The complete student procedure, including thresholds and Checkwork diagnosis, is in `docs/practical-walkthrough.md`.

## 1. Prepare source and archives

Run on the Labtainers VM host:

```bash
cd "$LABTAINER_DIR/labs/vpn-fingerprint_advanced-evasion"
python3 scripts/build-archives.py
bash scripts/preflight.sh
python3 scripts/smoke-test.py
```

Expected: `ARCHIVES_RESULT=PASS`, `PREFLIGHT=PASS`, `SMOKE_TEST=PASS`. `config/parameter.config` must remain empty (0 bytes) because some installed Labtainers releases parse it as ASCII. The archive builder restores systemd autostart links before writing all seven container `sys.tar` and `home.tar` files.

## 2. Rebuild images

```bash
cd "$HOME/labtainer/labtainer-student"
rebuild vpn-fingerprint_advanced-evasion
```

Use the student work directory for the installed Labtainers deployment. Rebuilding is mandatory after edits to `_system`, `home_tar`, or Dockerfiles.

## 3. Run the lab and verify automatic services

```bash
labtainer vpn-fingerprint_advanced-evasion
```

Wait 5–10 seconds. Verify gateway (`active (exited)` is expected for its oneshot unit), both DNS services (UDP/53), passive TLS responder (TCP/443), SOCKS5 simulator (TCP/1080), target server (TCP/8080), and victim initialization unit. Use `systemctl status`, `systemctl is-enabled`, `ss -lntup`, and `journalctl -b -u <unit>` in each relevant container. Manual `systemctl start` is a recovery/debug step, not the normal workflow.

## 4. Run exercise

Follow `docs/practical-walkthrough.md` in order: validate network, start PCAP capture on gateway, run the three safe marker simulations on victim, run Zeek/Suricata, configure the three analyzer thresholds, generate the report, and finally run `sudo checkwork-evidence.sh` on gateway.

Do not stop the lab unless `/home/ubuntu/checkwork-evidence.txt` contains all required markers and `CHECKWORK_EVIDENCE=PASS`.

## 5. Stop, inspect artifact, then Checkwork

On the host:

```bash
cd "$HOME/labtainer/labtainer-student"
stoplab
find "$HOME/labtainer_xfer/vpn-fingerprint_advanced-evasion" -maxdepth 1 -type f -name '*.lab' -printf '%TY-%Tm-%Td %TH:%TM %s %f\n'
```

Run the artifact verifier against the newly-created `.lab` file:

```bash
python3 "$LABTAINER_DIR/labs/vpn-fingerprint_advanced-evasion/scripts/verify-checkwork-artifact.py" \
  "$HOME/labtainer_xfer/vpn-fingerprint_advanced-evasion/<fresh-file>.lab"
```

Expected: `ARTIFACT_EVIDENCE_FOUND=PASS` and `ARTIFACT_MARKERS=PASS`. Only then run:

```bash
checkwork vpn-fingerprint_advanced-evasion
```

A terminal marker is not a grade. The check is complete only when the goal `advanced_evasion_forensics` is shown as passed by Checkwork. If the goal is absent/Unknown/False, follow `docs/checkwork-diagnostics.md`; do not tune detection thresholds to fix grader/artifact problems.
