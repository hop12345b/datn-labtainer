# Implementation review — vpn-fingerprint_advanced-evasion

## 1. Cây thư mục

- `config/`: `start.config`, `parameter.config`, `param.dat`, `about.txt`, DNS configs, SOCKS simulator config, Suricata rules/overlay, Zeek policy, C2 responder, `secrets/gen_secret.sh` và `secrets/secret.txt`.
- `dockerfiles/`: đủ 7 Dockerfile cho `victim`, `corp-dns`, `gateway`, `c2-server`, `exfil-dns`, `relay-proxy`, `target-data`.
- Mỗi thư mục container có `home_tar/home.tar`, `sys_tar/sys.tar`, thư mục nguồn `_system/`, cùng `INSTRUCTIONS.txt` nếu phù hợp. `victim/home_tar` chứa 3 script sinh dấu vết và dummy `secret.txt`; `gateway/home_tar` chứa 4 script Blue Team, rule files, Zeek policy và bảng MAC-IP.
- `scripts/redteam/`: `dns_exfil.py`, `c2_beacon.py`, `exfil_via_socks.py`.
- `scripts/blueteam/`: `analyze_dns_exfil.py`, `analyze_c2_iat.py`, `analyze_socks.py`, `generate_report.py`.
- `scripts/startup/`: `gateway-startup.sh`, `c2-startup.sh`, `dns-startup.sh`, `relay-startup.sh`, `target-startup.sh`.
- `scripts/`: `build-archives.py`, `preflight.sh`, `smoke-test.py`, capture/analysis wrappers.
- `docs/`: student guide, labedit GUI guide, build/verify guide, troubleshooting, packaging guide, file index.
- `instr_config/`: `results.config`, `goals.config`, instructor guide và rubric.

Danh sách từng đường dẫn cụ thể nằm trong `docs/file-index.md`.

## 2. Labtainers/labedit

Nguồn cấu hình chuẩn là `config/start.config`, theo định dạng của bài mẫu được cung cấp. Topology gồm 7 container và 2 subnet đã được định nghĩa đầy đủ: `client-net` (`10.0.1.0/24`) và `ext-net` (`10.0.3.0/24`). Bản yêu cầu nói “3 subnet” nhưng chỉ mô tả 2 subnet; bản dựng này dùng 2 subnet, không tự phát minh subnet thứ ba.

Gateway có hai địa chỉ: `10.0.1.1` và `10.0.3.1`. Dockerfile sử dụng `labtainer.network3`, `sys_tar/sys.tar` và `home_tar/home.tar` theo bài mẫu. Cần kiểm tra NET_ADMIN/NET_RAW và capture trên đúng VM; tên trường capability trong GUI phụ thuộc phiên bản.

## 3. Phạm vi các file

ZIP chứa source đầy đủ, không chỉ skeleton. `scripts/build-archives.py` sinh archive đúng quy ước; `scripts/preflight.sh` kiểm tra cấu trúc và cú pháp; `scripts/smoke-test.py` kiểm tra cú pháp Python cùng guardrails mô phỏng. Suricata dùng cấu hình package có sẵn khi chạy PCAP, cùng bộ rule riêng. File `config/suricata/suricata.yaml` là ghi chú/overlay có chủ đích, không được giả làm bản thay thế đầy đủ của YAML do package cài đặt cung cấp.

Các hành vi Red Team giữ ở dạng an toàn/mô phỏng: DNS chỉ gửi nhãn nonce sinh độc lập, không mã hóa hay truyền nội dung `secret.txt`; TLS server chỉ trả canned response và không có khả năng thực thi lệnh; SOCKS5 mô phỏng handshake rồi từ chối CONNECT, không mở kết nối upstream. `microsocks` thật và đường chuyển dữ liệu qua relay không được khởi tạo. JA3 không được gán hash cố định vì phụ thuộc OpenSSL/analyzer phiên bản.

## 4. Quy trình build và xác minh

Trên VM Labtainers:

```bash
cd "$LABTAINER_DIR/labs/vpn-fingerprint_advanced-evasion"
python3 scripts/build-archives.py
bash scripts/preflight.sh
python3 scripts/smoke-test.py
cd "$HOME/labtainer/labtainer-student"
rebuild vpn-fingerprint_advanced-evasion
```

Bản final tạo autostart link cho cả `default.target` và `multi-user.target` trong từng image, đồng thời mỗi wrapper chờ IP tĩnh xuất hiện trước khi bind listener. Sau khi mở lab, kiểm tra tự động service status trên từng container và listener trước khi làm traffic; không cần chạy `systemctl start` thủ công trong luồng bình thường. Chạy `sudo record-pcap.sh` trên gateway trước traffic; từ `victim` chạy lần lượt `redteam/dns_exfil.py`, `redteam/c2_beacon.py`, `redteam/exfil_via_socks.py`. Khi PCAP đã được thu, trên `gateway` chạy `sudo run-zeek.sh`, `sudo run-suricata.sh`, chỉnh các TODO trong ba analyzer rồi chạy các wrapper analyzer/báo cáo bằng `sudo`. Kết thúc bằng `stoplab` và `checkwork`.

Kết quả đã xác minh tại môi trường tạo gói: tạo đủ 7 cặp archive, `preflight.sh` trả `PREFLIGHT=PASS`, smoke test trả `SMOKE_TEST=PASS`, cú pháp Bash của startup scripts hợp lệ, cú pháp shell của các lệnh `RUN` trong 7 Dockerfile hợp lệ, kiểm tra liên kết autostart trong source và từng `sys.tar` đạt, và `systemd-analyze verify` không báo lỗi unit khi kiểm tra trong root thử nghiệm tối thiểu. **Chưa chạy Docker build, traffic thực, Zeek/Suricata runtime hoặc Checkwork trên VM Labtainers đích.** Vì vậy không khẳng định lab đã được kiểm thử end-to-end hay chắc chắn đạt toàn bộ result markers.

## 5. Tám lỗi thường gặp

1. Traffic hợp lệ bị chặn: xem thứ tự `iptables -S FORWARD`, kiểm tra các rule drop chỉ áp dụng cổng/protocol mục tiêu.
2. DNS không có phản hồi: kiểm tra `lab-dns.service`, file cấu hình dnsmasq, default route từ `corp-dns` đến gateway và đường tới `10.0.3.20`.
3. Không có JA3: xác nhận cài analyzer/package JA3 tương ứng; không lấy hash từ phiên bản khác.
4. SOCKS simulation không chạy: kiểm tra `lab-relay.service` và listener TCP/1080; endpoint cố ý không relay dữ liệu.
5. Suricata lỗi rule: xem log, dùng `/etc/suricata/suricata.yaml` package-installed và `-S /home/ubuntu/suricata/all.rules`; overlay đi kèm không phải file cấu hình đầy đủ.
6. TLS dừng sớm: kiểm tra `lab-c2.service`, chứng chỉ/key tự ký, listener 443 và phản hồi canned.
7. PCAP thiếu gói: bắt trên interface phía ngoài trước khi chạy ba script; xác minh NET_RAW và thời lượng capture.
8. Zeek log sai thư mục: chạy `run-zeek.sh`, kiểm tra `/home/ubuntu/zeek_logs` và output `ZEEK_RESULT`.

## Đóng gói/publish

Xem `docs/packaging.md`. Cần chạy `rebuild`, traffic, analyzer và `checkwork` thành công trên VM trước khi tạo/publish imodule và push image lên namespace `hop12345b`. Cờ của `create-imodules.sh`/`publish.py` phải xác nhận bằng `--help` trên bản Labtainers cài đặt.
