# Đóng gói và publish

## Tạo source archive

Trên VM Labtainers, ở thư mục chứa lab:

```bash
python3 scripts/build-archives.py
bash scripts/preflight.sh
python3 scripts/smoke-test.py
cd ..
tar -czf vpn-fingerprint_advanced-evasion-source.tar.gz vpn-fingerprint_advanced-evasion
```

## Tạo imodule và publish image

Các lệnh và flags có thể khác theo phiên bản Designer. Kiểm tra ngay trên VM bằng `create-imodules.sh --help`, `publish.py --help`, và dùng bài mẫu IPsec đang chạy được làm đối chiếu. Không giả định namespace/tag Docker hay kiểu archive là đúng nếu chưa xác nhận log. Quy trình mô tả trong yêu cầu là: tạo imodule từ lab đã preflight, `docker login`, chạy công cụ `publish.py` với registry `hop12345b`, rồi kiểm tra danh sách image đã được push.

**[CẦN KIỂM TRA]** Xác nhận tên image cuối theo quy ước đang dùng tại bản Labtainers cài đặt. Đừng push cho đến khi `rebuild`, khởi động đủ 7 container, chạy pha A/B và `checkwork` đều đạt trên VM mục tiêu.

## GitHub

Có thể tạo một repository cho dự án lab, giữ source ở root hoặc một thư mục rõ ràng, và đính kèm `imodule.tar`/`.rar` như GitHub Release asset nếu dung lượng phù hợp. Người cài cần lấy đúng archive cho bài này, sau đó dùng lệnh `imodule + URL` theo hướng dẫn của phiên bản Labtainers của họ. ZIP hiện tại là source bundle để rà soát, chưa phải xác nhận rằng imodule import thành công.
