# Chẩn đoán Checkwork — `vpn-fingerprint_advanced-evasion`

## 1. Ba trạng thái phải phân biệt

| Trạng thái | Ý nghĩa | Đã chứng minh Checkwork đạt? |
|---|---|---|
| `PREFLIGHT=PASS` và `SMOKE_TEST=PASS` | Source, cú pháp, archive, autostart links và cấu hình tĩnh qua kiểm tra | Chưa |
| `CHECKWORK_EVIDENCE=PASS` trên gateway | Các file runtime đủ điều kiện; script đã tạo `/home/ubuntu/checkwork-evidence.txt` | Chưa |
| `.lab` chứa `checkwork-evidence.txt` | Labtainers đã thu file evidence vào artifact của phiên vừa kết thúc | Chưa |
| Checkwork hiển thị goal `advanced_evasion_forensics` đạt | Grader đã đọc artifact và đánh giá goal | Có |

Một dòng PASS trong terminal không tự động được dùng làm điểm. Bản lab này dùng một system file có tên cố định và khai báo trực tiếp file đó trong `instr_config/results.config`.

## 2. Trình tự bắt buộc cuối buổi

Trên `gateway`, sau khi firewall, PCAP, Zeek, Suricata, ba analyzer và báo cáo đã hoàn tất:

```bash
sudo checkwork-evidence.sh
sudo cat /home/ubuntu/checkwork-evidence.txt
```

Chỉ tiếp tục nếu file chứa đủ các marker sau và dòng cuối `CHECKWORK_EVIDENCE=PASS`:

```text
VPN_BLOCK_CONFIRMED
LABPCAP_RESULT=PASS
ZEEK_RESULT=PASS
SURICATA_RESULT=PASS
DNS_EXFIL=DETECTED
C2_BEACON=DETECTED
SOCKS5_RELAY=DETECTED
Incident Report
CHECKWORK_EVIDENCE=PASS
```

Nếu script báo `CHECKWORK_EVIDENCE=FAIL`, đọc các dòng `CHECK_FAIL=...` và xử lý nguyên nhân cụ thể. Không stoplab khi evidence còn FAIL.

## 3. Stoplab trước, kiểm tra artifact sau

Trên host, tại thư mục student:

```bash
cd "$HOME/labtainer/labtainer-student"
stoplab
```

Đợi lệnh kết thúc. Liệt kê file artifact vừa tạo:

```bash
find "$HOME/labtainer_xfer/vpn-fingerprint_advanced-evasion" \
  -maxdepth 1 -type f -name '*.lab' \
  -printf '%TY-%Tm-%Td %TH:%TM:%TS  %s bytes  %f\n' | sort
```

Dùng helper để xác nhận `.lab` vừa tạo thực sự chứa file evidence và các marker. Thay tên mẫu bằng đúng file vừa liệt kê:

```bash
python3 "$LABTAINER_DIR/labs/vpn-fingerprint_advanced-evasion/scripts/verify-checkwork-artifact.py" \
  "$HOME/labtainer_xfer/vpn-fingerprint_advanced-evasion/<fresh-file>.lab"
```

Kết quả mong đợi:

```text
ARTIFACT_MEMBER=<đường_dẫn_trong_archive>/checkwork-evidence.txt
ARTIFACT_MARKERS=PASS
ARTIFACT_EVIDENCE_FOUND=PASS
```

Nếu helper báo `ARTIFACT_EVIDENCE_FOUND=FAIL`, chưa chạy Checkwork. File trên gateway chưa được đưa vào `.lab` hoặc phiên Labtainers chưa thu đúng kết quả. Kiểm tra lại `results.config`, file thực trên gateway và thời điểm stoplab.

Sau khi artifact qua kiểm tra:

```bash
checkwork vpn-fingerprint_advanced-evasion
```

## 4. Nếu Checkwork không hiển thị goal hoặc báo Unknown/False

### 4.1. Xác minh source cấu hình trên host

```bash
cd "$LABTAINER_DIR/labs/vpn-fingerprint_advanced-evasion"
cat instr_config/results.config
cat instr_config/goals.config
wc -c config/parameter.config
```

Các result cần trỏ tới đúng file:

```text
gateway:/home/ubuntu/checkwork-evidence.txt
```

`goals.config` phải tham chiếu đúng các tag đã khai báo trong `results.config`. `config/parameter.config` phải rỗng (0 byte), để tránh `UnicodeDecodeError` trên bản Labtainers đang dùng.

### 4.2. Kiểm tra identity và artifact cũ

```bash
find "$HOME/labtainer_xfer/vpn-fingerprint_advanced-evasion" \
  -maxdepth 1 -type f -name '*.lab' -printf '%TY-%Tm-%Td %TH:%TM %s %f\n'
```

Nếu có artifact của nhiều identity khác nhau do từng nhập email/student ID khác nhau, không xóa trực tiếp. Sao lưu trước:

```bash
mkdir -p "$HOME/advanced-evasion-lab-backup"
cp -av "$HOME/labtainer_xfer/vpn-fingerprint_advanced-evasion"/*.lab \
  "$HOME/advanced-evasion-lab-backup/" 2>/dev/null || true
```

Sau khi xác định đúng identity muốn chấm, chuyển artifact cũ thuộc identity khác ra khỏi thư mục transfer (giữ bản sao lưu). Ở lần chạy tiếp theo, giữ nguyên identity đó; nếu giá trị mặc định trong dấu ngoặc vuông là đúng thì nhấn Enter.

### 4.3. Debug grader

Trên host, vào thư mục instructor của Labtainers. Với cách bố trí trong ví dụ:

```bash
cd "$HOME/labtainer/labtainer-instructor"
./bin/gradelab -d vpn-fingerprint_advanced-evasion
```

Nếu thư mục khác, dùng thư mục thực tế dưới `$LABTAINER_DIR/scripts/labtainer-instructor`.

Trong terminal grader, thông thường bạn đã đăng nhập bằng `instructor`; không chạy `su - instructor` lần nữa:

```bash
whoami
cd /home/instructor
.local/bin/instructor.py
```

Kiểm tra cấu hình được copy vào grader:

```bash
cat /home/instructor/.local/instr_config/results.config
cat /home/instructor/.local/instr_config/goals.config
wc -c /home/instructor/.local/config/parameter.config
```

Tìm evidence trong kết quả đã giải nén:

```bash
find /home/instructor -type f -path '*/.local/result/*' \
  -name 'checkwork-evidence.txt' -print
```

Nếu tìm thấy, đọc file đó và đối chiếu marker. Nếu không tìm thấy trong `.local/result`, quay lại bước kiểm tra `.lab`; đừng chỉnh threshold của analyzer để chữa lỗi thu artifact.

Đọc log debug:

```bash
strings -a /tmp/instructor.log | tail -n 160
```

Trên host:

```bash
strings -a "$LABTAINER_DIR/logs/grader.log" | tail -n 160
tail -n 160 "$LABTAINER_DIR/logs/instructor.log"
```

## 5. Diễn giải nhanh các biểu hiện

- **Bảng “What is automatically assessed for this lab” trống:** kiểm tra `results.config`, `goals.config`, bản cấu hình trong grader và traceback khi parse config.
- **Goal có nhưng `Unknown`/False:** xác nhận `.local/result/checkwork-evidence.txt` tồn tại và nội dung khớp chính xác marker; phân biệt file evidence có trong gateway với file đã được grader thu thập.
- **`autoGrade()` lỗi:** cần traceback trong `/tmp/instructor.log` hoặc `logs/grader.log`; dòng `Error occurred within the grader container` chỉ là thông báo tổng quát.
- **`UnicodeDecodeError: ascii`:** giữ `config/parameter.config` rỗng; đồng bộ lại bản cấu hình trong grader bằng lượt checkwork mới.
- **Có hai identity trong grader:** kiểm tra các file `.lab` cũ trong transfer; sao lưu và tách artifact khác identity trước khi chấm lại.

## 6. Vì sao dùng file kết quả được đặt tên?

Labtainers Designer Guide mô tả rằng các file được tham chiếu trong `results.config` sẽ được thu vào artifact archive; tài liệu cũng phân biệt artifact hệ thống với `stdin/stdout` của lệnh. Vì vậy, bản lab này chấm một file có tên cố định thay vì phụ thuộc vào wildcard `*.stdout`. Xem [Lab Designer User Guide, phần system logs và automated assessment](https://nps.edu/documents/107523844/117289221/labdesigner.pdf).
