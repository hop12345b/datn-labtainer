# Hướng dẫn thực hành chi tiết — `vpn-fingerprint_advanced-evasion`

> **Phạm vi mô phỏng:** thực hiện hoàn toàn trong mạng Labtainers cô lập. DNS chỉ tạo nhãn ngẫu nhiên giả; không đọc, mã hóa hoặc truyền nội dung `secret.txt`. TLS server chỉ trả phản hồi cố định, không nhận lệnh điều khiển. SOCKS5 simulator chỉ ghi nhận handshake và từ chối yêu cầu `CONNECT`; không chuyển tiếp dữ liệu.
>
> **Quy tắc quan trọng:** một dòng `PASS` trên terminal chưa đồng nghĩa Checkwork đã đạt. Bài này có ba mốc riêng: (1) script hoàn tất, (2) `checkwork-evidence.txt` kiểm tra đủ bằng chứng, (3) Labtainers thu file đó vào artifact `.lab` và grader chấm được goal. Chỉ mốc thứ ba mới xác nhận Checkwork thành công.

## 0. Quy ước terminal và thứ tự

- **[HOST]**: terminal Ubuntu chạy Labtainers, bên ngoài các container.
- **[victim]**, **[gateway]**, **[corp-dns]**, **[exfil-dns]**, **[c2-server]**, **[relay-proxy]**, **[target-data]**: terminal của container cùng tên.
- Các wrapper `.sh` ở `gateway` cần quyền quản trị. Trong hướng dẫn này luôn chạy chúng bằng `sudo`, ví dụ `sudo run-zeek.sh`.
- Các script mô phỏng Python chạy trên `victim` bằng tài khoản `ubuntu`, không cần `sudo`.
- `lab-gateway.service` là unit `Type=oneshot`; trạng thái `active (exited)` là bình thường sau khi firewall/route đã được thiết lập. Những service còn lại phải ở trạng thái `active (running)`.
- Không dùng `labtainer -r` giữa quy trình nếu muốn giữ kết quả đang làm. `-r` tạo phiên làm lại và có thể tạo một bộ kết quả khác.
- Khi Labtainers hỏi e-mail/student identity, giữ nguyên cùng một identity trong mọi lần chạy. Nếu giá trị mặc định trong ngoặc vuông là identity bạn đang dùng, nhấn Enter; không nhập một identity khác giữa chừng.

## 1. Chuẩn bị source, archive và image

### 1.1. Xác nhận đúng thư mục lab

**[HOST]**

```bash
printf 'LABTAINER_DIR=%s\n' "$LABTAINER_DIR"
cd "$LABTAINER_DIR/labs/vpn-fingerprint_advanced-evasion"
pwd
ls config/start.config instr_config/results.config instr_config/goals.config
```

Đường dẫn cuối phải kết thúc bằng:

```text
.../labs/vpn-fingerprint_advanced-evasion
```

Không giải nén thành thư mục lồng hai cấp `vpn-fingerprint_advanced-evasion/vpn-fingerprint_advanced-evasion`.

### 1.2. Tạo lại archive cho 7 container

**[HOST]**

```bash
python3 scripts/build-archives.py
```

Script sẽ khôi phục systemd autostart symlink bị mất (nếu có) rồi tạo lại `home_tar/home.tar` và `sys_tar/sys.tar` cho 7 container.

Kiểm tra từng container:

```bash
for c in victim corp-dns gateway c2-server exfil-dns relay-proxy target-data; do
  test -s "$c/home_tar/home.tar" && test -s "$c/sys_tar/sys.tar" \
    && echo "ARCHIVE_OK $c" || echo "ARCHIVE_MISSING $c"
done
```

Cả 7 dòng phải là `ARCHIVE_OK`.

### 1.3. Chạy preflight và smoke test

**[HOST]**

```bash
bash scripts/preflight.sh
python3 scripts/smoke-test.py
```

Kết quả mong đợi:

```text
PARAMETER_CONFIG_ASCII=PASS
PREFLIGHT=PASS
SMOKE_TEST=PASS
```

Trong smoke test phải thấy đủ 7 dòng `SYSTEMD_AUTOSTART=PASS`, `SERVICE_IP_READINESS=PASS` và cuối cùng `SMOKE_TEST=PASS`.

`config/parameter.config` của lab này phải để trống (0 byte), tránh lỗi `UnicodeDecodeError` ở một số bản Labtainers/Python đọc file bằng ASCII:

```bash
wc -c config/parameter.config
```

Kết quả phải là `0`.

### 1.4. Rebuild image

Mỗi khi thay đổi `_system/`, `home_tar/`, Dockerfile hoặc cấu hình autostart, phải rebuild image. Chỉ sửa source không làm thay đổi container image đã build.

**[HOST]**

```bash
cd "$HOME/labtainer/labtainer-student"
rebuild vpn-fingerprint_advanced-evasion
```

Nếu thư mục student của bản cài đặt khác, dùng đúng thư mục student/workdir trên VM. Nếu build lỗi, xử lý lỗi đầu tiên của Docker/APT trước khi chạy lab.

## 2. Khởi động lab và kiểm tra service tự động

**[HOST]**

```bash
cd "$HOME/labtainer/labtainer-student"
labtainer vpn-fingerprint_advanced-evasion
```

Chờ terminal của 7 container xuất hiện, sau đó đợi thêm khoảng 5–10 giây để service chờ IP Labtainers và mở listener. Không cần chạy `systemctl start` nếu autostart hoạt động.

### 2.1. Gateway

**[gateway]**

```bash
ip -br addr
ip route
sudo systemctl is-enabled lab-gateway.service
sudo systemctl --no-pager --full status lab-gateway.service
sudo vpn-block-check.sh
sudo iptables -S FORWARD
```

Gateway phải có hai IP `10.0.1.1/24` và `10.0.3.1/24`. Unit gateway là `oneshot`, nên `active (exited)` là trạng thái đúng. Kết quả kiểm tra mong đợi:

```text
VPN_BLOCK_CONFIRMED
LABVPN_RESULT=PASS
```

### 2.2. Corp DNS

**[corp-dns]**

```bash
sudo systemctl is-enabled lab-dns.service
sudo systemctl --no-pager --full status lab-dns.service
sudo ss -lunp | grep ':53'
```

Cần thấy unit `enabled`, `active (running)` và listener UDP/53.

### 2.3. Exfil DNS sink

**[exfil-dns]**

```bash
sudo systemctl is-enabled lab-dns.service
sudo systemctl --no-pager --full status lab-dns.service
sudo ss -lunp | grep ':53'
```

Đây là container khác `corp-dns`, dù tên unit cũng là `lab-dns.service`.

### 2.4. TLS passive responder

**[c2-server]**

```bash
sudo systemctl is-enabled lab-c2.service
sudo systemctl --no-pager --full status lab-c2.service
sudo ss -lntp | grep ':443'
```

Cần thấy `enabled`, `active (running)` và TCP/443.

### 2.5. SOCKS5 handshake simulator

**[relay-proxy]**

```bash
sudo systemctl is-enabled lab-relay.service
sudo systemctl --no-pager --full status lab-relay.service
sudo ss -lntp | grep ':1080'
```

Cần thấy `enabled`, `active (running)` và TCP/1080. Simulator chỉ ghi nhận handshake và từ chối `CONNECT`.

### 2.6. Target dữ liệu giả

**[target-data]**

```bash
sudo systemctl is-enabled lab-target.service
sudo systemctl --no-pager --full status lab-target.service
sudo ss -lntp | grep ':8080'
```

Cần thấy TCP/8080. Đây chỉ là máy chủ trang tĩnh giả lập.

### 2.7. Victim

**[victim]**

```bash
sudo systemctl is-enabled lab-victim-init.service
sudo systemctl --no-pager --full status lab-victim-init.service
ls -lh /home/ubuntu/redteam/secret.txt
```

`lab-victim-init.service` là `oneshot`, nên `active (exited)` là bình thường. File `secret.txt` chỉ để làm dữ liệu dummy; nội dung file không được truyền trong bài lab.

### 2.8. Nếu service chưa tự hoạt động

Không tiếp tục tạo traffic. Trên đúng container đang lỗi, lấy log trước:

```bash
sudo journalctl -b -u <ten-service> --no-pager -n 120
ip -br addr
```

Tên unit: `lab-gateway.service`, `lab-dns.service`, `lab-c2.service`, `lab-relay.service`, `lab-target.service` hoặc `lab-victim-init.service`. Chỉ dùng `sudo systemctl start <ten-service>` như biện pháp phục hồi để chẩn đoán; ghi lại vì sao autostart không chạy trước khi kết thúc buổi test.

## 3. Kiểm tra kết nối trước khi bắt PCAP

**[victim]**

```bash
dig @10.0.1.10 probe.exfil.example.local A +time=2 +tries=1

timeout 8 openssl s_client \
  -connect 10.0.3.10:443 \
  -servername passive-c2.example.local \
  -brief </dev/null

nc -vz -w 2 10.0.3.30 1080
nc -vz -w 2 10.0.3.40 8080
```

Kết quả mong đợi: DNS trả lời địa chỉ `10.0.3.20`; TLS handshake tới passive responder hoạt động (chứng chỉ tự ký có thể được cảnh báo); TCP tới relay và target mở được. Nếu một dịch vụ không phản hồi, quay lại kiểm tra service của đúng container.

## 4. Bắt PCAP trước khi sinh traffic

Mở terminal `gateway` và bắt đầu capture.

**[gateway]**

```bash
sudo record-pcap.sh
```

Chờ dòng tương tự:

```text
CAPTURE_START iface=<interface> duration=45 output=/home/ubuntu/red_phase.pcap
```

Ngay sau `CAPTURE_START`, chuyển sang `victim` và chạy cả ba script. Capture kéo dài tối đa 45 giây; không chạy ba script trước khi bắt đầu capture.

## 5. Pha A — sinh traffic mô phỏng trên victim

### 5.1. DNS marker simulation

**[victim]**

```bash
python3 /home/ubuntu/redteam/dns_exfil.py
```

Mong đợi `DNS_SIMULATED_QUERIES` lớn hơn 0 và `DNS_EXFIL_SIMULATION_COMPLETE`.

### 5.2. TLS passive-request simulation

**[victim]**

```bash
python3 /home/ubuntu/redteam/c2_beacon.py
```

Mong đợi `C2_SIMULATED_REQUESTS` lớn hơn 0 và `C2_BEACON_SIMULATION_COMPLETE`.

### 5.3. SOCKS5 handshake-only simulation

**[victim]**

```bash
python3 /home/ubuntu/redteam/exfil_via_socks.py
```

Mong đợi `SOCKS5_CONNECT_REFUSED=EXPECTED` và `EXFIL_VIA_SOCKS_SIMULATION_COMPLETE`. Việc từ chối kết nối đích là hành vi mong đợi của simulator.

Chờ tcpdump kết thúc. Sau đó trên `gateway` kiểm tra PCAP:

```bash
sudo ls -lh /home/ubuntu/red_phase.pcap
sudo tcpdump -nn -r /home/ubuntu/red_phase.pcap 'udp port 53' | head -n 20
sudo tshark -r /home/ubuntu/red_phase.pcap -Y dns \
  -T fields -e frame.time_epoch -e ip.src -e ip.dst -e dns.qry.name | head -n 20
```

Cần nhìn thấy DNS query cho zone `exfil.example.local`. Nếu không có DNS trong PCAP nhưng log `exfil-dns` ghi nhận query, kiểm tra interface capture và thời điểm bắt gói; không chạy Zeek khi PCAP chưa chứa DNS.

## 6. Pha B — phân tích Zeek và Suricata

### 6.1. Zeek

**[gateway]**

```bash
sudo run-zeek.sh
sudo ls -lh /home/ubuntu/zeek_logs
sudo grep -F 'exfil.example.local' /home/ubuntu/zeek_logs/dns.log | head
```

Mong đợi:

```text
ZEEK_RESULT=PASS
LABZEEK_RESULT=PASS
```

`/home/ubuntu/zeek_logs/dns.log` phải tồn tại và có zone mô phỏng. `config/zeek/local.zeek` của bản này không bật `Log::default_rotation_interval`; không thêm cấu hình xoay log theo giờ vì wrapper kiểm tra tên cố định `dns.log`.

### 6.2. Suricata

**[gateway]**

```bash
sudo run-suricata.sh
sudo ls -lh /home/ubuntu/suricata_logs
sudo cat /home/ubuntu/suricata_logs/.lab-suricata-result
```

Mong đợi:

```text
SURICATA_RESULT=PASS
LABSURICATA_RESULT=PASS
```

`SURICATA_RESULT=PASS` xác nhận phân tích offline kết thúc thành công; không có nghĩa tất cả rule đều bắt buộc phải tạo alert.

## 7. Điền threshold cho ba analyzer

Các giá trị bên dưới là starter values cho workload mô phỏng của bài lab, không phải ngưỡng phổ quát cho mạng thật. Chỉnh file bên trong **[gateway]** tại `/home/ubuntu/blueteam/`.

### 7.1. DNS analyzer

File: `/home/ubuntu/blueteam/analyze_dns_exfil.py`

Đặt:

```python
QUERY_LEN_THRESH = 45
ENTROPY_THRESH = 3.3
SUSPECT_ZONE = 'exfil.example.local'
```

Ý nghĩa: tên truy vấn tối thiểu 45 ký tự, entropy nhãn cao từ 3.3 bit/ký tự, và phải kết thúc bằng zone quy định.

### 7.2. TLS timing analyzer

File: `/home/ubuntu/blueteam/analyze_c2_iat.py`

Đặt:

```python
C2_IP = '10.0.3.10'
IAT_WINDOW = 2.0
IAT_CV = 0.25
```

Script nhóm SYN cùng endpoint, tính IAT trong nhóm flow và yêu cầu tối thiểu 4 SYN. IAT trung bình phải gần chu kỳ 2 giây và CV không vượt 0.25. Máy ảo bận có thể làm timing dao động; khi thấy `C2_BEACON=NONE`, kiểm tra số SYN và IAT đo được trước khi cân nhắc threshold.

### 7.3. SOCKS5 analyzer

File: `/home/ubuntu/blueteam/analyze_socks.py`

Đặt:

```python
RELAY_IP = '10.0.3.30'
MIN_HANDSHAKES = 1
```

Một handshake mô phỏng là đủ cho lượt thực nghiệm này. Không diễn giải một handshake đơn lẻ thành bằng chứng proxy trái phép trong mạng doanh nghiệp thực tế.

### 7.4. Cách sửa nhanh không cần nano

Nếu image không có `nano`, chạy nguyên khối lệnh sau trong **[gateway]**. Lệnh chỉ sửa 8 biến CONFIG nói trên; sau đó in lại giá trị để kiểm tra.

```bash
sudo python3 - <<'PY'
from pathlib import Path
import re
base = Path('/home/ubuntu/blueteam')
updates = {
    'analyze_dns_exfil.py': {
        'QUERY_LEN_THRESH': '45',
        'ENTROPY_THRESH': '3.3',
        'SUSPECT_ZONE': "'exfil.example.local'",
    },
    'analyze_c2_iat.py': {
        'C2_IP': "'10.0.3.10'",
        'IAT_WINDOW': '2.0',
        'IAT_CV': '0.25',
    },
    'analyze_socks.py': {
        'RELAY_IP': "'10.0.3.30'",
        'MIN_HANDSHAKES': '1',
    },
}
for filename, values in updates.items():
    path = base / filename
    text = path.read_text(encoding='utf-8')
    for key, value in values.items():
        pattern = rf'(?m)^{re.escape(key)}\s*=.*$'
        text, count = re.subn(pattern, f'{key} = {value}', text)
        if count != 1:
            raise SystemExit(f'CONFIG_EDIT_FAIL {filename}:{key} matches={count}')
    path.write_text(text, encoding='utf-8')
    print(f'CONFIG_UPDATED={path}')
print('THRESHOLDS_CONFIGURED=PASS')
PY
```

### 7.5. Chạy ba analyzer

**[gateway]** — dùng `sudo` cho cả ba wrapper:

```bash
sudo analyze-dns.sh
sudo analyze-c2-iat.sh
sudo analyze-socks.sh
```

Kiểm tra file đầu ra:

```bash
sudo cat /home/ubuntu/bt_dns.out
sudo cat /home/ubuntu/bt_c2.out
sudo cat /home/ubuntu/bt_socks.out
```

Các marker cần có:

```text
DNS_EXFIL=DETECTED
C2_BEACON=DETECTED
SOCKS5_RELAY=DETECTED
```

Đối với C2, kiểm tra thêm `IAT_SYN_COUNT`, `IAT_MEAN` và `IAT_CV`. Nếu không đạt, đối chiếu PCAP bằng `tshark` trước khi thay đổi giá trị cấu hình.

## 8. Điền IOC và sinh báo cáo

File: `/home/ubuntu/blueteam/generate_report.py` trên `gateway`.

Điền block `IOCS`:

```python
IOCS = {
    'exfil_dns_zone': 'exfil.example.local',
    'c2_ip': '10.0.3.10',
    'relay_proxy': '10.0.3.30:1080',
    'victim_ip': '10.0.1.50',
    'ja3': [],
    'beacon_interval_s': 2.0
}
```

Để `ja3` là danh sách rỗng nếu chưa xác minh giá trị bằng công cụ và phiên bản tương ứng; không tự điền hash. Có thể dùng `sudo nano` hoặc sửa block bằng trình soạn thảo có sẵn.

Sinh báo cáo:

```bash
sudo generate-report.sh
sudo ls -lh /home/ubuntu/incident_report.md
sudo head -n 35 /home/ubuntu/incident_report.md
```

Mong đợi:

```text
REPORT_WRITTEN=/home/ubuntu/incident_report.md
Incident Report
LABREPORT_RESULT=PASS
```

Báo cáo cần có Summary, Timeline, IOCs, Device attribution và Recommendations. Bảng MAC-IP là dữ liệu giả lập; resolver forward có thể khiến PCAP phía external thấy nguồn `10.0.1.10`, vì vậy cần giải thích giới hạn truy vết này.

## 9. Cổng kiểm tra cuối trước khi stoplab

Đây là bước bắt buộc để tránh trường hợp mọi lệnh riêng lẻ đều hiện PASS nhưng Checkwork không có một artifact tổng hợp để đọc.

### 9.1. Kiểm tra các file bằng chứng đã tồn tại

**[gateway]**

```bash
sudo test -s /home/ubuntu/red_phase.pcap && echo PCAP_FILE=OK
sudo test -s /home/ubuntu/zeek_logs/dns.log && echo ZEEK_DNS_FILE=OK
sudo test -s /home/ubuntu/suricata_logs/.lab-suricata-result && echo SURICATA_STATUS_FILE=OK
sudo test -s /home/ubuntu/bt_dns.out && echo DNS_ANALYSIS_FILE=OK
sudo test -s /home/ubuntu/bt_c2.out && echo C2_ANALYSIS_FILE=OK
sudo test -s /home/ubuntu/bt_socks.out && echo SOCKS_ANALYSIS_FILE=OK
sudo test -s /home/ubuntu/incident_report.md && echo REPORT_FILE=OK
```

### 9.2. Tạo file evidence mà Checkwork đọc

**[gateway]**

```bash
sudo checkwork-evidence.sh
sudo cat /home/ubuntu/checkwork-evidence.txt
```

Chỉ tiếp tục khi kết quả cuối là:

```text
CHECKWORK_EVIDENCE=PASS
```

File `/home/ubuntu/checkwork-evidence.txt` phải chứa các marker:

```text
VPN_BLOCK_CONFIRMED
LABPCAP_RESULT=PASS
ZEEK_RESULT=PASS
SURICATA_RESULT=PASS
DNS_EXFIL=DETECTED
C2_BEACON=DETECTED
SOCKS5_RELAY=DETECTED
Incident Report
CHECKWORK_EVIDENCE=PASS
```

Nếu script trả `CHECKWORK_EVIDENCE=FAIL`, đọc các dòng `CHECK_FAIL=...`; không stoplab khi còn lỗi. Ví dụ `suricata-success-marker-missing` nghĩa là phải chạy lại `sudo run-suricata.sh` thành công trước khi chạy lại evidence check.

## 10. Stoplab, xác minh artifact, rồi mới Checkwork

### 10.1. Dừng lab đúng quy trình

Chạy trên **[HOST]**, tại thư mục student:

```bash
cd "$HOME/labtainer/labtainer-student"
stoplab
```

Không đóng terminal/VM đột ngột trước khi `stoplab` hoàn tất; đây là bước Labtainers thu thập artifact của các container.

### 10.2. Kiểm tra artifact mới được tạo

**[HOST]**

```bash
find "$HOME/labtainer_xfer/vpn-fingerprint_advanced-evasion" \
  -maxdepth 1 -type f -name '*.lab' \
  -printf '%TY-%Tm-%Td %TH:%TM:%TS  %s bytes  %f\n' | sort
```

Phải có file `.lab` mới, thời gian cập nhật tương ứng phiên vừa kết thúc và kích thước lớn hơn 0.

Kiểm tra cấu trúc ZIP của file `.lab` bằng script hỗ trợ (thay đường dẫn bằng tên file thực tế vừa liệt kê):

```bash
python3 "$LABTAINER_DIR/labs/vpn-fingerprint_advanced-evasion/scripts/verify-checkwork-artifact.py" \
  "$HOME/labtainer_xfer/vpn-fingerprint_advanced-evasion/<file-vua-tao>.lab"
```

Kết quả cần có `ARTIFACT_EVIDENCE_FOUND=PASS` và `ARTIFACT_MARKERS=PASS`. Nếu helper báo không thấy file evidence, chưa chạy Checkwork; hãy xử lý bước thu thập artifact trước.

### 10.3. Chạy Checkwork

**[HOST]**

```bash
checkwork vpn-fingerprint_advanced-evasion
```

Đọc bảng Checkwork. Goal `advanced_evasion_forensics` phải hiển thị đạt (Y/True/Pass tùy phiên bản Labtainers). `PREFLIGHT=PASS` hay `CHECKWORK_EVIDENCE=PASS` riêng lẻ không thay thế kết quả Checkwork.

## 11. Nếu Checkwork vẫn không đạt

### 11.1. Kiểm tra file cấu hình mà host sẽ gửi grader

**[HOST]**

```bash
cd "$LABTAINER_DIR/labs/vpn-fingerprint_advanced-evasion"
cat instr_config/results.config
cat instr_config/goals.config
wc -c config/parameter.config
```

Trong bản source này, `results.config` trỏ trực tiếp đến file hệ thống có tên cố định `gateway:/home/ubuntu/checkwork-evidence.txt`; mọi result đều đọc marker từ file này. `parameter.config` phải là 0 byte.

### 11.2. Kiểm tra identity và file `.lab` cũ

**[HOST]**

```bash
find "$HOME/labtainer_xfer/vpn-fingerprint_advanced-evasion" \
  -maxdepth 1 -type f -name '*.lab' -printf '%TY-%Tm-%Td %TH:%TM %s %f\n'
```

Nếu có nhiều file `.lab` ứng với các identity khác nhau do trước đó đã nhập email/student ID khác nhau, không xóa ngay. Sao lưu trước:

```bash
mkdir -p "$HOME/advanced-evasion-lab-backup"
cp -av "$HOME/labtainer_xfer/vpn-fingerprint_advanced-evasion"/*.lab \
  "$HOME/advanced-evasion-lab-backup/" 2>/dev/null || true
```

Chỉ để lại trong thư mục trao đổi bộ kết quả thuộc đúng identity mà bạn định chấm; chuyển file cũ khác identity sang thư mục backup (không xóa). Khi khởi động lab lần sau, dùng đúng cùng một identity; nếu giá trị mặc định là đúng, nhấn Enter.

### 11.3. Dùng grader debug để xem artifact đã được giải nén chưa

**[HOST]** — mở debug từ thư mục instructor của bản Labtainers đang cài:

```bash
cd "$HOME/labtainer/labtainer-instructor"
./bin/gradelab -d vpn-fingerprint_advanced-evasion
```

Nếu thư mục instructor của bạn nằm ở vị trí khác, dùng thư mục thật trong `$LABTAINER_DIR/scripts/labtainer-instructor`.

**[grader container]** — terminal debug thường đã đăng nhập bằng `instructor`; không chạy `su - instructor` lần nữa:

```bash
whoami
cd /home/instructor
.local/bin/instructor.py
```

Kiểm tra bản cấu hình đã được đưa vào grader:

```bash
cat /home/instructor/.local/instr_config/results.config
cat /home/instructor/.local/instr_config/goals.config
wc -c /home/instructor/.local/config/parameter.config
```

Kiểm tra file artifact đã được giải nén:

```bash
find /home/instructor -type f -path '*/.local/result/*' \
  -name 'checkwork-evidence.txt' -print
```

Nếu tìm thấy file, xem nội dung file đó. Nếu không tìm thấy, xem danh sách result artifacts và kiểm tra file `.lab` trên host; kết quả `PASS` bên trong container chưa được grader nhìn thấy nếu artifact chưa được thu thập.

Lấy log trong grader:

```bash
strings -a /tmp/instructor.log | tail -n 160
```

**[HOST]** — log tổng của Labtainers:

```bash
strings -a "$LABTAINER_DIR/logs/grader.log" | tail -n 160
tail -n 160 "$LABTAINER_DIR/logs/instructor.log"
```

Nếu bảng “What is automatically assessed for this lab” trống, kiểm tra `results.config`, `goals.config` được copy vào grader và traceback cấu hình. Nếu goal hiện nhưng kết quả Unknown/False, kiểm tra `.local/result/checkwork-evidence.txt` và so khớp chính xác các marker. Nếu có `UnicodeDecodeError` trong `ParameterParser.py`, giữ `config/parameter.config` trống.

## 12. Các lỗi thường gặp và cách xử lý

| Dấu hiệu | Nguyên nhân cần kiểm tra | Hướng xử lý |
|---|---|---|
| `PREFLIGHT=FAIL ... missing autostart link` | Symlink systemd bị mất khi giải nén | Chạy `python3 scripts/build-archives.py`, rồi `preflight.sh`; builder gọi script phục hồi liên kết trước khi tạo archive |
| Service không active sau khi mở lab | Image cũ, IP chưa được gán, startup unit lỗi | Rebuild image; kiểm tra `systemctl status`, `journalctl -u ...`, `ip -br addr` trong đúng container |
| `ZEEK_RESULT=FAIL dns.log missing` | PCAP không có DNS hoặc Zeek tạo timestamped log do rotation | Kiểm tra PCAP bằng `tcpdump`; bỏ `Log::default_rotation_interval` trong `local.zeek`; chạy lại Zeek |
| `SURICATA_RESULT=FAIL` | PCAP/rules/config không đọc được | Chạy `sudo run-suricata.sh`, đọc stdout và `suricata_logs`; kiểm tra `all.rules` |
| `DNS_EXFIL=NONE` | Không có DNS log đúng zone hoặc threshold chưa khớp | Xem `dns.log`, qname length, entropy và `SUSPECT_ZONE` trước khi đổi ngưỡng |
| `C2_BEACON=NONE` | Thiếu SYN, capture bắt muộn hoặc timing dao động | Xem số SYN, IAT mean/CV bằng analyzer; bắt lại đủ thời gian trước khi cân nhắc nới CV |
| `SOCKS5_RELAY=NONE` | PCAP thiếu payload cổng 1080 hoặc IP relay sai | Kiểm tra `tshark -Y 'tcp.port == 1080 && tcp.len > 0'` và `RELAY_IP` |
| `CHECKWORK_EVIDENCE=FAIL` | Một hoặc nhiều file runtime thiếu marker | Đọc từng `CHECK_FAIL=...`, chỉ chạy lại bước tương ứng, sau đó chạy evidence check lại |
| Terminal có PASS nhưng Checkwork không đạt | Evidence file chưa được collect hoặc result config/grader không đọc đúng file | Kiểm tra `.lab`, `ARTIFACT_EVIDENCE_FOUND`, `.local/result`, bản results/goals trong grader |
| Bảng assessment trống hoặc `autoGrade()` lỗi | Config chưa vào grader hoặc parser crash | Chạy `gradelab -d`, `instructor.py`, đọc `/tmp/instructor.log` và `logs/grader.log` |
| `UnicodeDecodeError: ascii` | `parameter.config` có ký tự không ASCII | Để `config/parameter.config` rỗng; rebuild archive và chạy lại Checkwork |
| Hai mã sinh viên/identity cùng xuất hiện | Identity thay đổi giữa các phiên hoặc file `.lab` cũ còn trong xfer | Giữ identity nhất quán; sao lưu và tách file `.lab` cũ trước lượt chấm sạch |

## 13. Khi nào được xem là hoàn thành?

| Mốc | Ý nghĩa | Đã đủ để kết luận Checkwork đạt? |
|---|---|---|
| `PREFLIGHT=PASS` | Source, archive, cấu hình và cú pháp tĩnh đạt | Chưa |
| `SMOKE_TEST=PASS` | Kiểm tra tĩnh script và autostart links đạt | Chưa |
| Các analyzer hiện `...=DETECTED` | Logic phân tích thấy dấu vết trong dữ liệu giả | Chưa |
| `CHECKWORK_EVIDENCE=PASS` | Gateway xác minh và ghi file evidence tổng hợp | Chưa |
| `.lab` có `checkwork-evidence.txt` | Artifact đã được Labtainers thu thập | Chưa |
| `checkwork` hiển thị goal đạt | Grader đã đọc và đánh giá evidence | **Có** |

Không publish imodule hoặc coi bài lab đã nghiệm thu cho đến khi kiểm thử `checkwork` thành công trên VM Labtainers mục tiêu.
