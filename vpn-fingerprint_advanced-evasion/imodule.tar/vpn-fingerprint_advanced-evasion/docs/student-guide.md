# Bài capstone: VPN fingerprinting & network forensics nâng cao

## Mục tiêu

Bạn sẽ thực hiện một chuỗi tạo dấu vết **mô phỏng trong mạng lab**, sau đó đóng vai SOC để thu thập và phân tích bằng tcpdump, Zeek, Suricata, tshark và Python. Không đưa dữ liệu cá nhân vào lab. Các script không truyền nội dung `secret.txt`; TLS server chỉ trả phản hồi cố định; bộ mô phỏng SOCKS5 từ chối `CONNECT` và không chuyển tiếp dữ liệu.

## Gợi ý chỉnh các TODO (không cung cấp sẵn đáp án)

- **Ba mức với DNS:** (1) đếm query theo zone; (2) thêm điều kiện chiều dài tên; (3) kết hợp entropy của nhãn con cùng zone và chiều dài. Kiểm tra đơn vị entropy là bit/ký tự.
- **Ba mức với TLS:** (1) lọc đúng IP/port của responder; (2) thu thập timestamp của TCP SYN; (3) tính IAT, trung bình và hệ số biến thiên (CV) trên cùng nhóm endpoint, không trộn với traffic không liên quan.
- **Ba mức với SOCKS5:** (1) lọc cổng 1080; (2) tìm greeting `05 01 00`; (3) kiểm tra thêm yêu cầu CONNECT và đối chiếu địa chỉ relay.

## Pha A — tạo lưu lượng giả

### 1. Khởi động lab và kiểm tra service tự động

Trên bản source final, systemd đã được cấu hình để tự khởi động unit từ `default.target` và `multi-user.target`. Script startup đợi IP tĩnh tương ứng xuất hiện trước khi mở listener, vì vậy **không chạy `systemctl start` trong luồng bình thường**.

Sau khi chạy `labtainer vpn-fingerprint_advanced-evasion` trên host và terminal các container xuất hiện, chờ khoảng 5–10 giây rồi kiểm tra:

**Gateway**

```bash
ip -br addr
sudo systemctl --no-pager --full status lab-gateway.service
sudo vpn-block-check.sh
```

Gateway cần có `10.0.1.1/24`, `10.0.3.1/24`; trạng thái `active (exited)` là bình thường với unit `oneshot`. Marker cần có: `VPN_BLOCK_CONFIRMED` và `LABVPN_RESULT=PASS`.

**Corp DNS**

```bash
sudo systemctl --no-pager --full status lab-dns.service
sudo ss -lunp | grep ':53'
```

**Exfil DNS**

```bash
sudo systemctl --no-pager --full status lab-dns.service
sudo ss -lunp | grep ':53'
```

**C2 server**

```bash
sudo systemctl --no-pager --full status lab-c2.service
sudo ss -lntp | grep ':443'
```

**Relay proxy simulator**

```bash
sudo systemctl --no-pager --full status lab-relay.service
sudo ss -lntp | grep ':1080'
```

**Target data**

```bash
sudo systemctl --no-pager --full status lab-target.service
sudo ss -lntp | grep ':8080'
```

Nếu bất kỳ service nào chưa `active`, lấy log trên đúng container:

```bash
sudo journalctl -b -u <ten-service> --no-pager -n 100
ip -br addr
```

Nếu source hiện tại chưa được rebuild, trên host chạy `python3 scripts/build-archives.py`, `bash scripts/preflight.sh`, rồi `rebuild vpn-fingerprint_advanced-evasion`. Chỉ dùng `sudo systemctl start <ten-service>` để chẩn đoán/khôi phục tạm thời sau khi đã lưu log.

### 1.1. Xác nhận firewall

Trên gateway:

```bash
sudo iptables -S FORWARD
sudo vpn-block-check.sh
```

Không coi trạng thái service là bằng chứng đủ: cần có hai IP, các rule firewall và listener đúng cổng.

### 2. Kiểm tra responder và DNS lab

Trên `victim`:

```bash
dig @10.0.1.10 probe.exfil.example.local A
openssl s_client -connect 10.0.3.10:443 -servername passive-c2.example.local
```

Dùng `dig` để kiểm tra truy vấn DNS thực tế; phép thử TCP bằng `nc` (nếu cần) không thay thế được truy vấn DNS. TLS responder dùng chứng chỉ tự ký trong lab.

### 3. Bắt PCAP trước khi tạo traffic

Trên `gateway`, ở terminal riêng:

```bash
sudo record-pcap.sh
```

Lệnh chờ tối đa 45 giây. Bắt đầu bước 4 ngay sau khi lệnh báo `CAPTURE_START`. Nếu môi trường không hỗ trợ `timeout`, dùng `tcpdump -ni any -s 0 -U -w /home/ubuntu/red_phase.pcap ip` rồi dừng thủ công bằng Ctrl+C.

### 4. Chạy DNS marker simulation

Trên `victim`:

```bash
python3 redteam/dns_exfil.py
```

Kết quả mong đợi: `DNS_SIMULATED_QUERIES` lớn hơn 0 và `DNS_EXFIL_SIMULATION_COMPLETE`. Các nhãn có nonce ngẫu nhiên; nội dung file dummy không được mã hóa hay truyền.

### 5. Chạy TLS passive-request simulation

Trên `victim`:

```bash
python3 redteam/c2_beacon.py
```

Kết quả mong đợi: `C2_SIMULATED_REQUESTS` lớn hơn 0 và `C2_BEACON_SIMULATION_COMPLETE`. Server chỉ trả body cố định, không có lệnh từ xa.

### 6. Chạy SOCKS5 handshake-only simulation

Trên `victim`:

```bash
python3 redteam/exfil_via_socks.py
```

Kết quả mong đợi: `SOCKS5_CONNECT_REFUSED=EXPECTED` và `EXFIL_VIA_SOCKS_SIMULATION_COMPLETE`. Server chỉ ghi nhận handshake và từ chối kết nối đích.

Sau khi ba script chạy xong, đợi capture tự dừng hoặc dừng thủ công. Trên `gateway`:

```bash
ls -lh /home/ubuntu/red_phase.pcap
capinfos /home/ubuntu/red_phase.pcap 2>/dev/null || true
```

## Pha B — phát hiện và truy vết

### 7. Tạo Zeek log và Suricata alert

Trên `gateway`:

```bash
sudo run-zeek.sh
sudo run-suricata.sh
ls -l /home/ubuntu/zeek_logs
```

Kết quả mong đợi: `ZEEK_RESULT=PASS`, `SURICATA_RESULT=PASS`, có `dns.log`, `conn.log`, `ssl.log` (tùy analyzer/version), và `fast.log` nếu có alert. Không khẳng định JA3 đã có nếu chưa cài và kiểm tra analyzer tương ứng.

### 8. Chỉnh `analyze_dns_exfil.py`

Mở `/home/ubuntu/blueteam/analyze_dns_exfil.py`, chỉnh `QUERY_LEN_THRESH`, `ENTROPY_THRESH`, `SUSPECT_ZONE` dựa trên quan sát Zeek log. Sau đó chạy:

```bash
sudo analyze-dns.sh
```

Mục tiêu: có candidate hợp lý và `DNS_EXFIL=DETECTED`; ghi chú vì sao một query đơn lẻ chưa đủ kết luận exfiltration trong mạng thật.

### 9. Chỉnh phân tích TLS và SOCKS5

Chỉnh `C2_IP`, `IAT_WINDOW`, `IAT_CV` trong `analyze_c2_iat.py`, rồi:

```bash
sudo analyze-c2-iat.sh
```

Chỉnh `RELAY_IP`, `MIN_HANDSHAKES` trong `analyze_socks.py`, rồi:

```bash
sudo analyze-socks.sh
```

Mục tiêu: cả hai script cho trạng thái `DETECTED`. Nếu không, đối chiếu `tshark -r /home/ubuntu/red_phase.pcap -Y 'tcp.port==443'` và `tshark -r /home/ubuntu/red_phase.pcap -Y 'tcp.port==1080'`.

### 10. Truy vết và viết báo cáo

Chỉnh IOC trong `/home/ubuntu/blueteam/generate_report.py`, rồi:

```bash
sudo generate-report.sh
cat /home/ubuntu/incident_report.md
```

Báo cáo phải có Summary, Timeline, IOCs, bảng IP/MAC giả lập và Recommendations. Ghi rõ DNS forwarder có thể làm packet trên ext interface mang IP nguồn `10.0.1.10`; dùng resolver log để giải thích attribution. Không khai báo JA3 hash nếu chưa kiểm chứng.

## Kết thúc và Checkwork

Trên `gateway`, sau khi tất cả analyzer và báo cáo đạt, chạy:

```bash
sudo checkwork-evidence.sh
sudo cat /home/ubuntu/checkwork-evidence.txt
```

Chỉ tiếp tục nếu file chứa tất cả marker và `CHECKWORK_EVIDENCE=PASS`. Trên host, chạy `stoplab`, xác nhận file `.lab` mới trong `~/labtainer_xfer/vpn-fingerprint_advanced-evasion`, rồi dùng `scripts/verify-checkwork-artifact.py` để kiểm tra artifact có `checkwork-evidence.txt`. Cuối cùng mới chạy `checkwork vpn-fingerprint_advanced-evasion`.

Các marker PASS ở terminal hoặc `CHECKWORK_EVIDENCE=PASS` chưa phải điểm cuối cùng. Chỉ báo cáo Checkwork hiển thị goal `advanced_evasion_forensics` đạt mới xác nhận bài được chấm thành công. Nếu goal trống/Unknown/False, làm theo `docs/checkwork-diagnostics.md`.
