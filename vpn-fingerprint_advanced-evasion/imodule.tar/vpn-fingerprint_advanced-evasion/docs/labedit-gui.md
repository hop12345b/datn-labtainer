# Dựng topology bằng labedit GUI

Giao diện labedit có thể khác theo phiên bản Labtainers. Cấu hình văn bản `config/start.config` trong gói này là nguồn chuẩn; không tạo lại topology nếu GUI đã nạp đúng 7 container.

## 1. Mở lab

1. Trên VM Labtainers, giải nén thư mục vào `$LABTAINER_DIR/labs/vpn-fingerprint_advanced-evasion`.
2. Chạy `labedit` từ môi trường Labtainers.
3. Dùng **File → Open** (tên menu có thể khác) và mở `vpn-fingerprint_advanced-evasion`.
4. Xác nhận 7 container: `victim`, `corp-dns`, `gateway`, `c2-server`, `exfil-dns`, `relay-proxy`, `target-data`.
5. Xác nhận hai network, theo file `start.config`: `client-net` (`10.0.1.0/24`) và `ext-net` (`10.0.3.0/24`). Yêu cầu ban đầu nói 3 subnet nhưng chỉ định địa chỉ cho 2 subnet; gói này giải quyết theo hai subnet đã được định nghĩa đầy đủ.

## 2. Điền thông số container

| Container | Image | User | Terminals | Network/IP |
|---|---|---|---:|---|
| victim | base `labtainer.network3` + Dockerfile | ubuntu | 1 | client-net / 10.0.1.50 |
| corp-dns | base `labtainer.network3` + Dockerfile | ubuntu | 1 | client-net / 10.0.1.10 |
| gateway | base `labtainer.network3` + Dockerfile | ubuntu | 2 | client-net / 10.0.1.1; ext-net / 10.0.3.1 |
| c2-server | base `labtainer.network3` + Dockerfile | ubuntu | 1 | ext-net / 10.0.3.10 |
| exfil-dns | base `labtainer.network3` + Dockerfile | ubuntu | 1 | ext-net / 10.0.3.20 |
| relay-proxy | base `labtainer.network3` + Dockerfile | ubuntu | 1 | ext-net / 10.0.3.30 |
| target-data | base `labtainer.network3` + Dockerfile | ubuntu | 1 | ext-net / 10.0.3.40 |

Password trong ví dụ là `ubuntu`, theo cấu hình. Không bật thiết bị `/dev/net/tun`: bài lab không khởi tạo tunnel kernel hoặc VPN thật. `NET_ADMIN` cần thiết để gateway cài iptables; `NET_RAW` cần nếu capture bằng công cụ đòi raw socket.

## 3. Capability [CẦN KIỂM TRA]

Không giả định tên trường capability trong GUI giống nhau giữa các bản. Mẫu IPsec kèm theo cũng cần iptables ở gateway, vì vậy kiểm tra capability/container launch policy hiện tại trước khi chỉnh GUI:

```bash
docker inspect <gateway-container-name> --format '{{json .HostConfig.CapAdd}} {{.HostConfig.Privileged}}'
docker exec <gateway-container-name> sh -lc 'iptables -S FORWARD'
```

Nếu `iptables` báo `Operation not permitted`, cần bật capability `NET_ADMIN` thông qua tùy chọn được hỗ trợ bởi phiên bản labedit/framework tại máy. **[CẦN KIỂM TRA]** Tên nút/chỗ nhập chính xác trong GUI: đối chiếu Lab Designer User Guide được cài kèm Labtainers hoặc tìm phần Docker capabilities trong mã labedit của phiên bản đó. Không tự thêm từ khóa vào `start.config` nếu parser chưa hỗ trợ.

`NET_RAW` cần thiết cho `tcpdump`; với network3 image, khả năng capture phụ thuộc runtime capability. Kiểm tra:

```bash
docker exec <gateway-container-name> tcpdump -ni any -c 1
```

## 4. Dockerfile và archive

Tên phải theo đúng quy ước, ví dụ `dockerfiles/Dockerfile.vpn-fingerprint_advanced-evasion.gateway.student`. Mỗi container dùng:

```dockerfile
ADD $labdir/$imagedir/sys_tar/sys.tar /
ADD $labdir/$imagedir/home_tar/home.tar $HOME
```

Sau khi chỉnh file trong `_system` hoặc `home_tar`, chạy `python3 scripts/build-archives.py` rồi **rebuild** lab. Sửa trực tiếp trong container đang chạy không cập nhật source ZIP hay archive đã build.

## 5. Results/Goals

Trong phần Results/Goals của labedit, đối chiếu `instr_config/results.config` và `instr_config/goals.config`. Bản hiện tại dùng file evidence có tên cố định `gateway:/home/ubuntu/checkwork-evidence.txt`, không phụ thuộc wildcard `gateway:*.stdout`. Sau khi chạy đủ các analyzer, sinh báo cáo, chạy `sudo checkwork-evidence.sh` trên gateway; file phải có `CHECKWORK_EVIDENCE=PASS`. Sau `stoplab`, xác nhận file `checkwork-evidence.txt` đã được thu vào `.lab` artifact và grader `.local/result`. Chỉ khi `checkwork vpn-fingerprint_advanced-evasion` hiển thị goal đạt mới coi phần tự động chấm điểm đã được xác nhận.
