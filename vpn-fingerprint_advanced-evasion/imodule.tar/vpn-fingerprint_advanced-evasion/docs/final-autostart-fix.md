# Bản final — sửa tự khởi động service

## Đã thay đổi gì

Bản này gia cố hai điểm có thể khiến service không active ngay sau khi Labtainers khởi động container:

1. Mỗi systemd unit được liên kết để khởi động từ cả `default.target` và `multi-user.target`. Mỗi Dockerfile cũng tạo lại các liên kết sau khi bung `sys.tar`, tránh phụ thuộc riêng vào liên kết bên trong archive.
2. Các startup wrapper chờ IP tĩnh của Labtainers xuất hiện rồi mới bind listener. Điều này giảm lỗi khởi động sớm khi systemd chạy trước khi địa chỉ lab được cấu hình. DNS, C2, relay và target tự khởi động lại sau lỗi; gateway đợi hai IP trước khi áp dụng forwarding/firewall.

Các service liên quan: `lab-gateway.service`, hai instance riêng của `lab-dns.service` (`corp-dns` và `exfil-dns`), `lab-c2.service`, `lab-relay.service`, `lab-target.service` và `lab-victim-init.service`.

## Cài bản final vào VM Labtainers

Các lệnh dưới đây chạy trên **host VM**, không chạy bên trong container. Thay `~/Downloads/vpn-fingerprint_advanced-evasion.zip` bằng nơi bạn lưu file ZIP nếu khác.

```bash
cd "$LABTAINER_DIR/labs"
mv vpn-fingerprint_advanced-evasion \
  "vpn-fingerprint_advanced-evasion.backup-$(date +%Y%m%d-%H%M%S)"
unzip ~/Downloads/vpn-fingerprint_advanced-evasion.zip -d .
cd vpn-fingerprint_advanced-evasion
bash scripts/preflight.sh
python3 scripts/smoke-test.py
```

`preflight.sh` tự gọi `build-archives.py`; builder sẽ khôi phục các systemd symlink nếu công cụ giải nén làm mất hoặc đổi chúng, rồi tạo lại các archive. Vì vậy không còn phụ thuộc vào việc trình giải nén ZIP giữ nguyên Unix symlink. Cũng có thể chủ động chạy `python3 scripts/build-archives.py` trước preflight.

Cần thấy `ARCHIVES_RESULT=PASS`, `PREFLIGHT=PASS`, `SMOKE_TEST=PASS`, các dòng `SYSTEMD_AUTOSTART=PASS` và `SERVICE_IP_READINESS=PASS`.

Sau đó rebuild image vì cấu hình systemd và Dockerfile đã thay đổi:

```bash
cd "$HOME/labtainer/labtainer-student"
rebuild vpn-fingerprint_advanced-evasion
```

Không bỏ qua bước rebuild. Thay source trên host mà không rebuild thì container vẫn chạy image cũ.

## Kiểm tra sau khi mở lab

```bash
labtainer vpn-fingerprint_advanced-evasion
```

Chờ 5–10 giây sau khi terminal của container hiện ra. Trong **từng terminal tương ứng**, kiểm tra:

| Container | Unit | Trạng thái mong đợi | Listener |
|---|---|---|---|
| `gateway` | `lab-gateway.service` | `active (exited)` | Không có listener bắt buộc; phải có hai IP và rule firewall |
| `corp-dns` | `lab-dns.service` | `active (running)` | UDP/53 |
| `exfil-dns` | `lab-dns.service` | `active (running)` | UDP/53 |
| `c2-server` | `lab-c2.service` | `active (running)` | TCP/443 |
| `relay-proxy` | `lab-relay.service` | `active (running)` | TCP/1080 |
| `target-data` | `lab-target.service` | `active (running)` | TCP/8080 |
| `victim` | `lab-victim-init.service` | `active (exited)` | Không có listener bắt buộc |

Ví dụ trong terminal `exfil-dns`:

```bash
sudo systemctl is-enabled lab-dns.service
sudo systemctl --no-pager --full status lab-dns.service
sudo ss -lunp | grep ':53'
```

`systemctl is-enabled` nên in `enabled`. Với `gateway`, kiểm tra:

```bash
ip -br addr
sudo systemctl --no-pager --full status lab-gateway.service
sudo vpn-block-check.sh
```

Gateway phải có `10.0.1.1/24` và `10.0.3.1/24`; firewall checker phải in `VPN_BLOCK_CONFIRMED` và `LABVPN_RESULT=PASS`.

## Nếu một service vẫn không tự khởi động

Không bắt PCAP hay chạy các analyzer cho đến khi các service đã sẵn sàng. Trong terminal container lỗi, lấy:

```bash
systemctl get-default
sudo systemctl is-enabled <ten-service>
sudo systemctl --no-pager --full status <ten-service>
sudo journalctl -b -u <ten-service> --no-pager -n 120
ip -br addr
```

Nếu log ghi `timeout waiting for lab IP`, đối chiếu địa chỉ thực tế với `config/start.config`. Nếu `disabled`, xác nhận đã rebuild image từ chính source final. Nếu service là `failed`, giữ lại log rồi thử `sudo systemctl reset-failed <ten-service>` và `sudo systemctl start <ten-service>` chỉ để chẩn đoán; gửi log trước khi sửa source tiếp.

## Bản vá bổ sung — đồng bộ `scripts/run-suricata.sh`

Rà soát lại toàn bộ cặp file "bản tham chiếu ở `scripts/`" so với bản thực sự được đóng gói vào `_system/`/`home_tar/` của từng container (đây là bất biến mà `docs/file-index.md` đã công bố: mỗi script staged đều có một bản mirror trong `scripts/`). Tất cả các cặp đều khớp, **trừ một file**: `scripts/run-suricata.sh` là bản cũ, thiếu đoạn ghi file trạng thái `/home/ubuntu/suricata_logs/.lab-suricata-result`.

File đang thực sự được đóng gói vào `sys.tar` của gateway — `gateway/_system/usr/local/sbin/run-suricata.sh` — đã có đoạn ghi `SURICATA_RESULT=PASS` vào `.lab-suricata-result`, và đây chính là file mà `checkwork-evidence.sh` đọc để xác nhận goal `_suricata_pass`. Vì `build-archives.py` tar trực tiếp từ `_system/` (không phải từ `scripts/`), runtime trên VM không bị ảnh hưởng bởi bản cũ này. Tuy vậy đây vẫn là một lỗi đóng gói thật sự: bản mirror sai sẽ gây nhầm lẫn cho bất kỳ ai dựa vào `scripts/run-suricata.sh` làm tài liệu tham khảo hoặc bản để chỉnh sửa trước khi build lại.

**Đã sửa:** đồng bộ `scripts/run-suricata.sh` thành bản giống hệt `gateway/_system/usr/local/sbin/run-suricata.sh`. Đã chạy lại `build-archives.py`, `preflight.sh`, `smoke-test.py`: tất cả `PASS`.

### Lưu ý — các TODO(SV) KHÔNG phải là lỗi

Ba file analyzer (`analyze_dns_exfil.py`, `analyze_c2_iat.py`, `analyze_socks.py`) và bảng IOC trong `generate_report.py` cố tình để trống các giá trị đánh dấu `TODO(SV)` (zone DNS, ngưỡng entropy/độ dài, IP C2/relay, cửa sổ/CV nhịp beacon...). Đây không phải lỗi đóng gói — đó chính là phần bài tập mà rubric chấm điểm trực tiếp (xem `instr_config/rubric.md`, mục 15/15/10 điểm cho DNS, SYN-IAT, SOCKS5). `instr_config/instructor-guide.md` có mục "Recommended starter thresholds for instructor-only testing" dành riêng cho giảng viên dùng khi tự kiểm thử dry-run; không nên điền sẵn các giá trị đó vào bản phát cho sinh viên, nếu không sẽ làm mất mục tiêu học tập của bài lab. Nếu Checkwork báo FAIL ở `_dns_detected`, `_c2_detected`, hoặc `_socks_detected`, nguyên nhân thường là ba TODO này còn giá trị `0`/`''` mặc định và cần người chấm/người học điền đúng giá trị quan sát được từ traffic thật trước khi chạy lại wrapper analyzer.

## Phạm vi kiểm thử

Đã chạy kiểm tra cú pháp Python/Bash, kiểm tra cú pháp shell trong các dòng `RUN` của 7 Dockerfile, kiểm tra liên kết autostart trong source và trong từng `sys.tar`, `preflight.sh` và `smoke-test.py`. Môi trường tạo gói không phải VM Labtainers của người dùng, vì vậy **chưa xác nhận runtime end-to-end**. Bước kiểm thử thực tế tiếp theo là chạy bản final trong VM và kiểm tra trạng thái service sau boot mà không chạy `systemctl start` thủ công.
