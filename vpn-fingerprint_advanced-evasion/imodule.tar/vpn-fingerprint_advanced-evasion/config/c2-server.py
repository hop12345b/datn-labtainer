#!/usr/bin/env python3
"""TLS passive responder: returns a canned reply only; accepts no commands."""
import socket, ssl, threading
HOST='10.0.3.10'; PORT=443
CERT='/home/ubuntu/c2/server.crt'; KEY='/home/ubuntu/c2/server.key'
RESPONSE=(b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 26\r\nConnection: close\r\n\r\nSYNTHETIC_PASSIVE_RESPONSE')

def handle(conn, addr):
    try:
        with conn:
            conn.settimeout(4)
            data=b''
            while b'\r\n\r\n' not in data and len(data)<4096:
                chunk=conn.recv(1024)
                if not chunk: break
                data+=chunk
            # Only a fixed HTTP response is returned; request data is never interpreted as a command.
            if data.startswith(b'GET /beacon'):
                conn.sendall(RESPONSE)
            else:
                conn.sendall(b'HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n')
    except OSError: pass

def main():
    ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.load_cert_chain(CERT,KEY)
    with socket.socket() as srv:
        srv.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); srv.bind((HOST,PORT)); srv.listen(32)
        while True:
            raw,addr=srv.accept()
            try: tls=ctx.wrap_socket(raw,server_side=True)
            except ssl.SSLError: raw.close(); continue
            threading.Thread(target=handle,args=(tls,addr),daemon=True).start()
if __name__=='__main__': main()
