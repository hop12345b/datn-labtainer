# Minimal site policy for the lab. Core dns/conn/ssl analyzers are loaded by Zeek.
redef Site::local_nets += { 10.0.1.0/24, 10.0.3.0/24 };
