#!/usr/bin/env bash
set -euo pipefail
umask 077
OUT="${1:-secret.txt}"
# 3072 random bytes expand to exactly 4096 base64 ASCII characters.
python3 - "$OUT" <<'PYGEN'
import base64, secrets, sys
from pathlib import Path
Path(sys.argv[1]).write_text(base64.b64encode(secrets.token_bytes(3072)).decode('ascii'), encoding='ascii')
PYGEN
printf 'SYNTHETIC_SECRET_BYTES=%s\n' "$(wc -c < "$OUT")"
