# Lab 2 network configuration

`start.config` defines the two isolated Labtainers networks (`client-net` 10.0.1.0/24 and `external-net` 10.0.2.0/24) and four containers. The `gateway` has one interface on each network and is the capture point. Runtime endpoints and generated traffic use private lab addresses only.
