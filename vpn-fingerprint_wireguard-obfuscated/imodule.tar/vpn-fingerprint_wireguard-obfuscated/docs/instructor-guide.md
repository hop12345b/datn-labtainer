# Hướng dẫn giảng viên / kiểm thử Lab 2

## Ý tưởng thực nghiệm

Bốn bộ PCAP đã gán nhãn:

| Tên PCAP | Nhãn đúng | Mục đích |
|---|---|---|
| `baseline-no-vpn.pcap` | `NO_VPN` | HTTP/cloud/video-like background + STUN-like noise và gói decoy |
| `direct-wireguard.pcap` | `DIRECT_WG` | WireGuard thuần UDP/51820 |
| `obfuscated-wireguard.pcap` | `OBFUSCATED_WG` | WireGuard qua `wg-obfuscator`, outer UDP/51830 với STUN-like masking |
| `decoy-only.pcap` | `NO_VPN` | Nền tương tự baseline cùng gói gửi tới port 51820/51830 nhưng không có tunnel |

Kỳ vọng cuối cùng: bốn loại đều phân loại đúng. Evaluator in precision/recall/accuracy dạng nhị phân, trong đó cả `DIRECT_WG` và `OBFUSCATED_WG` đều là positive. Goal Checkwork lại yêu cầu phân biệt đủ ba nhãn cụ thể cùng hai mẫu âm.

## Build và kiểm thử trước khi phát hành

1. Kiểm tra biến môi trường Labtainers và xác nhận tên/đường dẫn Dockerfiles được nhận diện bởi bản Labtainers cài trong VM.
2. Từ thư mục lab, chạy `./scripts/sync-build-assets.sh` sau khi sửa source ở `scripts/`.
3. Chạy build bằng công cụ Labtainers đúng phiên bản cài đặt (ví dụ từ GUI `labedit -b` hoặc lệnh tương ứng). Không xem các tarball placeholder là image build thành công.
4. Trong VM host, kiểm tra WireGuard kernel support/capability. **[CẦN KIỂM TRA]** tùy phiên bản Labtainers, khả năng `CAP_NET_ADMIN` và mô-đun WireGuard trong container có thể khác nhau.
5. Xác minh source tag `v1.5` của `ClusterM/wg-obfuscator` được build được trong môi trường Docker có kết nối tại thời điểm build. Lab không gọi Internet trong runtime; việc tạo image ban đầu có thể cần truy cập GitHub để lấy source và apt repository.
6. Chạy đủ bốn capture. Kiểm tra `wg show`, `curl` qua tunnel, `/var/log/wg-obfuscator-*.log`, và packet direction qua gateway.
7. Chạy evaluator trong `gateway`, xác nhận stdout có cả các marker đúng. Sau đó dừng lab và dùng Checkwork.
8. Ghi lại phiên bản kernel, `wg --version`, `wg-obfuscator --version`, `tshark --version`, và tổng số gói mỗi PCAP để việc chấm có thể tái lập.

## Hướng dẫn đọc kết quả

- Direct-WG detector dùng các type field WireGuard nhìn thấy trong đầu gói UDP: initiator/response/cookie/data. Đây chỉ là fingerprint heuristic, không xác thực danh tính peer.
- Obfuscated-WG detector dùng port ngoài, số gói hai chiều, độ đa dạng frame length và entropy payload. Nó không thể suy ra chắc chắn rằng mọi flow thỏa ngưỡng là WireGuard.
- Các PCAP trong bài là mẫu nhỏ có nhãn biết trước, không dùng để phát biểu khả năng phát hiện ngoài thực tế.
- Nếu `OBFUSCATED_WG` không được nhận diện, trước tiên kiểm tra tunnel hoạt động và capture có cả hai hướng; sau đó xem các metric in bởi `detect_wireguard.py` và điều chỉnh ngưỡng. Không thêm marker PASS bằng tay.

## Ghi chú tương thích obfs4

Tên lab kế hoạch ban đầu nhắc tới obfs4. Bản này **không triển khai obfs4**; nó dùng một obfuscator dành riêng cho WireGuard UDP để tránh coi một TCP stream transport là lớp bọc UDP trực tiếp. Nếu giáo trình bắt buộc phải có obfs4 thật, thay lớp che giấu bằng kiến trúc UDP relay + Shadowsocks-rust/adapter + obfs4proxy, rồi kiểm thử lại cả routing, framing và PCAP trước khi phát hành. Không được gọi `wg-obfuscator` là obfs4 trong tài liệu hoặc báo cáo.
