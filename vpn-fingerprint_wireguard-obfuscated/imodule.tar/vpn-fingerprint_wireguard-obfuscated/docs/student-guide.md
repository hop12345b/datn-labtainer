# HƯỚNG DẪN THỰC HÀNH LAB 2

## Fingerprinting WireGuard: traffic thuần, obfuscation và decoy

**Tên lab:** `vpn-fingerprint_wireguard-obfuscated`  
**Thời lượng:** 70 phút  
**Đối tượng:** Sinh viên ATTT năm 3–4, biết Linux và Python cơ bản.  
**Môi trường:** Labtainers trên Ubuntu; bốn container, hai subnet; không yêu cầu Internet trong thời gian chạy lab.

> **Ghi chú kỹ thuật:** bản thực hành này sử dụng `wg-obfuscator` để che giấu lưu lượng WireGuard/UDP với lớp bọc STUN-like. Đây không phải `obfs4proxy`. `obfs4proxy` là transport dạng stream, nên để dùng obfs4 thật với WireGuard cần thêm UDP/stream relay đã được kiểm thử. Không diễn giải kết quả của bài này như một đánh giá thực nghiệm về obfs4.

## 1. Mục tiêu

Sau khi hoàn thành, sinh viên có thể:

1. Thu và so sánh PCAP của lưu lượng nền, WireGuard thuần, WireGuard đã obfuscate, và decoy traffic.
2. Dùng `tcpdump` và `tshark` để quan sát port, loại gói nhìn thấy được, kích thước frame, hướng truyền, packet count và payload entropy.
3. Chỉnh **các tham số có sẵn** ở đầu `detect_wireguard.py`; không viết lại thuật toán.
4. Chạy `evaluate.py`, đọc confusion matrix, precision, recall, accuracy, và dùng Checkwork để kiểm tra bốn bộ PCAP đã biết nhãn.
5. Giải thích vì sao port hoặc kích thước gói đơn lẻ không đủ chứng minh có VPN.

## 2. Sơ đồ mạng

| Container | Địa chỉ | Vai trò |
|---|---|---|
| `client` | `10.0.1.100` | Tạo HTTP/cloud/video-like noise, WireGuard thuần hoặc WireGuard qua obfuscator |
| `gateway` | `10.0.1.1`, `10.0.2.1` | Router và điểm capture; có `tcpdump`, `tshark`, detector/evaluator |
| `vpn-server` | `10.0.2.10` | Hai WireGuard endpoint: một thuần và một nằm sau obfuscator |
| `web-server` | `10.0.2.20` | HTTP nội bộ cùng STUN-like decoy service |

`client-net`: `10.0.1.0/24`. `external-net`: `10.0.2.0/24`.

Các IP, private key, và obfuscation key trong bài chỉ dành cho lab cô lập. Không tái sử dụng bên ngoài.

## 3. Khởi động và kiểm tra (5 phút)

### Trên host Ubuntu

```bash
cd "$LABTAINER_DIR/scripts/labtainer-student"
labtainer vpn-fingerprint_wireguard-obfuscated
```

### Trong terminal `client`

```bash
ip -br addr
ip route
curl -i --max-time 4 http://10.0.2.20/
```

Kết quả HTTP phải chứa `WEB_SERVER_OK`.

### Trong terminal `gateway`

```bash
ip -br addr
ip route
sudo systemctl status vpn-fingerprint-gateway --no-pager
sudo tcpdump --version
sudo tshark --version | head -n 2
```

### Trong terminal `vpn-server`

```bash
ip -br addr
sudo systemctl status vpn-fingerprint-wg --no-pager
sudo systemctl status wg-obfuscator-server --no-pager
sudo wg show
sudo ss -lunp
```

**[CẦN KIỂM TRA]** WireGuard cần hỗ trợ kernel và quyền mạng phù hợp trong container. Nếu `wg-quick` báo `Operation not permitted` hoặc `Unknown device type`, trên host Ubuntu kiểm tra:

```bash
sudo modprobe wireguard
sudo modprobe tun
lsmod | grep -E 'wireguard|udp_tunnel|curve25519'
```

Sau đó kiểm tra capability/network mode mà bản Labtainers đang dùng cấp cho container. Không tiếp tục thu PCAP trước khi dịch vụ WireGuard khởi động được.

## 4. Capture A — baseline: HTTP và noise, không VPN (10 phút)

Trước tiên, trong terminal `client`, bảo đảm hai interface VPN không chạy:

```bash
sudo wg-quick down /etc/wireguard/wg-direct.conf 2>/dev/null || true
sudo wg-quick down /etc/wireguard/wg-obf.conf 2>/dev/null || true
```

Trong terminal `gateway`, bắt đầu capture 35 giây:

```bash
sudo timeout 35s tcpdump -i any -nn -U \
  '(tcp port 80 or udp port 3478 or udp port 51820 or udp port 51830)' \
  -w /home/ubuntu/baseline-no-vpn.pcap
```

Trong lúc `tcpdump` đang chạy, tại terminal `client`:

```bash
python3 /home/ubuntu/generate_traffic.py --mode noise --variant none
```

Đợi `tcpdump` kết thúc rồi kiểm tra ở `gateway`:

```bash
ls -lh /home/ubuntu/baseline-no-vpn.pcap
sudo tshark -r /home/ubuntu/baseline-no-vpn.pcap -q -z io,phs
```

Bộ noise chứa HTTP thường, endpoint giả lập cloud/video, STUN-like traffic nội bộ, và một số gói decoy gửi đến port thường được dùng trong kịch bản VPN. Đây đều là dịch vụ sinh trong lab; không có yêu cầu truy cập Internet thật.

## 5. Capture B — WireGuard thuần (10 phút)

### Trên `client`

```bash
sudo wg-quick up /etc/wireguard/wg-direct.conf
sudo wg show wg-direct
ip route get 10.0.2.20
curl -i --max-time 5 http://10.0.2.20/
```

HTTP qua tunnel phải thành công trước khi bắt gói.

### Trên `gateway`

```bash
sudo timeout 35s tcpdump -i any -nn -U \
  '(tcp port 80 or udp port 3478 or udp port 51820 or udp port 51830)' \
  -w /home/ubuntu/direct-wireguard.pcap
```

Trong lúc capture chạy, tại `client`:

```bash
python3 /home/ubuntu/generate_traffic.py --mode tunnel --variant direct
```

Sau khi capture kết thúc, tại `client`:

```bash
sudo wg show wg-direct
sudo wg-quick down /etc/wireguard/wg-direct.conf
```

## 6. Capture C — WireGuard đã obfuscate (10 phút)

### Kiểm tra obfuscator trên `client`

```bash
sudo systemctl status wg-obfuscator-client --no-pager
sudo tail -n 20 /var/log/wg-obfuscator-client.log
```

Nếu service không chạy, xem log trước khi tiếp tục. Không thay key ở một đầu riêng lẻ; cấu hình hai đầu phải dùng cùng lab-only key.

### Khởi động VPN trên `client`

```bash
sudo wg-quick up /etc/wireguard/wg-obf.conf
sudo wg show wg-obf
ip route get 10.0.2.20
curl -i --max-time 5 http://10.0.2.20/
```

### Capture ở `gateway`

```bash
sudo timeout 35s tcpdump -i any -nn -U \
  '(tcp port 80 or udp port 3478 or udp port 51820 or udp port 51830)' \
  -w /home/ubuntu/obfuscated-wireguard.pcap
```

Khi capture bắt đầu, chạy tại `client`:

```bash
python3 /home/ubuntu/generate_traffic.py --mode tunnel --variant obf
```

Sau capture, tại `client`:

```bash
sudo wg show wg-obf
sudo wg-quick down /etc/wireguard/wg-obf.conf
```

## 7. Capture D — adversarial decoy, không VPN (5 phút)

Đảm bảo cả hai tunnel đã tắt. Trên `gateway`:

```bash
sudo timeout 35s tcpdump -i any -nn -U \
  '(tcp port 80 or udp port 3478 or udp port 51820 or udp port 51830)' \
  -w /home/ubuntu/decoy-only.pcap
```

Trong lúc capture chạy, ở `client`:

```bash
python3 /home/ubuntu/generate_traffic.py --mode decoy --variant none
```

Đây là mẫu đối chứng âm có noise thật trong lab, cùng một số gói gửi đến port dễ khiến bộ phát hiện đơn giản nghi ngờ VPN. Các gói decoy không phải handshake WireGuard hợp lệ và không thiết lập tunnel.

## 8. Phân tích PCAP bằng tshark (10 phút)

Tất cả lệnh ở phần này chạy trong terminal `gateway`.

### Xem protocol hierarchy

```bash
sudo tshark -r /home/ubuntu/baseline-no-vpn.pcap -q -z io,phs
sudo tshark -r /home/ubuntu/direct-wireguard.pcap -q -z io,phs
sudo tshark -r /home/ubuntu/obfuscated-wireguard.pcap -q -z io,phs
sudo tshark -r /home/ubuntu/decoy-only.pcap -q -z io,phs
```

### Xem port, frame length và hướng truyền

```bash
sudo tshark -r /home/ubuntu/direct-wireguard.pcap -Y udp -T fields \
  -E separator=, -e frame.time_epoch -e frame.len -e ip.src -e ip.dst \
  -e udp.srcport -e udp.dstport -e udp.payload | head -n 30

sudo tshark -r /home/ubuntu/obfuscated-wireguard.pcap -Y udp -T fields \
  -E separator=, -e frame.time_epoch -e frame.len -e ip.src -e ip.dst \
  -e udp.srcport -e udp.dstport -e udp.payload | head -n 30
```

So sánh trực tiếp UDP/51820 (WireGuard thuần) với UDP/51830 (lớp obfuscator). Không giả định rằng chỉ cần thấy STUN-like packet là có video call thật.

### Chạy detector trước khi sửa tham số

```bash
python3 /home/ubuntu/detect_wireguard.py /home/ubuntu/baseline-no-vpn.pcap
python3 /home/ubuntu/detect_wireguard.py /home/ubuntu/direct-wireguard.pcap
python3 /home/ubuntu/detect_wireguard.py /home/ubuntu/obfuscated-wireguard.pcap
python3 /home/ubuntu/detect_wireguard.py /home/ubuntu/decoy-only.pcap
```

Script in loại phát hiện, số gói liên quan, số gói có chữ ký WireGuard nhìn thấy được, số gói vào/ra trên port obfuscator, số kích thước khác nhau, và entropy trung bình của payload quan sát được. Các metric chỉ dựa trên header/metadata bên ngoài và bytes quan sát được; script không giải mã payload WireGuard.

## 9. Điều chỉnh tham số và đánh giá (10 phút)

Mở file trong `gateway`:

```bash
nano /home/ubuntu/detect_wireguard.py
```

Chỉ điều chỉnh các hằng số trong khối `PARAMETERS TO TUNE` đầu file, dựa trên số liệu bạn thu được:

- port của WireGuard thuần;
- port phía ngoài của obfuscator;
- số gói có chữ ký WireGuard tối thiểu;
- số gói obfuscator tối thiểu;
- số gói tối thiểu ở từng chiều;
- số loại kích thước frame tối thiểu;
- entropy payload trung bình tối thiểu.

Không sửa hàm `detect_pcap`, phần trích xuất PCAP hoặc `evaluate.py`. Lưu lại tham số sau mỗi lần chạy để báo cáo có thể tái lập.

Chạy evaluator trên cả bốn PCAP:

```bash
python3 /home/ubuntu/evaluate.py \
  /home/ubuntu/baseline-no-vpn.pcap \
  /home/ubuntu/direct-wireguard.pcap \
  /home/ubuntu/obfuscated-wireguard.pcap \
  /home/ubuntu/decoy-only.pcap
```

Kết quả mong muốn là baseline và decoy được phân loại `NO_VPN`, bộ thứ hai là `DIRECT_WG`, và bộ thứ ba là `OBFUSCATED_WG`. Evaluator chỉ in marker tương ứng với một phân loại đúng; nếu cả bốn đúng, nó in `LAB2_RESULT_PASS`. Các metric precision/recall/accuracy là trên bốn bộ PCAP thử nghiệm được gán nhãn sẵn, không đại diện cho hiệu năng ngoài môi trường lab.

## 10. Nộp bài và Checkwork

Trên host Ubuntu:

```bash
stoplab vpn-fingerprint_wireguard-obfuscated
checkwork vpn-fingerprint_wireguard-obfuscated
```

Làm theo hướng dẫn đóng gói kết quả của phiên bản Labtainers đang cài. Nếu Checkwork không hiện goal, trước tiên xác nhận `evaluate.py` đã chạy trong terminal `gateway`, marker đúng đã xuất hiện trong stdout, và Labtainers đã thu thập stdout của terminal đó.

## 11. Câu hỏi cuối bài — gợi ý ba tầng

### Câu 1. Những dấu hiệu nào phân biệt WireGuard thuần với WireGuard đã obfuscate?

- **Gợi ý nhẹ:** Xem port nguồn/đích và loại transport.
- **Gợi ý vừa:** So sánh trường `udp.payload`, kích thước frame và số gói mỗi chiều.
- **Gợi ý mạnh:** Phân biệt chữ ký handshake còn nhìn thấy ở gói thuần với lớp bọc bên ngoài; nêu rõ đặc trưng nào có thể mất sau obfuscation.

### Câu 2. Vì sao một flow trên port 51820 hoặc 51830 không đủ để kết luận có VPN?

- **Gợi ý nhẹ:** Một port có thể được dùng bởi traffic khác hoặc gói giả.
- **Gợi ý vừa:** Dùng file decoy-only để so sánh port, số gói hai chiều và payload.
- **Gợi ý mạnh:** Giải thích trade-off giữa threshold thấp (false positives) và cao (false negatives); đề xuất nhiều feature cùng lúc.

### Câu 3. Entropy payload đo gì, và vì sao entropy cao không đồng nghĩa với VPN?

- **Gợi ý nhẹ:** Entropy mô tả độ phân bố đều của byte values.
- **Gợi ý vừa:** So sánh payload mã hóa, payload nén, dữ liệu ngẫu nhiên và STUN-like header.
- **Gợi ý mạnh:** Nêu cách sample size, header có cấu trúc và traffic đa dạng ảnh hưởng entropy; đề xuất kết hợp entropy với timing, size và flow direction.

### Câu 4. Noise nền ảnh hưởng thế nào tới precision và recall?

- **Gợi ý nhẹ:** Xác định false positive và false negative.
- **Gợi ý vừa:** So sánh baseline-no-vpn với decoy-only và hai loại VPN.
- **Gợi ý mạnh:** Mô tả trường hợp tăng threshold làm giảm FP nhưng bỏ sót flow obfuscated yếu, hoặc hạ threshold khiến STUN-like decoy bị nhận nhầm.

### Câu 5. Nếu đây là điều tra doanh nghiệp, cần thêm bằng chứng gì trước khi kết luận “shadow VPN”?

- **Gợi ý nhẹ:** Xem asset owner, allowlist và chính sách sử dụng.
- **Gợi ý vừa:** Đối chiếu thời gian, endpoint nội bộ, DNS/proxy log và lịch thay đổi.
- **Gợi ý mạnh:** Trình bày chuỗi chứng cứ có thể kiểm chứng, giải pháp xác minh với chủ thiết bị, và cách tránh quy kết chỉ dựa trên một chữ ký mạng.

## 12. Khắc phục nhanh

- **HTTP không truy cập được:** trong `client`, xem `ip route get 10.0.2.20`; trong `gateway`, kiểm tra `ip -br addr`, `ip route`, `sysctl net.ipv4.ip_forward`; trong `vpn-server`, kiểm tra NAT/forwarding.
- **WireGuard không khởi động:** chạy `sudo wg-quick up /etc/wireguard/wg-direct.conf` và đọc toàn bộ lỗi; xác minh kernel module/capability như mục 3.
- **Obfuscator không chạy:** ở `client`/`vpn-server`, đọc `/var/log/wg-obfuscator-*.log` và kiểm tra cùng key, target/port và `sudo ss -lunp`.
- **PCAP rỗng:** bảo đảm `tcpdump` chạy trước `generate_traffic.py`; xác nhận interface gateway và BPF filter.
- **Không phân loại được obfuscated traffic:** xem `OBF_PORT_PACKETS`, `OBF_IN_PACKETS`, `OBF_OUT_PACKETS`, `OBF_SIZE_VARIANTS` và `OBF_MEAN_PAYLOAD_ENTROPY`; thay đổi từng tham số một.
- **Checkwork trống:** chạy evaluator trước, xác nhận stdout có marker, rồi `stoplab` và `checkwork`.
